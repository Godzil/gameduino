Gameduino library
=================

Installation
------------

To install this library, place this entire folder as a subfolder in your
Arduino libraries folder.  Then restart your Arduino application.

To use this library in a sketch, go to the Sketch | Import Library menu and
select Gameduino.

This library also has many examples.  After installation, you can find them under
File | Examples | Gameduino.  'selftest' is a good example to start with, since it
runs a series of hardware tests.

