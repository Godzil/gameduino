/* {'track': 1, 'velocity': 70, 't': 0, 'channel': 2, 'pitch': 65} */
PAUSE(1),
NOTE(8, 65, 70),
/* {'track': 1, 'velocity': 72, 't': 0, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 72),
/* {'track': 1, 'velocity': 71, 't': 0, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 71),
/* {'track': 1, 'velocity': 71, 't': 0, 'channel': 2, 'pitch': 77} */
NOTE(11, 77, 71),
/* {'track': 1, 'velocity': 0, 't': 32, 'channel': 1, 'pitch': 89} */
PAUSE(32),
NOTE(0, 89, 0),
/* {'track': 1, 'velocity': 91, 't': 64, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 91),
/* {'track': 1, 'velocity': 0, 't': 96, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 0, 't': 116, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 116, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 116, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 116, 'channel': 2, 'pitch': 77} */
NOTE(11, 77, 0),
/* {'track': 1, 'velocity': 98, 't': 128, 'channel': 1, 'pitch': 89} */
PAUSE(12),
NOTE(0, 89, 98),
/* {'track': 1, 'velocity': 74, 't': 128, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 74),
/* {'track': 1, 'velocity': 72, 't': 128, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 72),
/* {'track': 1, 'velocity': 74, 't': 128, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 74),
/* {'track': 1, 'velocity': 75, 't': 128, 'channel': 2, 'pitch': 77} */
NOTE(11, 77, 75),
/* {'track': 1, 'velocity': 0, 't': 160, 'channel': 1, 'pitch': 89} */
PAUSE(32),
NOTE(0, 89, 0),
/* {'track': 1, 'velocity': 83, 't': 192, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 83),
/* {'track': 1, 'velocity': 0, 't': 224, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 244, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 244, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 244, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 244, 'channel': 2, 'pitch': 77} */
NOTE(11, 77, 0),
/* {'track': 1, 'velocity': 86, 't': 256, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 288, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 82, 't': 320, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 82),
/* {'track': 1, 'velocity': 0, 't': 352, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 106, 't': 384, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 106),
/* {'track': 1, 'velocity': 68, 't': 384, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 68),
/* {'track': 1, 'velocity': 67, 't': 384, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 67),
/* {'track': 1, 'velocity': 69, 't': 384, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 69),
/* {'track': 1, 'velocity': 0, 't': 416, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 103, 't': 448, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 103),
/* {'track': 1, 'velocity': 0, 't': 480, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 500, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 500, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 500, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 112, 't': 512, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 112),
/* {'track': 1, 'velocity': 87, 't': 512, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 87),
/* {'track': 1, 'velocity': 85, 't': 512, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 85),
/* {'track': 1, 'velocity': 87, 't': 512, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 87),
/* {'track': 1, 'velocity': 86, 't': 512, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 86),
/* {'track': 1, 'velocity': 0, 't': 544, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 91, 't': 576, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 91),
/* {'track': 1, 'velocity': 0, 't': 608, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 0, 't': 628, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 628, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 628, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 628, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 102, 't': 640, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 102),
/* {'track': 1, 'velocity': 76, 't': 640, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 76),
/* {'track': 1, 'velocity': 79, 't': 640, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 79),
/* {'track': 1, 'velocity': 79, 't': 640, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 79),
/* {'track': 1, 'velocity': 75, 't': 640, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 75),
/* {'track': 1, 'velocity': 0, 't': 672, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 86, 't': 704, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 86),
/* {'track': 1, 'velocity': 0, 't': 736, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 756, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 756, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 756, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 756, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 88, 't': 768, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 88),
/* {'track': 1, 'velocity': 0, 't': 800, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 83, 't': 832, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 83),
/* {'track': 1, 'velocity': 0, 't': 864, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 105, 't': 896, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 105),
/* {'track': 1, 'velocity': 67, 't': 896, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 67),
/* {'track': 1, 'velocity': 66, 't': 896, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 66),
/* {'track': 1, 'velocity': 68, 't': 896, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 68),
/* {'track': 1, 'velocity': 66, 't': 896, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 66),
/* {'track': 1, 'velocity': 0, 't': 928, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 105, 't': 960, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 105),
/* {'track': 1, 'velocity': 0, 't': 992, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 1012, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 1012, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 1012, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 1012, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 105, 't': 1024, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 105),
/* {'track': 1, 'velocity': 74, 't': 1024, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 74),
/* {'track': 1, 'velocity': 72, 't': 1024, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 72),
/* {'track': 1, 'velocity': 73, 't': 1024, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 73),
/* {'track': 1, 'velocity': 75, 't': 1024, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 75),
/* {'track': 1, 'velocity': 0, 't': 1056, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 89, 't': 1088, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 89),
/* {'track': 1, 'velocity': 0, 't': 1120, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 1140, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 1140, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 1140, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 1140, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 0),
/* {'track': 1, 'velocity': 102, 't': 1152, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 102),
/* {'track': 1, 'velocity': 77, 't': 1152, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 77),
/* {'track': 1, 'velocity': 73, 't': 1152, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 73),
/* {'track': 1, 'velocity': 73, 't': 1152, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 73),
/* {'track': 1, 'velocity': 74, 't': 1152, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 74),
/* {'track': 1, 'velocity': 0, 't': 1184, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 90, 't': 1216, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 90),
/* {'track': 1, 'velocity': 0, 't': 1248, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 1268, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 1268, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 1268, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 1268, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 0),
/* {'track': 1, 'velocity': 86, 't': 1280, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 1312, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 84, 't': 1344, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 84),
/* {'track': 1, 'velocity': 0, 't': 1376, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 104, 't': 1408, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 104),
/* {'track': 1, 'velocity': 67, 't': 1408, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 67),
/* {'track': 1, 'velocity': 68, 't': 1408, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 68),
/* {'track': 1, 'velocity': 68, 't': 1408, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 68),
/* {'track': 1, 'velocity': 70, 't': 1408, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 70),
/* {'track': 1, 'velocity': 0, 't': 1440, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 106, 't': 1472, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 106),
/* {'track': 1, 'velocity': 0, 't': 1504, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 1524, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 1524, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 1524, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 1524, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 0),
/* {'track': 1, 'velocity': 112, 't': 1536, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 112),
/* {'track': 1, 'velocity': 80, 't': 1536, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 80),
/* {'track': 1, 'velocity': 83, 't': 1536, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 83),
/* {'track': 1, 'velocity': 81, 't': 1536, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 81),
/* {'track': 1, 'velocity': 82, 't': 1536, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 82),
/* {'track': 1, 'velocity': 0, 't': 1568, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 91, 't': 1600, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 91),
/* {'track': 1, 'velocity': 0, 't': 1632, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 0, 't': 1652, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 1652, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 1652, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 1652, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 101, 't': 1664, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 101),
/* {'track': 1, 'velocity': 76, 't': 1664, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 76),
/* {'track': 1, 'velocity': 77, 't': 1664, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 77),
/* {'track': 1, 'velocity': 74, 't': 1664, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 74),
/* {'track': 1, 'velocity': 77, 't': 1664, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 77),
/* {'track': 1, 'velocity': 0, 't': 1696, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 86, 't': 1728, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 86),
/* {'track': 1, 'velocity': 0, 't': 1760, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 1780, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 1780, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 1780, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 1780, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 86, 't': 1792, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 1824, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 86, 't': 1856, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 86),
/* {'track': 1, 'velocity': 0, 't': 1888, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 102, 't': 1920, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 102),
/* {'track': 1, 'velocity': 69, 't': 1920, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 69),
/* {'track': 1, 'velocity': 66, 't': 1920, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 66),
/* {'track': 1, 'velocity': 68, 't': 1920, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 68),
/* {'track': 1, 'velocity': 67, 't': 1920, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 67),
/* {'track': 1, 'velocity': 0, 't': 1952, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 105, 't': 1984, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 105),
/* {'track': 1, 'velocity': 0, 't': 2016, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 2036, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 2036, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 2036, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 2036, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 112, 't': 2048, 'channel': 1, 'pitch': 89} */
PAUSE(12),
NOTE(0, 89, 112),
/* {'track': 1, 'velocity': 83, 't': 2048, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 83),
/* {'track': 1, 'velocity': 79, 't': 2048, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 79),
/* {'track': 1, 'velocity': 81, 't': 2048, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 81),
/* {'track': 1, 'velocity': 80, 't': 2048, 'channel': 2, 'pitch': 77} */
NOTE(11, 77, 80),
/* {'track': 1, 'velocity': 0, 't': 2080, 'channel': 1, 'pitch': 89} */
PAUSE(32),
NOTE(0, 89, 0),
/* {'track': 1, 'velocity': 92, 't': 2112, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 92),
/* {'track': 1, 'velocity': 0, 't': 2144, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 0, 't': 2164, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 2164, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 2164, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 2164, 'channel': 2, 'pitch': 77} */
NOTE(11, 77, 0),
/* {'track': 1, 'velocity': 101, 't': 2176, 'channel': 1, 'pitch': 89} */
PAUSE(12),
NOTE(0, 89, 101),
/* {'track': 1, 'velocity': 77, 't': 2176, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 77),
/* {'track': 1, 'velocity': 75, 't': 2176, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 75),
/* {'track': 1, 'velocity': 74, 't': 2176, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 74),
/* {'track': 1, 'velocity': 77, 't': 2176, 'channel': 2, 'pitch': 77} */
NOTE(11, 77, 77),
/* {'track': 1, 'velocity': 0, 't': 2208, 'channel': 1, 'pitch': 89} */
PAUSE(32),
NOTE(0, 89, 0),
/* {'track': 1, 'velocity': 82, 't': 2240, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 82),
/* {'track': 1, 'velocity': 0, 't': 2272, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 2292, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 2292, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 2292, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 2292, 'channel': 2, 'pitch': 77} */
NOTE(11, 77, 0),
/* {'track': 1, 'velocity': 86, 't': 2304, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 2336, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 85, 't': 2368, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 85),
/* {'track': 1, 'velocity': 0, 't': 2400, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 106, 't': 2432, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 106),
/* {'track': 1, 'velocity': 67, 't': 2432, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 67),
/* {'track': 1, 'velocity': 69, 't': 2432, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 69),
/* {'track': 1, 'velocity': 70, 't': 2432, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 70),
/* {'track': 1, 'velocity': 0, 't': 2464, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 106, 't': 2496, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 106),
/* {'track': 1, 'velocity': 0, 't': 2528, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 2548, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 2548, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 2548, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 112, 't': 2560, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 112),
/* {'track': 1, 'velocity': 87, 't': 2560, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 87),
/* {'track': 1, 'velocity': 87, 't': 2560, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 87),
/* {'track': 1, 'velocity': 85, 't': 2560, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 85),
/* {'track': 1, 'velocity': 87, 't': 2560, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 87),
/* {'track': 1, 'velocity': 0, 't': 2592, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 92, 't': 2624, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 92),
/* {'track': 1, 'velocity': 0, 't': 2656, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 0, 't': 2676, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 2676, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 2676, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 2676, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 101, 't': 2688, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 101),
/* {'track': 1, 'velocity': 77, 't': 2688, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 77),
/* {'track': 1, 'velocity': 78, 't': 2688, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 78),
/* {'track': 1, 'velocity': 78, 't': 2688, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 78),
/* {'track': 1, 'velocity': 76, 't': 2688, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 76),
/* {'track': 1, 'velocity': 0, 't': 2720, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 87, 't': 2752, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 87),
/* {'track': 1, 'velocity': 0, 't': 2784, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 2804, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 2804, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 2804, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 2804, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 87, 't': 2816, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 87),
/* {'track': 1, 'velocity': 0, 't': 2848, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 84, 't': 2880, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 84),
/* {'track': 1, 'velocity': 0, 't': 2912, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 102, 't': 2944, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 102),
/* {'track': 1, 'velocity': 67, 't': 2944, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 67),
/* {'track': 1, 'velocity': 69, 't': 2944, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 69),
/* {'track': 1, 'velocity': 70, 't': 2944, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 70),
/* {'track': 1, 'velocity': 69, 't': 2944, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 69),
/* {'track': 1, 'velocity': 0, 't': 2976, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 106, 't': 3008, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 106),
/* {'track': 1, 'velocity': 0, 't': 3040, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 3060, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 3060, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 3060, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 3060, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 3072, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 104),
/* {'track': 1, 'velocity': 73, 't': 3072, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 73),
/* {'track': 1, 'velocity': 74, 't': 3072, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 74),
/* {'track': 1, 'velocity': 73, 't': 3072, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 73),
/* {'track': 1, 'velocity': 74, 't': 3072, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 74),
/* {'track': 1, 'velocity': 0, 't': 3104, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 92, 't': 3136, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 92),
/* {'track': 1, 'velocity': 0, 't': 3168, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 3188, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 3188, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 3188, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 3188, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 0),
/* {'track': 1, 'velocity': 101, 't': 3200, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 101),
/* {'track': 1, 'velocity': 73, 't': 3200, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 73),
/* {'track': 1, 'velocity': 74, 't': 3200, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 74),
/* {'track': 1, 'velocity': 75, 't': 3200, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 75),
/* {'track': 1, 'velocity': 75, 't': 3200, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 75),
/* {'track': 1, 'velocity': 0, 't': 3232, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 91, 't': 3264, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 91),
/* {'track': 1, 'velocity': 0, 't': 3296, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 3316, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 3316, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 3316, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 3316, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 0),
/* {'track': 1, 'velocity': 86, 't': 3328, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 3360, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 83, 't': 3392, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 83),
/* {'track': 1, 'velocity': 0, 't': 3424, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 103, 't': 3456, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 103),
/* {'track': 1, 'velocity': 70, 't': 3456, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 70),
/* {'track': 1, 'velocity': 66, 't': 3456, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 66),
/* {'track': 1, 'velocity': 69, 't': 3456, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 69),
/* {'track': 1, 'velocity': 67, 't': 3456, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 67),
/* {'track': 1, 'velocity': 0, 't': 3488, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 104, 't': 3520, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 104),
/* {'track': 1, 'velocity': 0, 't': 3552, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 3572, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 3572, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 3572, 'channel': 2, 'pitch': 72} */
NOTE(10, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 3572, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 0),
/* {'track': 1, 'velocity': 112, 't': 3584, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 112),
/* {'track': 1, 'velocity': 81, 't': 3584, 'channel': 2, 'pitch': 67} */
NOTE(8, 67, 81),
/* {'track': 1, 'velocity': 82, 't': 3584, 'channel': 2, 'pitch': 71} */
NOTE(9, 71, 82),
/* {'track': 1, 'velocity': 82, 't': 3584, 'channel': 2, 'pitch': 76} */
NOTE(10, 76, 82),
/* {'track': 1, 'velocity': 0, 't': 3616, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 85, 't': 3648, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 85),
/* {'track': 1, 'velocity': 0, 't': 3680, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 3700, 'channel': 2, 'pitch': 67} */
PAUSE(20),
NOTE(8, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 3700, 'channel': 2, 'pitch': 71} */
NOTE(9, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 3700, 'channel': 2, 'pitch': 76} */
NOTE(10, 76, 0),
/* {'track': 1, 'velocity': 107, 't': 3712, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 107),
/* {'track': 1, 'velocity': 77, 't': 3712, 'channel': 2, 'pitch': 67} */
NOTE(8, 67, 77),
/* {'track': 1, 'velocity': 77, 't': 3712, 'channel': 2, 'pitch': 71} */
NOTE(9, 71, 77),
/* {'track': 1, 'velocity': 75, 't': 3712, 'channel': 2, 'pitch': 76} */
NOTE(10, 76, 75),
/* {'track': 1, 'velocity': 0, 't': 3744, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 84, 't': 3776, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 84),
/* {'track': 1, 'velocity': 0, 't': 3808, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 3828, 'channel': 2, 'pitch': 67} */
PAUSE(20),
NOTE(8, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 3828, 'channel': 2, 'pitch': 71} */
NOTE(9, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 3828, 'channel': 2, 'pitch': 76} */
NOTE(10, 76, 0),
/* {'track': 1, 'velocity': 84, 't': 3840, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 84),
/* {'track': 1, 'velocity': 0, 't': 3872, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 87, 't': 3904, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 87),
/* {'track': 1, 'velocity': 0, 't': 3936, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 102, 't': 3968, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 102),
/* {'track': 1, 'velocity': 70, 't': 3968, 'channel': 2, 'pitch': 67} */
NOTE(8, 67, 70),
/* {'track': 1, 'velocity': 70, 't': 3968, 'channel': 2, 'pitch': 71} */
NOTE(9, 71, 70),
/* {'track': 1, 'velocity': 70, 't': 3968, 'channel': 2, 'pitch': 76} */
NOTE(10, 76, 70),
/* {'track': 1, 'velocity': 0, 't': 4000, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 108, 't': 4032, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 108),
/* {'track': 1, 'velocity': 0, 't': 4064, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 4084, 'channel': 2, 'pitch': 67} */
PAUSE(20),
NOTE(8, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 4084, 'channel': 2, 'pitch': 71} */
NOTE(9, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 4084, 'channel': 2, 'pitch': 76} */
NOTE(10, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 4096, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 104),
/* {'track': 1, 'velocity': 71, 't': 4096, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 71),
/* {'track': 1, 'velocity': 69, 't': 4096, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 69),
/* {'track': 1, 'velocity': 68, 't': 4096, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 68),
/* {'track': 1, 'velocity': 67, 't': 4096, 'channel': 2, 'pitch': 72} */
NOTE(11, 72, 67),
/* {'track': 1, 'velocity': 0, 't': 4128, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 93, 't': 4160, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 93),
/* {'track': 1, 'velocity': 0, 't': 4192, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 4212, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 4212, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 4212, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 4212, 'channel': 2, 'pitch': 72} */
NOTE(11, 72, 0),
/* {'track': 1, 'velocity': 100, 't': 4224, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 100),
/* {'track': 1, 'velocity': 72, 't': 4224, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 72),
/* {'track': 1, 'velocity': 74, 't': 4224, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 74),
/* {'track': 1, 'velocity': 76, 't': 4224, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 76),
/* {'track': 1, 'velocity': 75, 't': 4224, 'channel': 2, 'pitch': 72} */
NOTE(11, 72, 75),
/* {'track': 1, 'velocity': 0, 't': 4256, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 84, 't': 4288, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 84),
/* {'track': 1, 'velocity': 0, 't': 4320, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 4340, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 4340, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 4340, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 4340, 'channel': 2, 'pitch': 72} */
NOTE(11, 72, 0),
/* {'track': 1, 'velocity': 85, 't': 4352, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 85),
/* {'track': 1, 'velocity': 0, 't': 4384, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 84, 't': 4416, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 84),
/* {'track': 1, 'velocity': 0, 't': 4448, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 103, 't': 4480, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 103),
/* {'track': 1, 'velocity': 70, 't': 4480, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 70),
/* {'track': 1, 'velocity': 67, 't': 4480, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 67),
/* {'track': 1, 'velocity': 69, 't': 4480, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 69),
/* {'track': 1, 'velocity': 0, 't': 4512, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 4544, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 104),
/* {'track': 1, 'velocity': 0, 't': 4576, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 4596, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 4596, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 4596, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 109, 't': 4608, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 109),
/* {'track': 1, 'velocity': 87, 't': 4608, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 87),
/* {'track': 1, 'velocity': 88, 't': 4608, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 88),
/* {'track': 1, 'velocity': 88, 't': 4608, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 88),
/* {'track': 1, 'velocity': 87, 't': 4608, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 87),
/* {'track': 1, 'velocity': 0, 't': 4640, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 94, 't': 4672, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 94),
/* {'track': 1, 'velocity': 0, 't': 4704, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 4724, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 4724, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 4724, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 4724, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 0),
/* {'track': 1, 'velocity': 101, 't': 4736, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 101),
/* {'track': 1, 'velocity': 76, 't': 4736, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 76),
/* {'track': 1, 'velocity': 78, 't': 4736, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 78),
/* {'track': 1, 'velocity': 75, 't': 4736, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 75),
/* {'track': 1, 'velocity': 75, 't': 4736, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 75),
/* {'track': 1, 'velocity': 0, 't': 4768, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 85, 't': 4800, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 85),
/* {'track': 1, 'velocity': 0, 't': 4832, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 4852, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 4852, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 4852, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 4852, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 0),
/* {'track': 1, 'velocity': 85, 't': 4864, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 85),
/* {'track': 1, 'velocity': 0, 't': 4896, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 82, 't': 4928, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 82),
/* {'track': 1, 'velocity': 0, 't': 4960, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 105, 't': 4992, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 105),
/* {'track': 1, 'velocity': 67, 't': 4992, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 67),
/* {'track': 1, 'velocity': 68, 't': 4992, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 68),
/* {'track': 1, 'velocity': 70, 't': 4992, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 70),
/* {'track': 1, 'velocity': 69, 't': 4992, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 69),
/* {'track': 1, 'velocity': 0, 't': 5024, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 5056, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 104),
/* {'track': 1, 'velocity': 0, 't': 5088, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 5108, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 5108, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 5108, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 5108, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 0),
/* {'track': 1, 'velocity': 106, 't': 5120, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 106),
/* {'track': 1, 'velocity': 72, 't': 5120, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 72),
/* {'track': 1, 'velocity': 73, 't': 5120, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 73),
/* {'track': 1, 'velocity': 72, 't': 5120, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 72),
/* {'track': 1, 'velocity': 72, 't': 5120, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 72),
/* {'track': 1, 'velocity': 0, 't': 5152, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 88, 't': 5184, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 88),
/* {'track': 1, 'velocity': 0, 't': 5216, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 5236, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 5236, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 5236, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 5236, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 0),
/* {'track': 1, 'velocity': 101, 't': 5248, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 101),
/* {'track': 1, 'velocity': 76, 't': 5248, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 76),
/* {'track': 1, 'velocity': 77, 't': 5248, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 77),
/* {'track': 1, 'velocity': 73, 't': 5248, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 73),
/* {'track': 1, 'velocity': 76, 't': 5248, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 76),
/* {'track': 1, 'velocity': 0, 't': 5280, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 89, 't': 5312, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 89),
/* {'track': 1, 'velocity': 0, 't': 5344, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 5364, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 5364, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 5364, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 5364, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 0),
/* {'track': 1, 'velocity': 87, 't': 5376, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 87),
/* {'track': 1, 'velocity': 0, 't': 5408, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 86, 't': 5440, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 86),
/* {'track': 1, 'velocity': 0, 't': 5472, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 106, 't': 5504, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 106),
/* {'track': 1, 'velocity': 66, 't': 5504, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 66),
/* {'track': 1, 'velocity': 70, 't': 5504, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 70),
/* {'track': 1, 'velocity': 66, 't': 5504, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 66),
/* {'track': 1, 'velocity': 69, 't': 5504, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 69),
/* {'track': 1, 'velocity': 0, 't': 5536, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 5568, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 104),
/* {'track': 1, 'velocity': 0, 't': 5600, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 5620, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 5620, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 5620, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 5620, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 0),
/* {'track': 1, 'velocity': 111, 't': 5632, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 111),
/* {'track': 1, 'velocity': 83, 't': 5632, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 83),
/* {'track': 1, 'velocity': 82, 't': 5632, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 82),
/* {'track': 1, 'velocity': 82, 't': 5632, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 82),
/* {'track': 1, 'velocity': 80, 't': 5632, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 80),
/* {'track': 1, 'velocity': 0, 't': 5664, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 92, 't': 5696, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 92),
/* {'track': 1, 'velocity': 0, 't': 5728, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 5748, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 5748, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 5748, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 5748, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 0),
/* {'track': 1, 'velocity': 101, 't': 5760, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 101),
/* {'track': 1, 'velocity': 76, 't': 5760, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 76),
/* {'track': 1, 'velocity': 75, 't': 5760, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 75),
/* {'track': 1, 'velocity': 77, 't': 5760, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 77),
/* {'track': 1, 'velocity': 76, 't': 5760, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 76),
/* {'track': 1, 'velocity': 0, 't': 5792, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 87, 't': 5824, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 87),
/* {'track': 1, 'velocity': 0, 't': 5856, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 5876, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 5876, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 5876, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 5876, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 0),
/* {'track': 1, 'velocity': 85, 't': 5888, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 85),
/* {'track': 1, 'velocity': 0, 't': 5920, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 82, 't': 5952, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 82),
/* {'track': 1, 'velocity': 0, 't': 5984, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 103, 't': 6016, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 103),
/* {'track': 1, 'velocity': 70, 't': 6016, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 70),
/* {'track': 1, 'velocity': 69, 't': 6016, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 69),
/* {'track': 1, 'velocity': 67, 't': 6016, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 67),
/* {'track': 1, 'velocity': 67, 't': 6016, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 67),
/* {'track': 1, 'velocity': 0, 't': 6048, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 6080, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 104),
/* {'track': 1, 'velocity': 0, 't': 6112, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 6132, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 6132, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 6132, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 6132, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 0),
/* {'track': 1, 'velocity': 114, 't': 6144, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 114),
/* {'track': 1, 'velocity': 80, 't': 6144, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 80),
/* {'track': 1, 'velocity': 82, 't': 6144, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 82),
/* {'track': 1, 'velocity': 82, 't': 6144, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 82),
/* {'track': 1, 'velocity': 79, 't': 6144, 'channel': 2, 'pitch': 72} */
NOTE(11, 72, 79),
/* {'track': 1, 'velocity': 0, 't': 6176, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 95, 't': 6208, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 95),
/* {'track': 1, 'velocity': 0, 't': 6240, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 6260, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 6260, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 6260, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 6260, 'channel': 2, 'pitch': 72} */
NOTE(11, 72, 0),
/* {'track': 1, 'velocity': 101, 't': 6272, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 101),
/* {'track': 1, 'velocity': 77, 't': 6272, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 77),
/* {'track': 1, 'velocity': 77, 't': 6272, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 77),
/* {'track': 1, 'velocity': 77, 't': 6272, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 77),
/* {'track': 1, 'velocity': 75, 't': 6272, 'channel': 2, 'pitch': 72} */
NOTE(11, 72, 75),
/* {'track': 1, 'velocity': 0, 't': 6304, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 85, 't': 6336, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 85),
/* {'track': 1, 'velocity': 0, 't': 6368, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 6388, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 6388, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 6388, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 6388, 'channel': 2, 'pitch': 72} */
NOTE(11, 72, 0),
/* {'track': 1, 'velocity': 83, 't': 6400, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 83),
/* {'track': 1, 'velocity': 0, 't': 6432, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 86, 't': 6464, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 86),
/* {'track': 1, 'velocity': 0, 't': 6496, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 104, 't': 6528, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 104),
/* {'track': 1, 'velocity': 67, 't': 6528, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 67),
/* {'track': 1, 'velocity': 68, 't': 6528, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 68),
/* {'track': 1, 'velocity': 68, 't': 6528, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 68),
/* {'track': 1, 'velocity': 0, 't': 6560, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 105, 't': 6592, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 105),
/* {'track': 1, 'velocity': 0, 't': 6624, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 6644, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 6644, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 6644, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 110, 't': 6656, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 110),
/* {'track': 1, 'velocity': 85, 't': 6656, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 85),
/* {'track': 1, 'velocity': 86, 't': 6656, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 86),
/* {'track': 1, 'velocity': 85, 't': 6656, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 85),
/* {'track': 1, 'velocity': 87, 't': 6656, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 87),
/* {'track': 1, 'velocity': 0, 't': 6688, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 92, 't': 6720, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 92),
/* {'track': 1, 'velocity': 0, 't': 6752, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 6772, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 6772, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 6772, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 6772, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 0),
/* {'track': 1, 'velocity': 104, 't': 6784, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 104),
/* {'track': 1, 'velocity': 78, 't': 6784, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 78),
/* {'track': 1, 'velocity': 75, 't': 6784, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 75),
/* {'track': 1, 'velocity': 79, 't': 6784, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 79),
/* {'track': 1, 'velocity': 77, 't': 6784, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 77),
/* {'track': 1, 'velocity': 0, 't': 6816, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 84, 't': 6848, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 84),
/* {'track': 1, 'velocity': 0, 't': 6880, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 6900, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 6900, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 6900, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 6900, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 0),
/* {'track': 1, 'velocity': 84, 't': 6912, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 84),
/* {'track': 1, 'velocity': 0, 't': 6944, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 83, 't': 6976, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 83),
/* {'track': 1, 'velocity': 0, 't': 7008, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 106, 't': 7040, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 106),
/* {'track': 1, 'velocity': 67, 't': 7040, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 67),
/* {'track': 1, 'velocity': 68, 't': 7040, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 68),
/* {'track': 1, 'velocity': 68, 't': 7040, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 68),
/* {'track': 1, 'velocity': 67, 't': 7040, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 67),
/* {'track': 1, 'velocity': 0, 't': 7072, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 105, 't': 7104, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 105),
/* {'track': 1, 'velocity': 0, 't': 7136, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 7156, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 7156, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 7156, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 7156, 'channel': 2, 'pitch': 71} */
NOTE(11, 71, 0),
/* {'track': 1, 'velocity': 108, 't': 7168, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 108),
/* {'track': 1, 'velocity': 74, 't': 7168, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 74),
/* {'track': 1, 'velocity': 74, 't': 7168, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 74),
/* {'track': 1, 'velocity': 74, 't': 7168, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 74),
/* {'track': 1, 'velocity': 75, 't': 7168, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 75),
/* {'track': 1, 'velocity': 0, 't': 7200, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 89, 't': 7232, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 89),
/* {'track': 1, 'velocity': 0, 't': 7264, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 7284, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 7284, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 7284, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 7284, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 0),
/* {'track': 1, 'velocity': 102, 't': 7296, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 102),
/* {'track': 1, 'velocity': 75, 't': 7296, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 75),
/* {'track': 1, 'velocity': 76, 't': 7296, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 76),
/* {'track': 1, 'velocity': 77, 't': 7296, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 77),
/* {'track': 1, 'velocity': 74, 't': 7296, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 74),
/* {'track': 1, 'velocity': 0, 't': 7328, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 88, 't': 7360, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 88),
/* {'track': 1, 'velocity': 0, 't': 7392, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 7412, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 7412, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 7412, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 7412, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 0),
/* {'track': 1, 'velocity': 85, 't': 7424, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 85),
/* {'track': 1, 'velocity': 0, 't': 7456, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 82, 't': 7488, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 82),
/* {'track': 1, 'velocity': 0, 't': 7520, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 106, 't': 7552, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 106),
/* {'track': 1, 'velocity': 68, 't': 7552, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 68),
/* {'track': 1, 'velocity': 67, 't': 7552, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 67),
/* {'track': 1, 'velocity': 68, 't': 7552, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 68),
/* {'track': 1, 'velocity': 68, 't': 7552, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 68),
/* {'track': 1, 'velocity': 0, 't': 7584, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 106, 't': 7616, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 106),
/* {'track': 1, 'velocity': 0, 't': 7648, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 7668, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 7668, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 7668, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 7668, 'channel': 2, 'pitch': 69} */
NOTE(11, 69, 0),
/* {'track': 1, 'velocity': 113, 't': 7680, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 113),
/* {'track': 1, 'velocity': 82, 't': 7680, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 82),
/* {'track': 1, 'velocity': 82, 't': 7680, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 82),
/* {'track': 1, 'velocity': 80, 't': 7680, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 80),
/* {'track': 1, 'velocity': 0, 't': 7712, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 84, 't': 7744, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 84),
/* {'track': 1, 'velocity': 0, 't': 7776, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 7796, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 7796, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 7796, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 0),
/* {'track': 1, 'velocity': 108, 't': 7808, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 108),
/* {'track': 1, 'velocity': 77, 't': 7808, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 77),
/* {'track': 1, 'velocity': 74, 't': 7808, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 74),
/* {'track': 1, 'velocity': 75, 't': 7808, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 75),
/* {'track': 1, 'velocity': 0, 't': 7840, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 84, 't': 7872, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 84),
/* {'track': 1, 'velocity': 0, 't': 7904, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 7924, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 7924, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 7924, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 0),
/* {'track': 1, 'velocity': 84, 't': 7936, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 84),
/* {'track': 1, 'velocity': 0, 't': 7968, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 88, 't': 8000, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 88),
/* {'track': 1, 'velocity': 0, 't': 8032, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 98, 't': 8064, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 98),
/* {'track': 1, 'velocity': 69, 't': 8064, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 69),
/* {'track': 1, 'velocity': 68, 't': 8064, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 68),
/* {'track': 1, 'velocity': 67, 't': 8064, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 67),
/* {'track': 1, 'velocity': 0, 't': 8096, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 107, 't': 8128, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 107),
/* {'track': 1, 'velocity': 0, 't': 8160, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 8180, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 8180, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 8180, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 0),
/* {'track': 1, 'velocity': 107, 't': 8192, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 107),
/* {'track': 1, 'velocity': 69, 't': 8192, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 69),
/* {'track': 1, 'velocity': 68, 't': 8192, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 68),
/* {'track': 1, 'velocity': 68, 't': 8192, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 68),
/* {'track': 1, 'velocity': 69, 't': 8192, 'channel': 2, 'pitch': 67} */
NOTE(11, 67, 69),
/* {'track': 1, 'velocity': 0, 't': 8224, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 93, 't': 8256, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 93),
/* {'track': 1, 'velocity': 0, 't': 8288, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 8308, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 8308, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 8308, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 8308, 'channel': 2, 'pitch': 67} */
NOTE(11, 67, 0),
/* {'track': 1, 'velocity': 100, 't': 8320, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 100),
/* {'track': 1, 'velocity': 76, 't': 8320, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 76),
/* {'track': 1, 'velocity': 73, 't': 8320, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 73),
/* {'track': 1, 'velocity': 73, 't': 8320, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 73),
/* {'track': 1, 'velocity': 74, 't': 8320, 'channel': 2, 'pitch': 67} */
NOTE(11, 67, 74),
/* {'track': 1, 'velocity': 0, 't': 8352, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 86, 't': 8384, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 8416, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 8436, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 8436, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 8436, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 8436, 'channel': 2, 'pitch': 67} */
NOTE(11, 67, 0),
/* {'track': 1, 'velocity': 85, 't': 8448, 'channel': 1, 'pitch': 71} */
PAUSE(12),
NOTE(0, 71, 85),
/* {'track': 1, 'velocity': 0, 't': 8480, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 86, 't': 8512, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 86),
/* {'track': 1, 'velocity': 0, 't': 8544, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 104, 't': 8576, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 104),
/* {'track': 1, 'velocity': 69, 't': 8576, 'channel': 2, 'pitch': 59} */
NOTE(8, 59, 69),
/* {'track': 1, 'velocity': 67, 't': 8576, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 67),
/* {'track': 1, 'velocity': 0, 't': 8608, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 105, 't': 8640, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 105),
/* {'track': 1, 'velocity': 0, 't': 8672, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 8692, 'channel': 2, 'pitch': 59} */
PAUSE(20),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 8692, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 117, 't': 8704, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 117),
/* {'track': 1, 'velocity': 88, 't': 8704, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 88),
/* {'track': 1, 'velocity': 88, 't': 8704, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 88),
/* {'track': 1, 'velocity': 88, 't': 8704, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 88),
/* {'track': 1, 'velocity': 0, 't': 8736, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 96, 't': 8768, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 96),
/* {'track': 1, 'velocity': 0, 't': 8800, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 8820, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 8820, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 8820, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 102, 't': 8832, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 102),
/* {'track': 1, 'velocity': 78, 't': 8832, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 78),
/* {'track': 1, 'velocity': 76, 't': 8832, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 76),
/* {'track': 1, 'velocity': 78, 't': 8832, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 78),
/* {'track': 1, 'velocity': 0, 't': 8864, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 84, 't': 8896, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 84),
/* {'track': 1, 'velocity': 0, 't': 8928, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 8948, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 8948, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 8948, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 83, 't': 8960, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 83),
/* {'track': 1, 'velocity': 0, 't': 8992, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 86, 't': 9024, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 86),
/* {'track': 1, 'velocity': 0, 't': 9056, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 104, 't': 9088, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 104),
/* {'track': 1, 'velocity': 67, 't': 9088, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 67),
/* {'track': 1, 'velocity': 66, 't': 9088, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 66),
/* {'track': 1, 'velocity': 69, 't': 9088, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 69),
/* {'track': 1, 'velocity': 0, 't': 9120, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 105, 't': 9152, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 105),
/* {'track': 1, 'velocity': 0, 't': 9184, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 9204, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 9204, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 9204, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 114, 't': 9216, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 114),
/* {'track': 1, 'velocity': 79, 't': 9216, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 79),
/* {'track': 1, 'velocity': 78, 't': 9216, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 78),
/* {'track': 1, 'velocity': 77, 't': 9216, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 77),
/* {'track': 1, 'velocity': 0, 't': 9248, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 87, 't': 9280, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 87),
/* {'track': 1, 'velocity': 0, 't': 9312, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 9332, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 9332, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 9332, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 106, 't': 9344, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 106),
/* {'track': 1, 'velocity': 76, 't': 9344, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 76),
/* {'track': 1, 'velocity': 78, 't': 9344, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 78),
/* {'track': 1, 'velocity': 75, 't': 9344, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 75),
/* {'track': 1, 'velocity': 0, 't': 9376, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 87, 't': 9408, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 87),
/* {'track': 1, 'velocity': 0, 't': 9440, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 9460, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 9460, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 9460, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 85, 't': 9472, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 85),
/* {'track': 1, 'velocity': 0, 't': 9504, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 79, 't': 9536, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 79),
/* {'track': 1, 'velocity': 0, 't': 9568, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 107, 't': 9600, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 107),
/* {'track': 1, 'velocity': 70, 't': 9600, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 70),
/* {'track': 1, 'velocity': 68, 't': 9600, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 68),
/* {'track': 1, 'velocity': 69, 't': 9600, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 69),
/* {'track': 1, 'velocity': 0, 't': 9632, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 105, 't': 9664, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 105),
/* {'track': 1, 'velocity': 0, 't': 9696, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 9716, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 9716, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 9716, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 112, 't': 9728, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 112),
/* {'track': 1, 'velocity': 75, 't': 9728, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 75),
/* {'track': 1, 'velocity': 77, 't': 9728, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 77),
/* {'track': 1, 'velocity': 76, 't': 9728, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 76),
/* {'track': 1, 'velocity': 0, 't': 9760, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 94, 't': 9792, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 94),
/* {'track': 1, 'velocity': 0, 't': 9824, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 9844, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 9844, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 9844, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 99, 't': 9856, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 99),
/* {'track': 1, 'velocity': 74, 't': 9856, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 74),
/* {'track': 1, 'velocity': 75, 't': 9856, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 75),
/* {'track': 1, 'velocity': 75, 't': 9856, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 75),
/* {'track': 1, 'velocity': 0, 't': 9888, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 85, 't': 9920, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 85),
/* {'track': 1, 'velocity': 0, 't': 9952, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 9972, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 9972, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 9972, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 84, 't': 9984, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 84),
/* {'track': 1, 'velocity': 0, 't': 10016, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 82, 't': 10048, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 82),
/* {'track': 1, 'velocity': 0, 't': 10080, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 104, 't': 10112, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 104),
/* {'track': 1, 'velocity': 69, 't': 10112, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 69),
/* {'track': 1, 'velocity': 67, 't': 10112, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 67),
/* {'track': 1, 'velocity': 69, 't': 10112, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 69),
/* {'track': 1, 'velocity': 0, 't': 10144, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 106, 't': 10176, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 106),
/* {'track': 1, 'velocity': 0, 't': 10208, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 10228, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 10228, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 10228, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 115, 't': 10240, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 115),
/* {'track': 1, 'velocity': 75, 't': 10240, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 75),
/* {'track': 1, 'velocity': 71, 't': 10240, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 71),
/* {'track': 1, 'velocity': 72, 't': 10240, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 72),
/* {'track': 1, 'velocity': 0, 't': 10272, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 86, 't': 10304, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 86),
/* {'track': 1, 'velocity': 0, 't': 10336, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 10356, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 10356, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 10356, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 0),
/* {'track': 1, 'velocity': 105, 't': 10368, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 105),
/* {'track': 1, 'velocity': 74, 't': 10368, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 74),
/* {'track': 1, 'velocity': 76, 't': 10368, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 76),
/* {'track': 1, 'velocity': 76, 't': 10368, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 76),
/* {'track': 1, 'velocity': 0, 't': 10400, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 86, 't': 10432, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 86),
/* {'track': 1, 'velocity': 0, 't': 10464, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 10484, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 10484, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 10484, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 0),
/* {'track': 1, 'velocity': 86, 't': 10496, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 10528, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 82, 't': 10560, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 82),
/* {'track': 1, 'velocity': 0, 't': 10592, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 105, 't': 10624, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 105),
/* {'track': 1, 'velocity': 68, 't': 10624, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 68),
/* {'track': 1, 'velocity': 70, 't': 10624, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 70),
/* {'track': 1, 'velocity': 0, 't': 10656, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 104, 't': 10688, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 104),
/* {'track': 1, 'velocity': 0, 't': 10720, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 10740, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 10740, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 117, 't': 10752, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 117),
/* {'track': 1, 'velocity': 87, 't': 10752, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 87),
/* {'track': 1, 'velocity': 86, 't': 10752, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 86),
/* {'track': 1, 'velocity': 87, 't': 10752, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 87),
/* {'track': 1, 'velocity': 0, 't': 10784, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 93, 't': 10816, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 93),
/* {'track': 1, 'velocity': 0, 't': 10848, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 10868, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 10868, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 10868, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 99, 't': 10880, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 99),
/* {'track': 1, 'velocity': 75, 't': 10880, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 75),
/* {'track': 1, 'velocity': 78, 't': 10880, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 78),
/* {'track': 1, 'velocity': 75, 't': 10880, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 75),
/* {'track': 1, 'velocity': 0, 't': 10912, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 83, 't': 10944, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 83),
/* {'track': 1, 'velocity': 0, 't': 10976, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 10996, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 10996, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 10996, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 86, 't': 11008, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 86),
/* {'track': 1, 'velocity': 0, 't': 11040, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 83, 't': 11072, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 83),
/* {'track': 1, 'velocity': 0, 't': 11104, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 103, 't': 11136, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 103),
/* {'track': 1, 'velocity': 68, 't': 11136, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 68),
/* {'track': 1, 'velocity': 66, 't': 11136, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 66),
/* {'track': 1, 'velocity': 68, 't': 11136, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 68),
/* {'track': 1, 'velocity': 0, 't': 11168, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 103, 't': 11200, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 103),
/* {'track': 1, 'velocity': 0, 't': 11232, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 11252, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 11252, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 11252, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 113, 't': 11264, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 113),
/* {'track': 1, 'velocity': 77, 't': 11264, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 77),
/* {'track': 1, 'velocity': 78, 't': 11264, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 78),
/* {'track': 1, 'velocity': 76, 't': 11264, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 76),
/* {'track': 1, 'velocity': 0, 't': 11296, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 88, 't': 11328, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 88),
/* {'track': 1, 'velocity': 0, 't': 11360, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 11380, 'channel': 2, 'pitch': 64} */
PAUSE(20),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 11380, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 11380, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 105, 't': 11392, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 105),
/* {'track': 1, 'velocity': 77, 't': 11392, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 77),
/* {'track': 1, 'velocity': 74, 't': 11392, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 74),
/* {'track': 1, 'velocity': 75, 't': 11392, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 75),
/* {'track': 1, 'velocity': 0, 't': 11424, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 86, 't': 11456, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 86),
/* {'track': 1, 'velocity': 0, 't': 11488, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 11508, 'channel': 2, 'pitch': 64} */
PAUSE(20),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 11508, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 11508, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 87, 't': 11520, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 87),
/* {'track': 1, 'velocity': 0, 't': 11552, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 81, 't': 11584, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 81),
/* {'track': 1, 'velocity': 0, 't': 11616, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 106, 't': 11648, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 106),
/* {'track': 1, 'velocity': 69, 't': 11648, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 69),
/* {'track': 1, 'velocity': 67, 't': 11648, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 67),
/* {'track': 1, 'velocity': 67, 't': 11648, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 67),
/* {'track': 1, 'velocity': 0, 't': 11680, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 103, 't': 11712, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 103),
/* {'track': 1, 'velocity': 0, 't': 11744, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 11764, 'channel': 2, 'pitch': 64} */
PAUSE(20),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 11764, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 11764, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 112, 't': 11776, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 112),
/* {'track': 1, 'velocity': 77, 't': 11776, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 77),
/* {'track': 1, 'velocity': 78, 't': 11776, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 78),
/* {'track': 1, 'velocity': 77, 't': 11776, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 77),
/* {'track': 1, 'velocity': 0, 't': 11808, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 95, 't': 11840, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 95),
/* {'track': 1, 'velocity': 0, 't': 11872, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 11892, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 11892, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 11892, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 102, 't': 11904, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 102),
/* {'track': 1, 'velocity': 77, 't': 11904, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 77),
/* {'track': 1, 'velocity': 77, 't': 11904, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 77),
/* {'track': 1, 'velocity': 74, 't': 11904, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 74),
/* {'track': 1, 'velocity': 0, 't': 11936, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 86, 't': 11968, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 86),
/* {'track': 1, 'velocity': 0, 't': 12000, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 12020, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 12020, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 12020, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 83, 't': 12032, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 83),
/* {'track': 1, 'velocity': 0, 't': 12064, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 83, 't': 12096, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 83),
/* {'track': 1, 'velocity': 0, 't': 12128, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 104, 't': 12160, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 104),
/* {'track': 1, 'velocity': 67, 't': 12160, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 67),
/* {'track': 1, 'velocity': 66, 't': 12160, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 66),
/* {'track': 1, 'velocity': 69, 't': 12160, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 69),
/* {'track': 1, 'velocity': 0, 't': 12192, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 106, 't': 12224, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 106),
/* {'track': 1, 'velocity': 0, 't': 12256, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 12276, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 12276, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 12276, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 113, 't': 12288, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 113),
/* {'track': 1, 'velocity': 72, 't': 12288, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 72),
/* {'track': 1, 'velocity': 71, 't': 12288, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 71),
/* {'track': 1, 'velocity': 73, 't': 12288, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 73),
/* {'track': 1, 'velocity': 0, 't': 12320, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 89, 't': 12352, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 89),
/* {'track': 1, 'velocity': 0, 't': 12384, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 12404, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 12404, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 12404, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 104, 't': 12416, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 104),
/* {'track': 1, 'velocity': 75, 't': 12416, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 75),
/* {'track': 1, 'velocity': 76, 't': 12416, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 76),
/* {'track': 1, 'velocity': 73, 't': 12416, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 73),
/* {'track': 1, 'velocity': 0, 't': 12448, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 86, 't': 12480, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 86),
/* {'track': 1, 'velocity': 0, 't': 12512, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 12532, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 12532, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 12532, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 84, 't': 12544, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 84),
/* {'track': 1, 'velocity': 0, 't': 12576, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 80, 't': 12608, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 80),
/* {'track': 1, 'velocity': 0, 't': 12640, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 105, 't': 12672, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 105),
/* {'track': 1, 'velocity': 66, 't': 12672, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 66),
/* {'track': 1, 'velocity': 67, 't': 12672, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 67),
/* {'track': 1, 'velocity': 0, 't': 12704, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 105, 't': 12736, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 105),
/* {'track': 1, 'velocity': 0, 't': 12768, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 12788, 'channel': 2, 'pitch': 64} */
PAUSE(20),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 12788, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 112, 't': 12800, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 112),
/* {'track': 1, 'velocity': 83, 't': 12800, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 83),
/* {'track': 1, 'velocity': 84, 't': 12800, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 84),
/* {'track': 1, 'velocity': 86, 't': 12800, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 86),
/* {'track': 1, 'velocity': 0, 't': 12832, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 91, 't': 12864, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 91),
/* {'track': 1, 'velocity': 0, 't': 12896, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 12916, 'channel': 2, 'pitch': 64} */
PAUSE(20),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 12916, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 12916, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 99, 't': 12928, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 99),
/* {'track': 1, 'velocity': 78, 't': 12928, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 78),
/* {'track': 1, 'velocity': 75, 't': 12928, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 75),
/* {'track': 1, 'velocity': 74, 't': 12928, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 74),
/* {'track': 1, 'velocity': 0, 't': 12960, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 83, 't': 12992, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 83),
/* {'track': 1, 'velocity': 0, 't': 13024, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 13044, 'channel': 2, 'pitch': 64} */
PAUSE(20),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 13044, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 13044, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 86, 't': 13056, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 86),
/* {'track': 1, 'velocity': 0, 't': 13088, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 84, 't': 13120, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 84),
/* {'track': 1, 'velocity': 0, 't': 13152, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 105, 't': 13184, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 105),
/* {'track': 1, 'velocity': 69, 't': 13184, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 69),
/* {'track': 1, 'velocity': 66, 't': 13184, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 66),
/* {'track': 1, 'velocity': 69, 't': 13184, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 69),
/* {'track': 1, 'velocity': 0, 't': 13216, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 13248, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 104),
/* {'track': 1, 'velocity': 0, 't': 13280, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 13300, 'channel': 2, 'pitch': 64} */
PAUSE(20),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 13300, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 13300, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 112, 't': 13312, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 112),
/* {'track': 1, 'velocity': 76, 't': 13312, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 76),
/* {'track': 1, 'velocity': 76, 't': 13312, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 76),
/* {'track': 1, 'velocity': 79, 't': 13312, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 79),
/* {'track': 1, 'velocity': 0, 't': 13344, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 80, 't': 13376, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 80),
/* {'track': 1, 'velocity': 0, 't': 13408, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 13428, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 13428, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 13428, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 110, 't': 13440, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 110),
/* {'track': 1, 'velocity': 76, 't': 13440, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 76),
/* {'track': 1, 'velocity': 76, 't': 13440, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 76),
/* {'track': 1, 'velocity': 76, 't': 13440, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 76),
/* {'track': 1, 'velocity': 0, 't': 13472, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 79, 't': 13504, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 79),
/* {'track': 1, 'velocity': 0, 't': 13536, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 13556, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 13556, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 13556, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 86, 't': 13568, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 13600, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 89, 't': 13632, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 89),
/* {'track': 1, 'velocity': 0, 't': 13664, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 101, 't': 13696, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 101),
/* {'track': 1, 'velocity': 67, 't': 13696, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 67),
/* {'track': 1, 'velocity': 69, 't': 13696, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 69),
/* {'track': 1, 'velocity': 68, 't': 13696, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 68),
/* {'track': 1, 'velocity': 0, 't': 13728, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 105, 't': 13760, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 105),
/* {'track': 1, 'velocity': 0, 't': 13792, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 13812, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 13812, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 13812, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 118, 't': 13824, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 118),
/* {'track': 1, 'velocity': 76, 't': 13824, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 76),
/* {'track': 1, 'velocity': 76, 't': 13824, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 76),
/* {'track': 1, 'velocity': 76, 't': 13824, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 76),
/* {'track': 1, 'velocity': 0, 't': 13856, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 91, 't': 13888, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 91),
/* {'track': 1, 'velocity': 0, 't': 13920, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 13940, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 13940, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 13940, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 105, 't': 13952, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 105),
/* {'track': 1, 'velocity': 77, 't': 13952, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 77),
/* {'track': 1, 'velocity': 74, 't': 13952, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 74),
/* {'track': 1, 'velocity': 77, 't': 13952, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 77),
/* {'track': 1, 'velocity': 0, 't': 13984, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 88, 't': 14016, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 88),
/* {'track': 1, 'velocity': 0, 't': 14048, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 14068, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 14068, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 14068, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 84, 't': 14080, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 84),
/* {'track': 1, 'velocity': 0, 't': 14112, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 82, 't': 14144, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 82),
/* {'track': 1, 'velocity': 0, 't': 14176, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 104, 't': 14208, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 104),
/* {'track': 1, 'velocity': 67, 't': 14208, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 67),
/* {'track': 1, 'velocity': 67, 't': 14208, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 67),
/* {'track': 1, 'velocity': 67, 't': 14208, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 67),
/* {'track': 1, 'velocity': 0, 't': 14240, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 108, 't': 14272, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 108),
/* {'track': 1, 'velocity': 0, 't': 14304, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 14324, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 14324, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 14324, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 108, 't': 14336, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 108),
/* {'track': 1, 'velocity': 77, 't': 14336, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 77),
/* {'track': 1, 'velocity': 78, 't': 14336, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 78),
/* {'track': 1, 'velocity': 78, 't': 14336, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 78),
/* {'track': 1, 'velocity': 0, 't': 14368, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 86, 't': 14400, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 86),
/* {'track': 1, 'velocity': 0, 't': 14432, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 14452, 'channel': 2, 'pitch': 64} */
PAUSE(20),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 14452, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 14452, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 108, 't': 14464, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 108),
/* {'track': 1, 'velocity': 77, 't': 14464, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 77),
/* {'track': 1, 'velocity': 75, 't': 14464, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 75),
/* {'track': 1, 'velocity': 77, 't': 14464, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 77),
/* {'track': 1, 'velocity': 0, 't': 14496, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 83, 't': 14528, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 83),
/* {'track': 1, 'velocity': 0, 't': 14560, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 14580, 'channel': 2, 'pitch': 64} */
PAUSE(20),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 14580, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 14580, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 85, 't': 14592, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 85),
/* {'track': 1, 'velocity': 0, 't': 14624, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 85, 't': 14656, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 85),
/* {'track': 1, 'velocity': 0, 't': 14688, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 106, 't': 14720, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 106),
/* {'track': 1, 'velocity': 69, 't': 14720, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 69),
/* {'track': 1, 'velocity': 68, 't': 14720, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 68),
/* {'track': 1, 'velocity': 68, 't': 14720, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 68),
/* {'track': 1, 'velocity': 0, 't': 14752, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 107, 't': 14784, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 107),
/* {'track': 1, 'velocity': 0, 't': 14816, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 14836, 'channel': 2, 'pitch': 64} */
PAUSE(20),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 14836, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 14836, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 114, 't': 14848, 'channel': 1, 'pitch': 85} */
PAUSE(12),
NOTE(0, 85, 114),
/* {'track': 1, 'velocity': 84, 't': 14848, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 84),
/* {'track': 1, 'velocity': 85, 't': 14848, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 85),
/* {'track': 1, 'velocity': 83, 't': 14848, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 83),
/* {'track': 1, 'velocity': 86, 't': 14848, 'channel': 2, 'pitch': 73} */
NOTE(11, 73, 86),
/* {'track': 1, 'velocity': 0, 't': 14880, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 90, 't': 14912, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 90),
/* {'track': 1, 'velocity': 0, 't': 14944, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 14964, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 14964, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 14964, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 14964, 'channel': 2, 'pitch': 73} */
NOTE(11, 73, 0),
/* {'track': 1, 'velocity': 103, 't': 14976, 'channel': 1, 'pitch': 85} */
PAUSE(12),
NOTE(0, 85, 103),
/* {'track': 1, 'velocity': 77, 't': 14976, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 77),
/* {'track': 1, 'velocity': 76, 't': 14976, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 76),
/* {'track': 1, 'velocity': 74, 't': 14976, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 74),
/* {'track': 1, 'velocity': 76, 't': 14976, 'channel': 2, 'pitch': 73} */
NOTE(11, 73, 76),
/* {'track': 1, 'velocity': 0, 't': 15008, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 87, 't': 15040, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 87),
/* {'track': 1, 'velocity': 0, 't': 15072, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 15092, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 15092, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 15092, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 15092, 'channel': 2, 'pitch': 73} */
NOTE(11, 73, 0),
/* {'track': 1, 'velocity': 86, 't': 15104, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 86),
/* {'track': 1, 'velocity': 0, 't': 15136, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 79, 't': 15168, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 79),
/* {'track': 1, 'velocity': 0, 't': 15200, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 108, 't': 15232, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 108),
/* {'track': 1, 'velocity': 66, 't': 15232, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 66),
/* {'track': 1, 'velocity': 70, 't': 15232, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 70),
/* {'track': 1, 'velocity': 68, 't': 15232, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 68),
/* {'track': 1, 'velocity': 69, 't': 15232, 'channel': 2, 'pitch': 73} */
NOTE(11, 73, 69),
/* {'track': 1, 'velocity': 0, 't': 15264, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 107, 't': 15296, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 107),
/* {'track': 1, 'velocity': 0, 't': 15328, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 15348, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 15348, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 15348, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 15348, 'channel': 2, 'pitch': 73} */
NOTE(11, 73, 0),
/* {'track': 1, 'velocity': 112, 't': 15360, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 112),
/* {'track': 1, 'velocity': 80, 't': 15360, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 80),
/* {'track': 1, 'velocity': 81, 't': 15360, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 81),
/* {'track': 1, 'velocity': 81, 't': 15360, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 81),
/* {'track': 1, 'velocity': 82, 't': 15360, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 82),
/* {'track': 1, 'velocity': 0, 't': 15392, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 92, 't': 15424, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 92),
/* {'track': 1, 'velocity': 0, 't': 15456, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 15476, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 15476, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 15476, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 15476, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 0),
/* {'track': 1, 'velocity': 99, 't': 15488, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 99),
/* {'track': 1, 'velocity': 75, 't': 15488, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 75),
/* {'track': 1, 'velocity': 76, 't': 15488, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 76),
/* {'track': 1, 'velocity': 75, 't': 15488, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 75),
/* {'track': 1, 'velocity': 75, 't': 15488, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 75),
/* {'track': 1, 'velocity': 0, 't': 15520, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 84, 't': 15552, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 84),
/* {'track': 1, 'velocity': 0, 't': 15584, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 15604, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 15604, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 15604, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 15604, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 0),
/* {'track': 1, 'velocity': 87, 't': 15616, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 87),
/* {'track': 1, 'velocity': 0, 't': 15648, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 83, 't': 15680, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 83),
/* {'track': 1, 'velocity': 0, 't': 15712, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 105, 't': 15744, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 105),
/* {'track': 1, 'velocity': 67, 't': 15744, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 67),
/* {'track': 1, 'velocity': 67, 't': 15744, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 67),
/* {'track': 1, 'velocity': 70, 't': 15744, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 70),
/* {'track': 1, 'velocity': 66, 't': 15744, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 66),
/* {'track': 1, 'velocity': 0, 't': 15776, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 104, 't': 15808, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 104),
/* {'track': 1, 'velocity': 0, 't': 15840, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 15860, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 15860, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 15860, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 15860, 'channel': 2, 'pitch': 74} */
NOTE(11, 74, 0),
/* {'track': 1, 'velocity': 115, 't': 15872, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 115),
/* {'track': 1, 'velocity': 83, 't': 15872, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 83),
/* {'track': 1, 'velocity': 82, 't': 15872, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 82),
/* {'track': 1, 'velocity': 82, 't': 15872, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 82),
/* {'track': 1, 'velocity': 82, 't': 15872, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 82),
/* {'track': 1, 'velocity': 0, 't': 15904, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 93, 't': 15936, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 93),
/* {'track': 1, 'velocity': 0, 't': 15968, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 0, 't': 15988, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 15988, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 15988, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 15988, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 102, 't': 16000, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 102),
/* {'track': 1, 'velocity': 76, 't': 16000, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 76),
/* {'track': 1, 'velocity': 77, 't': 16000, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 77),
/* {'track': 1, 'velocity': 75, 't': 16000, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 75),
/* {'track': 1, 'velocity': 75, 't': 16000, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 75),
/* {'track': 1, 'velocity': 0, 't': 16032, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 85, 't': 16064, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 85),
/* {'track': 1, 'velocity': 0, 't': 16096, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 16116, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 16116, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 16116, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 16116, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 87, 't': 16128, 'channel': 1, 'pitch': 82} */
PAUSE(12),
NOTE(0, 82, 87),
/* {'track': 1, 'velocity': 0, 't': 16160, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 87, 't': 16192, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 87),
/* {'track': 1, 'velocity': 0, 't': 16224, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 101, 't': 16256, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 101),
/* {'track': 1, 'velocity': 66, 't': 16256, 'channel': 2, 'pitch': 60} */
NOTE(8, 60, 66),
/* {'track': 1, 'velocity': 70, 't': 16256, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 70),
/* {'track': 1, 'velocity': 69, 't': 16256, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 69),
/* {'track': 1, 'velocity': 70, 't': 16256, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 70),
/* {'track': 1, 'velocity': 0, 't': 16288, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 109, 't': 16320, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 109),
/* {'track': 1, 'velocity': 0, 't': 16352, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 0, 't': 16372, 'channel': 2, 'pitch': 60} */
PAUSE(20),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 16372, 'channel': 2, 'pitch': 67} */
NOTE(9, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 16372, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 16372, 'channel': 2, 'pitch': 76} */
NOTE(11, 76, 0),
/* {'track': 1, 'velocity': 103, 't': 16384, 'channel': 1, 'pitch': 89} */
PAUSE(12),
NOTE(0, 89, 103),
/* {'track': 1, 'velocity': 57, 't': 16384, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 57),
/* {'track': 1, 'velocity': 58, 't': 16384, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 58),
/* {'track': 1, 'velocity': 58, 't': 16384, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 58),
/* {'track': 1, 'velocity': 57, 't': 16384, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 57),
/* {'track': 1, 'velocity': 70, 't': 16384, 'channel': 2, 'pitch': 41} */
NOTE(12, 41, 70),
/* {'track': 1, 'velocity': 0, 't': 16416, 'channel': 1, 'pitch': 89} */
PAUSE(32),
NOTE(0, 89, 0),
/* {'track': 1, 'velocity': 93, 't': 16448, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 93),
/* {'track': 1, 'velocity': 0, 't': 16480, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 0, 't': 16500, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 16500, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 16500, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 16500, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 0),
/* {'track': 1, 'velocity': 102, 't': 16512, 'channel': 1, 'pitch': 89} */
PAUSE(12),
NOTE(0, 89, 102),
/* {'track': 1, 'velocity': 72, 't': 16512, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 72),
/* {'track': 1, 'velocity': 73, 't': 16512, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 73),
/* {'track': 1, 'velocity': 70, 't': 16512, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 70),
/* {'track': 1, 'velocity': 72, 't': 16512, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 72),
/* {'track': 1, 'velocity': 0, 't': 16544, 'channel': 1, 'pitch': 89} */
PAUSE(32),
NOTE(0, 89, 0),
/* {'track': 1, 'velocity': 84, 't': 16576, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 84),
/* {'track': 1, 'velocity': 0, 't': 16608, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 16628, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 16628, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 16628, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 16628, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 0),
/* {'track': 1, 'velocity': 86, 't': 16640, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 16672, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 85, 't': 16704, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 85),
/* {'track': 1, 'velocity': 0, 't': 16736, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 106, 't': 16768, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 106),
/* {'track': 1, 'velocity': 66, 't': 16768, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 66),
/* {'track': 1, 'velocity': 70, 't': 16768, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 70),
/* {'track': 1, 'velocity': 67, 't': 16768, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 67),
/* {'track': 1, 'velocity': 0, 't': 16800, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 104, 't': 16832, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 104),
/* {'track': 1, 'velocity': 0, 't': 16864, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 16884, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 16884, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 16884, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 111, 't': 16896, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 111),
/* {'track': 1, 'velocity': 85, 't': 16896, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 85),
/* {'track': 1, 'velocity': 86, 't': 16896, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 86),
/* {'track': 1, 'velocity': 87, 't': 16896, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 87),
/* {'track': 1, 'velocity': 87, 't': 16896, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 87),
/* {'track': 1, 'velocity': 0, 't': 16928, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 91, 't': 16960, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 91),
/* {'track': 1, 'velocity': 0, 't': 16992, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 0, 't': 17012, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 17012, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 17012, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 17012, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 102, 't': 17024, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 102),
/* {'track': 1, 'velocity': 77, 't': 17024, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 77),
/* {'track': 1, 'velocity': 78, 't': 17024, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 78),
/* {'track': 1, 'velocity': 78, 't': 17024, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 78),
/* {'track': 1, 'velocity': 76, 't': 17024, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 76),
/* {'track': 1, 'velocity': 0, 't': 17056, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 86, 't': 17088, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 86),
/* {'track': 1, 'velocity': 0, 't': 17120, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 17140, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 17140, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 17140, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 17140, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 87, 't': 17152, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 87),
/* {'track': 1, 'velocity': 0, 't': 17184, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 84, 't': 17216, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 84),
/* {'track': 1, 'velocity': 0, 't': 17248, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 104, 't': 17280, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 104),
/* {'track': 1, 'velocity': 66, 't': 17280, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 66),
/* {'track': 1, 'velocity': 68, 't': 17280, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 68),
/* {'track': 1, 'velocity': 68, 't': 17280, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 68),
/* {'track': 1, 'velocity': 66, 't': 17280, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 66),
/* {'track': 1, 'velocity': 0, 't': 17312, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 105, 't': 17344, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 105),
/* {'track': 1, 'velocity': 0, 't': 17376, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 17396, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 17396, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 17396, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 17396, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 105, 't': 17408, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 105),
/* {'track': 1, 'velocity': 72, 't': 17408, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 72),
/* {'track': 1, 'velocity': 74, 't': 17408, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 74),
/* {'track': 1, 'velocity': 72, 't': 17408, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 72),
/* {'track': 1, 'velocity': 73, 't': 17408, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 73),
/* {'track': 1, 'velocity': 0, 't': 17440, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 88, 't': 17472, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 88),
/* {'track': 1, 'velocity': 0, 't': 17504, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 17524, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 17524, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 17524, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 17524, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 0),
/* {'track': 1, 'velocity': 99, 't': 17536, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 99),
/* {'track': 1, 'velocity': 74, 't': 17536, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 74),
/* {'track': 1, 'velocity': 75, 't': 17536, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 75),
/* {'track': 1, 'velocity': 75, 't': 17536, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 75),
/* {'track': 1, 'velocity': 74, 't': 17536, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 74),
/* {'track': 1, 'velocity': 0, 't': 17568, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 89, 't': 17600, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 89),
/* {'track': 1, 'velocity': 0, 't': 17632, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 17652, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 17652, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 17652, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 17652, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 0),
/* {'track': 1, 'velocity': 86, 't': 17664, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 17696, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 85, 't': 17728, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 85),
/* {'track': 1, 'velocity': 0, 't': 17760, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 105, 't': 17792, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 105),
/* {'track': 1, 'velocity': 67, 't': 17792, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 67),
/* {'track': 1, 'velocity': 66, 't': 17792, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 66),
/* {'track': 1, 'velocity': 69, 't': 17792, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 69),
/* {'track': 1, 'velocity': 69, 't': 17792, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 69),
/* {'track': 1, 'velocity': 0, 't': 17824, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 106, 't': 17856, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 106),
/* {'track': 1, 'velocity': 0, 't': 17888, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 17908, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 17908, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 17908, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 17908, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 0),
/* {'track': 1, 'velocity': 112, 't': 17920, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 112),
/* {'track': 1, 'velocity': 81, 't': 17920, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 81),
/* {'track': 1, 'velocity': 81, 't': 17920, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 81),
/* {'track': 1, 'velocity': 83, 't': 17920, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 83),
/* {'track': 1, 'velocity': 84, 't': 17920, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 84),
/* {'track': 1, 'velocity': 0, 't': 17952, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 94, 't': 17984, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 94),
/* {'track': 1, 'velocity': 0, 't': 18016, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 0, 't': 18036, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 18036, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 18036, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 18036, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 103, 't': 18048, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 103),
/* {'track': 1, 'velocity': 76, 't': 18048, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 76),
/* {'track': 1, 'velocity': 77, 't': 18048, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 77),
/* {'track': 1, 'velocity': 75, 't': 18048, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 75),
/* {'track': 1, 'velocity': 74, 't': 18048, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 74),
/* {'track': 1, 'velocity': 0, 't': 18080, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 88, 't': 18112, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 88),
/* {'track': 1, 'velocity': 0, 't': 18144, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 18164, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 18164, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 18164, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 18164, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 86, 't': 18176, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 18208, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 85, 't': 18240, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 85),
/* {'track': 1, 'velocity': 0, 't': 18272, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 105, 't': 18304, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 105),
/* {'track': 1, 'velocity': 68, 't': 18304, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 68),
/* {'track': 1, 'velocity': 67, 't': 18304, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 67),
/* {'track': 1, 'velocity': 67, 't': 18304, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 67),
/* {'track': 1, 'velocity': 69, 't': 18304, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 69),
/* {'track': 1, 'velocity': 0, 't': 18336, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 105, 't': 18368, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 105),
/* {'track': 1, 'velocity': 0, 't': 18382, 'channel': 2, 'pitch': 41} */
PAUSE(14),
NOTE(8, 41, 0),
/* {'track': 1, 'velocity': 0, 't': 18400, 'channel': 1, 'pitch': 84} */
PAUSE(18),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 18420, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 18420, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 18420, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 18420, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 113, 't': 18432, 'channel': 1, 'pitch': 89} */
PAUSE(12),
NOTE(0, 89, 113),
/* {'track': 1, 'velocity': 81, 't': 18432, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 81),
/* {'track': 1, 'velocity': 81, 't': 18432, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 81),
/* {'track': 1, 'velocity': 80, 't': 18432, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 80),
/* {'track': 1, 'velocity': 79, 't': 18432, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 79),
/* {'track': 1, 'velocity': 78, 't': 18432, 'channel': 2, 'pitch': 41} */
NOTE(12, 41, 78),
/* {'track': 1, 'velocity': 0, 't': 18464, 'channel': 1, 'pitch': 89} */
PAUSE(32),
NOTE(0, 89, 0),
/* {'track': 1, 'velocity': 94, 't': 18496, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 94),
/* {'track': 1, 'velocity': 0, 't': 18528, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 0, 't': 18548, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 18548, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 18548, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 18548, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 0),
/* {'track': 1, 'velocity': 101, 't': 18560, 'channel': 1, 'pitch': 89} */
PAUSE(12),
NOTE(0, 89, 101),
/* {'track': 1, 'velocity': 74, 't': 18560, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 74),
/* {'track': 1, 'velocity': 77, 't': 18560, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 77),
/* {'track': 1, 'velocity': 77, 't': 18560, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 77),
/* {'track': 1, 'velocity': 77, 't': 18560, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 77),
/* {'track': 1, 'velocity': 0, 't': 18592, 'channel': 1, 'pitch': 89} */
PAUSE(32),
NOTE(0, 89, 0),
/* {'track': 1, 'velocity': 83, 't': 18624, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 83),
/* {'track': 1, 'velocity': 0, 't': 18656, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 18676, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 18676, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 18676, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 18676, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 0),
/* {'track': 1, 'velocity': 83, 't': 18688, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 83),
/* {'track': 1, 'velocity': 0, 't': 18720, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 85, 't': 18752, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 85),
/* {'track': 1, 'velocity': 0, 't': 18784, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 105, 't': 18816, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 105),
/* {'track': 1, 'velocity': 67, 't': 18816, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 67),
/* {'track': 1, 'velocity': 68, 't': 18816, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 68),
/* {'track': 1, 'velocity': 66, 't': 18816, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 66),
/* {'track': 1, 'velocity': 0, 't': 18848, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 107, 't': 18880, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 107),
/* {'track': 1, 'velocity': 0, 't': 18912, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 18932, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 18932, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 18932, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 110, 't': 18944, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 110),
/* {'track': 1, 'velocity': 86, 't': 18944, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 86),
/* {'track': 1, 'velocity': 88, 't': 18944, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 88),
/* {'track': 1, 'velocity': 86, 't': 18944, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 86),
/* {'track': 1, 'velocity': 84, 't': 18944, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 84),
/* {'track': 1, 'velocity': 0, 't': 18976, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 93, 't': 19008, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 93),
/* {'track': 1, 'velocity': 0, 't': 19040, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 0, 't': 19060, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 19060, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 19060, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 19060, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 102, 't': 19072, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 102),
/* {'track': 1, 'velocity': 79, 't': 19072, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 79),
/* {'track': 1, 'velocity': 77, 't': 19072, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 77),
/* {'track': 1, 'velocity': 77, 't': 19072, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 77),
/* {'track': 1, 'velocity': 76, 't': 19072, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 76),
/* {'track': 1, 'velocity': 0, 't': 19104, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 86, 't': 19136, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 86),
/* {'track': 1, 'velocity': 0, 't': 19168, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 19188, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 19188, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 19188, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 19188, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 86, 't': 19200, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 19232, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 82, 't': 19264, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 82),
/* {'track': 1, 'velocity': 0, 't': 19296, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 104, 't': 19328, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 104),
/* {'track': 1, 'velocity': 70, 't': 19328, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 70),
/* {'track': 1, 'velocity': 68, 't': 19328, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 68),
/* {'track': 1, 'velocity': 69, 't': 19328, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 69),
/* {'track': 1, 'velocity': 66, 't': 19328, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 66),
/* {'track': 1, 'velocity': 0, 't': 19360, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 104, 't': 19392, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 104),
/* {'track': 1, 'velocity': 0, 't': 19424, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 19444, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 19444, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 19444, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 19444, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 108, 't': 19456, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 108),
/* {'track': 1, 'velocity': 72, 't': 19456, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 72),
/* {'track': 1, 'velocity': 71, 't': 19456, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 71),
/* {'track': 1, 'velocity': 71, 't': 19456, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 71),
/* {'track': 1, 'velocity': 73, 't': 19456, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 73),
/* {'track': 1, 'velocity': 0, 't': 19488, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 89, 't': 19520, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 89),
/* {'track': 1, 'velocity': 0, 't': 19552, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 19572, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 19572, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 19572, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 19572, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 0),
/* {'track': 1, 'velocity': 101, 't': 19584, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 101),
/* {'track': 1, 'velocity': 75, 't': 19584, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 75),
/* {'track': 1, 'velocity': 75, 't': 19584, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 75),
/* {'track': 1, 'velocity': 74, 't': 19584, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 74),
/* {'track': 1, 'velocity': 75, 't': 19584, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 75),
/* {'track': 1, 'velocity': 0, 't': 19616, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 88, 't': 19648, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 88),
/* {'track': 1, 'velocity': 0, 't': 19680, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 19700, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 19700, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 19700, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 19700, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 0),
/* {'track': 1, 'velocity': 89, 't': 19712, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 89),
/* {'track': 1, 'velocity': 0, 't': 19744, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 85, 't': 19776, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 85),
/* {'track': 1, 'velocity': 0, 't': 19808, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 104, 't': 19840, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 104),
/* {'track': 1, 'velocity': 69, 't': 19840, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 69),
/* {'track': 1, 'velocity': 66, 't': 19840, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 66),
/* {'track': 1, 'velocity': 66, 't': 19840, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 66),
/* {'track': 1, 'velocity': 67, 't': 19840, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 67),
/* {'track': 1, 'velocity': 0, 't': 19872, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 103, 't': 19904, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 103),
/* {'track': 1, 'velocity': 0, 't': 19936, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 19956, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 19956, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 19956, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 19956, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 0),
/* {'track': 1, 'velocity': 110, 't': 19968, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 110),
/* {'track': 1, 'velocity': 81, 't': 19968, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 81),
/* {'track': 1, 'velocity': 82, 't': 19968, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 82),
/* {'track': 1, 'velocity': 81, 't': 19968, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 81),
/* {'track': 1, 'velocity': 0, 't': 20000, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 84, 't': 20032, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 84),
/* {'track': 1, 'velocity': 0, 't': 20064, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 20084, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 20084, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 20084, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 108, 't': 20096, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 108),
/* {'track': 1, 'velocity': 78, 't': 20096, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 78),
/* {'track': 1, 'velocity': 76, 't': 20096, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 76),
/* {'track': 1, 'velocity': 78, 't': 20096, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 78),
/* {'track': 1, 'velocity': 0, 't': 20128, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 86, 't': 20160, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 86),
/* {'track': 1, 'velocity': 0, 't': 20192, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 20212, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 20212, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 20212, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 83, 't': 20224, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 83),
/* {'track': 1, 'velocity': 0, 't': 20256, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 85, 't': 20288, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 85),
/* {'track': 1, 'velocity': 0, 't': 20320, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 99, 't': 20352, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 99),
/* {'track': 1, 'velocity': 68, 't': 20352, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 68),
/* {'track': 1, 'velocity': 66, 't': 20352, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 66),
/* {'track': 1, 'velocity': 66, 't': 20352, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 66),
/* {'track': 1, 'velocity': 0, 't': 20384, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 105, 't': 20416, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 105),
/* {'track': 1, 'velocity': 0, 't': 20430, 'channel': 2, 'pitch': 41} */
PAUSE(14),
NOTE(8, 41, 0),
/* {'track': 1, 'velocity': 0, 't': 20448, 'channel': 1, 'pitch': 83} */
PAUSE(18),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 20468, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 20468, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 20468, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 106, 't': 20480, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 106),
/* {'track': 1, 'velocity': 70, 't': 20480, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 70),
/* {'track': 1, 'velocity': 67, 't': 20480, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 67),
/* {'track': 1, 'velocity': 68, 't': 20480, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 68),
/* {'track': 1, 'velocity': 69, 't': 20480, 'channel': 2, 'pitch': 60} */
NOTE(11, 60, 69),
/* {'track': 1, 'velocity': 93, 't': 20480, 'channel': 2, 'pitch': 48} */
NOTE(12, 48, 93),
/* {'track': 1, 'velocity': 0, 't': 20512, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 91, 't': 20544, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 91),
/* {'track': 1, 'velocity': 0, 't': 20576, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 20596, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 20596, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 20596, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 20596, 'channel': 2, 'pitch': 60} */
NOTE(11, 60, 0),
/* {'track': 1, 'velocity': 101, 't': 20608, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 101),
/* {'track': 1, 'velocity': 76, 't': 20608, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 76),
/* {'track': 1, 'velocity': 73, 't': 20608, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 73),
/* {'track': 1, 'velocity': 75, 't': 20608, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 75),
/* {'track': 1, 'velocity': 75, 't': 20608, 'channel': 2, 'pitch': 60} */
NOTE(11, 60, 75),
/* {'track': 1, 'velocity': 0, 't': 20640, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 82, 't': 20672, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 82),
/* {'track': 1, 'velocity': 0, 't': 20704, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 20724, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 20724, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 20724, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 20724, 'channel': 2, 'pitch': 60} */
NOTE(11, 60, 0),
/* {'track': 1, 'velocity': 87, 't': 20736, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 87),
/* {'track': 1, 'velocity': 0, 't': 20768, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 84, 't': 20800, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 84),
/* {'track': 1, 'velocity': 0, 't': 20832, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 105, 't': 20864, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 105),
/* {'track': 1, 'velocity': 67, 't': 20864, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 67),
/* {'track': 1, 'velocity': 67, 't': 20864, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 67),
/* {'track': 1, 'velocity': 68, 't': 20864, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 68),
/* {'track': 1, 'velocity': 0, 't': 20896, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 20928, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 104),
/* {'track': 1, 'velocity': 0, 't': 20960, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 20980, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 20980, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 20980, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 109, 't': 20992, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 109),
/* {'track': 1, 'velocity': 88, 't': 20992, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 88),
/* {'track': 1, 'velocity': 86, 't': 20992, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 86),
/* {'track': 1, 'velocity': 86, 't': 20992, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 86),
/* {'track': 1, 'velocity': 87, 't': 20992, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 87),
/* {'track': 1, 'velocity': 0, 't': 21024, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 91, 't': 21056, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 91),
/* {'track': 1, 'velocity': 0, 't': 21088, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 21108, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 21108, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 21108, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 21108, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 0),
/* {'track': 1, 'velocity': 100, 't': 21120, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 100),
/* {'track': 1, 'velocity': 79, 't': 21120, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 79),
/* {'track': 1, 'velocity': 77, 't': 21120, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 77),
/* {'track': 1, 'velocity': 76, 't': 21120, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 76),
/* {'track': 1, 'velocity': 77, 't': 21120, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 77),
/* {'track': 1, 'velocity': 0, 't': 21152, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 88, 't': 21184, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 88),
/* {'track': 1, 'velocity': 0, 't': 21216, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 21236, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 21236, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 21236, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 21236, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 0),
/* {'track': 1, 'velocity': 86, 't': 21248, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 86),
/* {'track': 1, 'velocity': 0, 't': 21280, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 86, 't': 21312, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 86),
/* {'track': 1, 'velocity': 0, 't': 21344, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 104, 't': 21376, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 104),
/* {'track': 1, 'velocity': 66, 't': 21376, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 66),
/* {'track': 1, 'velocity': 67, 't': 21376, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 67),
/* {'track': 1, 'velocity': 67, 't': 21376, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 67),
/* {'track': 1, 'velocity': 68, 't': 21376, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 68),
/* {'track': 1, 'velocity': 0, 't': 21408, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 21440, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 104),
/* {'track': 1, 'velocity': 0, 't': 21472, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 21492, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 21492, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 21492, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 21492, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 0),
/* {'track': 1, 'velocity': 107, 't': 21504, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 107),
/* {'track': 1, 'velocity': 71, 't': 21504, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 71),
/* {'track': 1, 'velocity': 71, 't': 21504, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 71),
/* {'track': 1, 'velocity': 72, 't': 21504, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 72),
/* {'track': 1, 'velocity': 74, 't': 21504, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 74),
/* {'track': 1, 'velocity': 0, 't': 21536, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 91, 't': 21568, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 91),
/* {'track': 1, 'velocity': 0, 't': 21600, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 21620, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 21620, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 21620, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 21620, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 0),
/* {'track': 1, 'velocity': 100, 't': 21632, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 100),
/* {'track': 1, 'velocity': 74, 't': 21632, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 74),
/* {'track': 1, 'velocity': 73, 't': 21632, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 73),
/* {'track': 1, 'velocity': 74, 't': 21632, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 74),
/* {'track': 1, 'velocity': 76, 't': 21632, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 76),
/* {'track': 1, 'velocity': 0, 't': 21664, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 91, 't': 21696, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 91),
/* {'track': 1, 'velocity': 0, 't': 21728, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 21748, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 21748, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 21748, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 21748, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 0),
/* {'track': 1, 'velocity': 88, 't': 21760, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 88),
/* {'track': 1, 'velocity': 0, 't': 21792, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 82, 't': 21824, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 82),
/* {'track': 1, 'velocity': 0, 't': 21856, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 103, 't': 21888, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 103),
/* {'track': 1, 'velocity': 66, 't': 21888, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 66),
/* {'track': 1, 'velocity': 68, 't': 21888, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 68),
/* {'track': 1, 'velocity': 67, 't': 21888, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 67),
/* {'track': 1, 'velocity': 69, 't': 21888, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 69),
/* {'track': 1, 'velocity': 0, 't': 21920, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 105, 't': 21952, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 105),
/* {'track': 1, 'velocity': 0, 't': 21966, 'channel': 2, 'pitch': 48} */
PAUSE(14),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 21984, 'channel': 1, 'pitch': 79} */
PAUSE(18),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 22004, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 22004, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 22004, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 22004, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 0),
/* {'track': 1, 'velocity': 111, 't': 22016, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 111),
/* {'track': 1, 'velocity': 83, 't': 22016, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 83),
/* {'track': 1, 'velocity': 81, 't': 22016, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 81),
/* {'track': 1, 'velocity': 83, 't': 22016, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 83),
/* {'track': 1, 'velocity': 83, 't': 22016, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 83),
/* {'track': 1, 'velocity': 0, 't': 22048, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 92, 't': 22080, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 92),
/* {'track': 1, 'velocity': 0, 't': 22112, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 22132, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 22132, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 22132, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 22132, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 0),
/* {'track': 1, 'velocity': 102, 't': 22144, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 102),
/* {'track': 1, 'velocity': 75, 't': 22144, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 75),
/* {'track': 1, 'velocity': 76, 't': 22144, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 76),
/* {'track': 1, 'velocity': 75, 't': 22144, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 75),
/* {'track': 1, 'velocity': 76, 't': 22144, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 76),
/* {'track': 1, 'velocity': 0, 't': 22176, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 85, 't': 22208, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 85),
/* {'track': 1, 'velocity': 0, 't': 22240, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 22260, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 22260, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 22260, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 22260, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 0),
/* {'track': 1, 'velocity': 87, 't': 22272, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 87),
/* {'track': 1, 'velocity': 0, 't': 22304, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 84, 't': 22336, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 84),
/* {'track': 1, 'velocity': 0, 't': 22368, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 104, 't': 22400, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 104),
/* {'track': 1, 'velocity': 66, 't': 22400, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 66),
/* {'track': 1, 'velocity': 68, 't': 22400, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 68),
/* {'track': 1, 'velocity': 69, 't': 22400, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 69),
/* {'track': 1, 'velocity': 67, 't': 22400, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 67),
/* {'track': 1, 'velocity': 0, 't': 22432, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 22464, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 104),
/* {'track': 1, 'velocity': 0, 't': 22496, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 22516, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 22516, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 22516, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 22516, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 0),
/* {'track': 1, 'velocity': 113, 't': 22528, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 113),
/* {'track': 1, 'velocity': 79, 't': 22528, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 79),
/* {'track': 1, 'velocity': 79, 't': 22528, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 79),
/* {'track': 1, 'velocity': 83, 't': 22528, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 83),
/* {'track': 1, 'velocity': 81, 't': 22528, 'channel': 2, 'pitch': 60} */
NOTE(11, 60, 81),
/* {'track': 1, 'velocity': 70, 't': 22528, 'channel': 2, 'pitch': 48} */
NOTE(12, 48, 70),
/* {'track': 1, 'velocity': 0, 't': 22560, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 94, 't': 22592, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 94),
/* {'track': 1, 'velocity': 0, 't': 22624, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 22644, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 22644, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 22644, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 22644, 'channel': 2, 'pitch': 60} */
NOTE(11, 60, 0),
/* {'track': 1, 'velocity': 101, 't': 22656, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 101),
/* {'track': 1, 'velocity': 75, 't': 22656, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 75),
/* {'track': 1, 'velocity': 77, 't': 22656, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 77),
/* {'track': 1, 'velocity': 76, 't': 22656, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 76),
/* {'track': 1, 'velocity': 75, 't': 22656, 'channel': 2, 'pitch': 60} */
NOTE(11, 60, 75),
/* {'track': 1, 'velocity': 0, 't': 22688, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 84, 't': 22720, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 84),
/* {'track': 1, 'velocity': 0, 't': 22752, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 22772, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 22772, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 22772, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 22772, 'channel': 2, 'pitch': 60} */
NOTE(11, 60, 0),
/* {'track': 1, 'velocity': 86, 't': 22784, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 86),
/* {'track': 1, 'velocity': 0, 't': 22816, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 84, 't': 22848, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 84),
/* {'track': 1, 'velocity': 0, 't': 22880, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 103, 't': 22912, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 103),
/* {'track': 1, 'velocity': 67, 't': 22912, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 67),
/* {'track': 1, 'velocity': 69, 't': 22912, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 69),
/* {'track': 1, 'velocity': 67, 't': 22912, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 67),
/* {'track': 1, 'velocity': 0, 't': 22944, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 107, 't': 22976, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 107),
/* {'track': 1, 'velocity': 0, 't': 23008, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 23028, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 23028, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 23028, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 110, 't': 23040, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 110),
/* {'track': 1, 'velocity': 87, 't': 23040, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 87),
/* {'track': 1, 'velocity': 85, 't': 23040, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 85),
/* {'track': 1, 'velocity': 84, 't': 23040, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 84),
/* {'track': 1, 'velocity': 85, 't': 23040, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 85),
/* {'track': 1, 'velocity': 0, 't': 23072, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 91, 't': 23104, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 91),
/* {'track': 1, 'velocity': 0, 't': 23136, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 23156, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 23156, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 23156, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 23156, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 0),
/* {'track': 1, 'velocity': 104, 't': 23168, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 104),
/* {'track': 1, 'velocity': 78, 't': 23168, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 78),
/* {'track': 1, 'velocity': 78, 't': 23168, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 78),
/* {'track': 1, 'velocity': 77, 't': 23168, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 77),
/* {'track': 1, 'velocity': 77, 't': 23168, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 77),
/* {'track': 1, 'velocity': 0, 't': 23200, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 87, 't': 23232, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 87),
/* {'track': 1, 'velocity': 0, 't': 23264, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 23284, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 23284, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 23284, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 23284, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 0),
/* {'track': 1, 'velocity': 86, 't': 23296, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 86),
/* {'track': 1, 'velocity': 0, 't': 23328, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 84, 't': 23360, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 84),
/* {'track': 1, 'velocity': 0, 't': 23392, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 105, 't': 23424, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 105),
/* {'track': 1, 'velocity': 69, 't': 23424, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 69),
/* {'track': 1, 'velocity': 68, 't': 23424, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 68),
/* {'track': 1, 'velocity': 70, 't': 23424, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 70),
/* {'track': 1, 'velocity': 68, 't': 23424, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 68),
/* {'track': 1, 'velocity': 0, 't': 23456, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 105, 't': 23488, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 105),
/* {'track': 1, 'velocity': 0, 't': 23520, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 23540, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 23540, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 23540, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 23540, 'channel': 2, 'pitch': 59} */
NOTE(11, 59, 0),
/* {'track': 1, 'velocity': 105, 't': 23552, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 105),
/* {'track': 1, 'velocity': 73, 't': 23552, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 73),
/* {'track': 1, 'velocity': 73, 't': 23552, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 73),
/* {'track': 1, 'velocity': 72, 't': 23552, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 72),
/* {'track': 1, 'velocity': 73, 't': 23552, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 73),
/* {'track': 1, 'velocity': 0, 't': 23584, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 89, 't': 23616, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 89),
/* {'track': 1, 'velocity': 0, 't': 23648, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 23668, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 23668, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 23668, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 23668, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 0),
/* {'track': 1, 'velocity': 103, 't': 23680, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 103),
/* {'track': 1, 'velocity': 75, 't': 23680, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 75),
/* {'track': 1, 'velocity': 74, 't': 23680, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 74),
/* {'track': 1, 'velocity': 74, 't': 23680, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 74),
/* {'track': 1, 'velocity': 76, 't': 23680, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 76),
/* {'track': 1, 'velocity': 0, 't': 23712, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 91, 't': 23744, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 91),
/* {'track': 1, 'velocity': 0, 't': 23776, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 23796, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 23796, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 23796, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 23796, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 0),
/* {'track': 1, 'velocity': 86, 't': 23808, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 86),
/* {'track': 1, 'velocity': 0, 't': 23840, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 82, 't': 23872, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 82),
/* {'track': 1, 'velocity': 0, 't': 23904, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 104, 't': 23936, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 104),
/* {'track': 1, 'velocity': 68, 't': 23936, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 68),
/* {'track': 1, 'velocity': 69, 't': 23936, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 69),
/* {'track': 1, 'velocity': 68, 't': 23936, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 68),
/* {'track': 1, 'velocity': 70, 't': 23936, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 70),
/* {'track': 1, 'velocity': 0, 't': 23968, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 107, 't': 24000, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 107),
/* {'track': 1, 'velocity': 0, 't': 24014, 'channel': 2, 'pitch': 48} */
PAUSE(14),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 24032, 'channel': 1, 'pitch': 79} */
PAUSE(18),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 24052, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 24052, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 24052, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 24052, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 0),
/* {'track': 1, 'velocity': 113, 't': 24064, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 113),
/* {'track': 1, 'velocity': 82, 't': 24064, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 82),
/* {'track': 1, 'velocity': 83, 't': 24064, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 83),
/* {'track': 1, 'velocity': 82, 't': 24064, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 82),
/* {'track': 1, 'velocity': 0, 't': 24096, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 86, 't': 24128, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 86),
/* {'track': 1, 'velocity': 0, 't': 24160, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 24180, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 24180, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 24180, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 106, 't': 24192, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 106),
/* {'track': 1, 'velocity': 75, 't': 24192, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 75),
/* {'track': 1, 'velocity': 75, 't': 24192, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 75),
/* {'track': 1, 'velocity': 76, 't': 24192, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 76),
/* {'track': 1, 'velocity': 0, 't': 24224, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 83, 't': 24256, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 83),
/* {'track': 1, 'velocity': 0, 't': 24288, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 24308, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 24308, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 24308, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 86, 't': 24320, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 24352, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 85, 't': 24384, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 85),
/* {'track': 1, 'velocity': 0, 't': 24416, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 101, 't': 24448, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 101),
/* {'track': 1, 'velocity': 67, 't': 24448, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 67),
/* {'track': 1, 'velocity': 69, 't': 24448, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 69),
/* {'track': 1, 'velocity': 68, 't': 24448, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 68),
/* {'track': 1, 'velocity': 0, 't': 24480, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 105, 't': 24512, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 105),
/* {'track': 1, 'velocity': 0, 't': 24544, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 24564, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 24564, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 24564, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 103, 't': 24576, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 103),
/* {'track': 1, 'velocity': 69, 't': 24576, 'channel': 2, 'pitch': 47} */
NOTE(8, 47, 69),
/* {'track': 1, 'velocity': 67, 't': 24576, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 67),
/* {'track': 1, 'velocity': 68, 't': 24576, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 68),
/* {'track': 1, 'velocity': 69, 't': 24576, 'channel': 2, 'pitch': 43} */
NOTE(11, 43, 69),
/* {'track': 1, 'velocity': 0, 't': 24608, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 93, 't': 24640, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 93),
/* {'track': 1, 'velocity': 0, 't': 24672, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 24692, 'channel': 2, 'pitch': 47} */
PAUSE(20),
NOTE(8, 47, 0),
/* {'track': 1, 'velocity': 0, 't': 24692, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 24692, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 100, 't': 24704, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 100),
/* {'track': 1, 'velocity': 72, 't': 24704, 'channel': 2, 'pitch': 47} */
NOTE(8, 47, 72),
/* {'track': 1, 'velocity': 76, 't': 24704, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 76),
/* {'track': 1, 'velocity': 74, 't': 24704, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 74),
/* {'track': 1, 'velocity': 0, 't': 24736, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 86, 't': 24768, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 24800, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 24820, 'channel': 2, 'pitch': 47} */
PAUSE(20),
NOTE(8, 47, 0),
/* {'track': 1, 'velocity': 0, 't': 24820, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 24820, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 85, 't': 24832, 'channel': 1, 'pitch': 71} */
PAUSE(12),
NOTE(0, 71, 85),
/* {'track': 1, 'velocity': 0, 't': 24864, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 83, 't': 24896, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 83),
/* {'track': 1, 'velocity': 0, 't': 24928, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 104, 't': 24960, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 104),
/* {'track': 1, 'velocity': 66, 't': 24960, 'channel': 2, 'pitch': 47} */
NOTE(8, 47, 66),
/* {'track': 1, 'velocity': 68, 't': 24960, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 68),
/* {'track': 1, 'velocity': 0, 't': 24992, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 104, 't': 25024, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 104),
/* {'track': 1, 'velocity': 0, 't': 25056, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 25076, 'channel': 2, 'pitch': 47} */
PAUSE(20),
NOTE(8, 47, 0),
/* {'track': 1, 'velocity': 0, 't': 25076, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 0),
/* {'track': 1, 'velocity': 113, 't': 25088, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 113),
/* {'track': 1, 'velocity': 88, 't': 25088, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 88),
/* {'track': 1, 'velocity': 87, 't': 25088, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 87),
/* {'track': 1, 'velocity': 87, 't': 25088, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 87),
/* {'track': 1, 'velocity': 0, 't': 25120, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 93, 't': 25152, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 93),
/* {'track': 1, 'velocity': 0, 't': 25184, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 25204, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 25204, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 25204, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 102, 't': 25216, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 102),
/* {'track': 1, 'velocity': 77, 't': 25216, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 77),
/* {'track': 1, 'velocity': 76, 't': 25216, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 76),
/* {'track': 1, 'velocity': 76, 't': 25216, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 76),
/* {'track': 1, 'velocity': 0, 't': 25248, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 86, 't': 25280, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 86),
/* {'track': 1, 'velocity': 0, 't': 25312, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 25332, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 25332, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 25332, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 84, 't': 25344, 'channel': 1, 'pitch': 72} */
PAUSE(12),
NOTE(0, 72, 84),
/* {'track': 1, 'velocity': 0, 't': 25376, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 86, 't': 25408, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 86),
/* {'track': 1, 'velocity': 0, 't': 25440, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 104, 't': 25472, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 104),
/* {'track': 1, 'velocity': 68, 't': 25472, 'channel': 2, 'pitch': 48} */
NOTE(8, 48, 68),
/* {'track': 1, 'velocity': 69, 't': 25472, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 69),
/* {'track': 1, 'velocity': 68, 't': 25472, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 68),
/* {'track': 1, 'velocity': 0, 't': 25504, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 105, 't': 25536, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 105),
/* {'track': 1, 'velocity': 0, 't': 25568, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 25588, 'channel': 2, 'pitch': 48} */
PAUSE(20),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 25588, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 25588, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 108, 't': 25600, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 108),
/* {'track': 1, 'velocity': 77, 't': 25600, 'channel': 2, 'pitch': 47} */
NOTE(8, 47, 77),
/* {'track': 1, 'velocity': 75, 't': 25600, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 75),
/* {'track': 1, 'velocity': 76, 't': 25600, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 76),
/* {'track': 1, 'velocity': 0, 't': 25632, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 91, 't': 25664, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 91),
/* {'track': 1, 'velocity': 0, 't': 25696, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 25716, 'channel': 2, 'pitch': 47} */
PAUSE(20),
NOTE(8, 47, 0),
/* {'track': 1, 'velocity': 0, 't': 25716, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 25716, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 99, 't': 25728, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 99),
/* {'track': 1, 'velocity': 77, 't': 25728, 'channel': 2, 'pitch': 47} */
NOTE(8, 47, 77),
/* {'track': 1, 'velocity': 77, 't': 25728, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 77),
/* {'track': 1, 'velocity': 74, 't': 25728, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 74),
/* {'track': 1, 'velocity': 0, 't': 25760, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 86, 't': 25792, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 25824, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 25844, 'channel': 2, 'pitch': 47} */
PAUSE(20),
NOTE(8, 47, 0),
/* {'track': 1, 'velocity': 0, 't': 25844, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 25844, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 84, 't': 25856, 'channel': 1, 'pitch': 71} */
PAUSE(12),
NOTE(0, 71, 84),
/* {'track': 1, 'velocity': 0, 't': 25888, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 85, 't': 25920, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 85),
/* {'track': 1, 'velocity': 0, 't': 25952, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 103, 't': 25984, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 103),
/* {'track': 1, 'velocity': 67, 't': 25984, 'channel': 2, 'pitch': 47} */
NOTE(8, 47, 67),
/* {'track': 1, 'velocity': 66, 't': 25984, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 66),
/* {'track': 1, 'velocity': 68, 't': 25984, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 68),
/* {'track': 1, 'velocity': 0, 't': 26016, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 103, 't': 26048, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 103),
/* {'track': 1, 'velocity': 0, 't': 26062, 'channel': 2, 'pitch': 43} */
PAUSE(14),
NOTE(8, 43, 0),
/* {'track': 1, 'velocity': 0, 't': 26080, 'channel': 1, 'pitch': 74} */
PAUSE(18),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 26100, 'channel': 2, 'pitch': 47} */
PAUSE(20),
NOTE(8, 47, 0),
/* {'track': 1, 'velocity': 0, 't': 26100, 'channel': 2, 'pitch': 50} */
NOTE(9, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 26100, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 116, 't': 26112, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 116),
/* {'track': 1, 'velocity': 77, 't': 26112, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 77),
/* {'track': 1, 'velocity': 75, 't': 26112, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 75),
/* {'track': 1, 'velocity': 77, 't': 26112, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 77),
/* {'track': 1, 'velocity': 0, 't': 26144, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 95, 't': 26176, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 95),
/* {'track': 1, 'velocity': 0, 't': 26208, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 26228, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 26228, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 26228, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 101, 't': 26240, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 101),
/* {'track': 1, 'velocity': 75, 't': 26240, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 75),
/* {'track': 1, 'velocity': 77, 't': 26240, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 77),
/* {'track': 1, 'velocity': 77, 't': 26240, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 77),
/* {'track': 1, 'velocity': 0, 't': 26272, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 84, 't': 26304, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 84),
/* {'track': 1, 'velocity': 0, 't': 26336, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 26356, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 26356, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 26356, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 84, 't': 26368, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 84),
/* {'track': 1, 'velocity': 0, 't': 26400, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 84, 't': 26432, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 84),
/* {'track': 1, 'velocity': 0, 't': 26464, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 105, 't': 26496, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 105),
/* {'track': 1, 'velocity': 67, 't': 26496, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 67),
/* {'track': 1, 'velocity': 66, 't': 26496, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 66),
/* {'track': 1, 'velocity': 69, 't': 26496, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 69),
/* {'track': 1, 'velocity': 0, 't': 26528, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 104, 't': 26560, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 104),
/* {'track': 1, 'velocity': 0, 't': 26592, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 26612, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 26612, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 26612, 'channel': 2, 'pitch': 55} */
NOTE(10, 55, 0),
/* {'track': 1, 'velocity': 115, 't': 26624, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 115),
/* {'track': 1, 'velocity': 82, 't': 26624, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 82),
/* {'track': 1, 'velocity': 80, 't': 26624, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 80),
/* {'track': 1, 'velocity': 83, 't': 26624, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 83),
/* {'track': 1, 'velocity': 70, 't': 26624, 'channel': 2, 'pitch': 55} */
NOTE(11, 55, 70),
/* {'track': 1, 'velocity': 0, 't': 26656, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 91, 't': 26688, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 91),
/* {'track': 1, 'velocity': 0, 't': 26720, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 26740, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 26740, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 26740, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 100, 't': 26752, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 100),
/* {'track': 1, 'velocity': 75, 't': 26752, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 75),
/* {'track': 1, 'velocity': 74, 't': 26752, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 74),
/* {'track': 1, 'velocity': 75, 't': 26752, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 75),
/* {'track': 1, 'velocity': 0, 't': 26784, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 83, 't': 26816, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 83),
/* {'track': 1, 'velocity': 0, 't': 26848, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 26868, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 26868, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 26868, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 85, 't': 26880, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 85),
/* {'track': 1, 'velocity': 0, 't': 26912, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 83, 't': 26944, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 83),
/* {'track': 1, 'velocity': 0, 't': 26976, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 106, 't': 27008, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 106),
/* {'track': 1, 'velocity': 67, 't': 27008, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 67),
/* {'track': 1, 'velocity': 66, 't': 27008, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 66),
/* {'track': 1, 'velocity': 69, 't': 27008, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 69),
/* {'track': 1, 'velocity': 0, 't': 27040, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 104, 't': 27072, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 104),
/* {'track': 1, 'velocity': 0, 't': 27104, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 27124, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 27124, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 27124, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 112, 't': 27136, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 112),
/* {'track': 1, 'velocity': 76, 't': 27136, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 76),
/* {'track': 1, 'velocity': 78, 't': 27136, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 78),
/* {'track': 1, 'velocity': 79, 't': 27136, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 79),
/* {'track': 1, 'velocity': 0, 't': 27168, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 93, 't': 27200, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 93),
/* {'track': 1, 'velocity': 0, 't': 27232, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 27252, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 27252, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 27252, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 102, 't': 27264, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 102),
/* {'track': 1, 'velocity': 75, 't': 27264, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 75),
/* {'track': 1, 'velocity': 75, 't': 27264, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 75),
/* {'track': 1, 'velocity': 76, 't': 27264, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 76),
/* {'track': 1, 'velocity': 0, 't': 27296, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 86, 't': 27328, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 86),
/* {'track': 1, 'velocity': 0, 't': 27360, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 27380, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 27380, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 27380, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 85, 't': 27392, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 85),
/* {'track': 1, 'velocity': 0, 't': 27424, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 83, 't': 27456, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 83),
/* {'track': 1, 'velocity': 0, 't': 27488, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 103, 't': 27520, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 103),
/* {'track': 1, 'velocity': 66, 't': 27520, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 66),
/* {'track': 1, 'velocity': 66, 't': 27520, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 66),
/* {'track': 1, 'velocity': 70, 't': 27520, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 70),
/* {'track': 1, 'velocity': 0, 't': 27552, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 103, 't': 27584, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 103),
/* {'track': 1, 'velocity': 0, 't': 27598, 'channel': 2, 'pitch': 55} */
PAUSE(14),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 27616, 'channel': 1, 'pitch': 76} */
PAUSE(18),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 27636, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 27636, 'channel': 2, 'pitch': 52} */
NOTE(9, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 27636, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 117, 't': 27648, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 117),
/* {'track': 1, 'velocity': 79, 't': 27648, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 79),
/* {'track': 1, 'velocity': 78, 't': 27648, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 78),
/* {'track': 1, 'velocity': 77, 't': 27648, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 77),
/* {'track': 1, 'velocity': 69, 't': 27648, 'channel': 2, 'pitch': 53} */
NOTE(11, 53, 69),
/* {'track': 1, 'velocity': 0, 't': 27680, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 83, 't': 27712, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 83),
/* {'track': 1, 'velocity': 0, 't': 27744, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 27764, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 27764, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 27764, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 107, 't': 27776, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 107),
/* {'track': 1, 'velocity': 76, 't': 27776, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 76),
/* {'track': 1, 'velocity': 76, 't': 27776, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 76),
/* {'track': 1, 'velocity': 77, 't': 27776, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 77),
/* {'track': 1, 'velocity': 0, 't': 27808, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 83, 't': 27840, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 83),
/* {'track': 1, 'velocity': 0, 't': 27872, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 27892, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 27892, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 27892, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 84, 't': 27904, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 84),
/* {'track': 1, 'velocity': 0, 't': 27936, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 87, 't': 27968, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 87),
/* {'track': 1, 'velocity': 0, 't': 28000, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 103, 't': 28032, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 103),
/* {'track': 1, 'velocity': 70, 't': 28032, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 70),
/* {'track': 1, 'velocity': 67, 't': 28032, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 67),
/* {'track': 1, 'velocity': 68, 't': 28032, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 68),
/* {'track': 1, 'velocity': 0, 't': 28064, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 103, 't': 28096, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 103),
/* {'track': 1, 'velocity': 0, 't': 28110, 'channel': 2, 'pitch': 53} */
PAUSE(14),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 28128, 'channel': 1, 'pitch': 77} */
PAUSE(18),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 28148, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 28148, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 28148, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 118, 't': 28160, 'channel': 1, 'pitch': 85} */
PAUSE(12),
NOTE(0, 85, 118),
/* {'track': 1, 'velocity': 78, 't': 28160, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 78),
/* {'track': 1, 'velocity': 76, 't': 28160, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 76),
/* {'track': 1, 'velocity': 76, 't': 28160, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 76),
/* {'track': 1, 'velocity': 72, 't': 28160, 'channel': 2, 'pitch': 52} */
NOTE(11, 52, 72),
/* {'track': 1, 'velocity': 0, 't': 28192, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 88, 't': 28224, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 88),
/* {'track': 1, 'velocity': 0, 't': 28256, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 28276, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 28276, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 28276, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 104, 't': 28288, 'channel': 1, 'pitch': 85} */
PAUSE(12),
NOTE(0, 85, 104),
/* {'track': 1, 'velocity': 76, 't': 28288, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 76),
/* {'track': 1, 'velocity': 76, 't': 28288, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 76),
/* {'track': 1, 'velocity': 76, 't': 28288, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 76),
/* {'track': 1, 'velocity': 0, 't': 28320, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 86, 't': 28352, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 28384, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 28404, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 28404, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 28404, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 89, 't': 28416, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 89),
/* {'track': 1, 'velocity': 0, 't': 28448, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 81, 't': 28480, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 81),
/* {'track': 1, 'velocity': 0, 't': 28512, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 109, 't': 28544, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 109),
/* {'track': 1, 'velocity': 68, 't': 28544, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 68),
/* {'track': 1, 'velocity': 70, 't': 28544, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 70),
/* {'track': 1, 'velocity': 69, 't': 28544, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 69),
/* {'track': 1, 'velocity': 0, 't': 28576, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 105, 't': 28608, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 105),
/* {'track': 1, 'velocity': 0, 't': 28622, 'channel': 2, 'pitch': 52} */
PAUSE(14),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 28640, 'channel': 1, 'pitch': 81} */
PAUSE(18),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 28660, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 28660, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 28660, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 114, 't': 28672, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 114),
/* {'track': 1, 'velocity': 78, 't': 28672, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 78),
/* {'track': 1, 'velocity': 76, 't': 28672, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 76),
/* {'track': 1, 'velocity': 72, 't': 28672, 'channel': 2, 'pitch': 50} */
NOTE(10, 50, 72),
/* {'track': 1, 'velocity': 0, 't': 28704, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 91, 't': 28736, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 91),
/* {'track': 1, 'velocity': 0, 't': 28768, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 28788, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 28788, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 101, 't': 28800, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 101),
/* {'track': 1, 'velocity': 78, 't': 28800, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 78),
/* {'track': 1, 'velocity': 75, 't': 28800, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 75),
/* {'track': 1, 'velocity': 0, 't': 28832, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 84, 't': 28864, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 84),
/* {'track': 1, 'velocity': 0, 't': 28896, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 28916, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 28916, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 83, 't': 28928, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 83),
/* {'track': 1, 'velocity': 0, 't': 28960, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 83, 't': 28992, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 83),
/* {'track': 1, 'velocity': 0, 't': 29024, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 102, 't': 29056, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 102),
/* {'track': 1, 'velocity': 70, 't': 29056, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 70),
/* {'track': 1, 'velocity': 69, 't': 29056, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 69),
/* {'track': 1, 'velocity': 0, 't': 29088, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 105, 't': 29120, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 105),
/* {'track': 1, 'velocity': 0, 't': 29152, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 29172, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 29172, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 113, 't': 29184, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 113),
/* {'track': 1, 'velocity': 88, 't': 29184, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 88),
/* {'track': 1, 'velocity': 87, 't': 29184, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 87),
/* {'track': 1, 'velocity': 0, 't': 29216, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 94, 't': 29248, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 94),
/* {'track': 1, 'velocity': 0, 't': 29280, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 29300, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 29300, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 99, 't': 29312, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 99),
/* {'track': 1, 'velocity': 76, 't': 29312, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 76),
/* {'track': 1, 'velocity': 77, 't': 29312, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 77),
/* {'track': 1, 'velocity': 0, 't': 29344, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 86, 't': 29376, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 29408, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 29428, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 29428, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 85, 't': 29440, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 85),
/* {'track': 1, 'velocity': 0, 't': 29472, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 86, 't': 29504, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 29536, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 104, 't': 29568, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 104),
/* {'track': 1, 'velocity': 69, 't': 29568, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 69),
/* {'track': 1, 'velocity': 67, 't': 29568, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 67),
/* {'track': 1, 'velocity': 0, 't': 29600, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 109, 't': 29632, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 109),
/* {'track': 1, 'velocity': 0, 't': 29664, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 29684, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 29684, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 108, 't': 29696, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 108),
/* {'track': 1, 'velocity': 84, 't': 29696, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 84),
/* {'track': 1, 'velocity': 82, 't': 29696, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 82),
/* {'track': 1, 'velocity': 83, 't': 29696, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 83),
/* {'track': 1, 'velocity': 0, 't': 29728, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 88, 't': 29760, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 88),
/* {'track': 1, 'velocity': 0, 't': 29792, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 29812, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 29812, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 29812, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 101, 't': 29824, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 101),
/* {'track': 1, 'velocity': 77, 't': 29824, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 77),
/* {'track': 1, 'velocity': 77, 't': 29824, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 77),
/* {'track': 1, 'velocity': 76, 't': 29824, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 76),
/* {'track': 1, 'velocity': 0, 't': 29856, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 88, 't': 29888, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 88),
/* {'track': 1, 'velocity': 0, 't': 29920, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 29940, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 29940, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 29940, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 85, 't': 29952, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 85),
/* {'track': 1, 'velocity': 0, 't': 29984, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 86, 't': 30016, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 30048, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 102, 't': 30080, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 102),
/* {'track': 1, 'velocity': 69, 't': 30080, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 69),
/* {'track': 1, 'velocity': 68, 't': 30080, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 68),
/* {'track': 1, 'velocity': 69, 't': 30080, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 69),
/* {'track': 1, 'velocity': 0, 't': 30112, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 105, 't': 30144, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 105),
/* {'track': 1, 'velocity': 0, 't': 30158, 'channel': 2, 'pitch': 50} */
PAUSE(14),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 30176, 'channel': 1, 'pitch': 81} */
PAUSE(18),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 30196, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 30196, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 30196, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 109, 't': 30208, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 109),
/* {'track': 1, 'velocity': 83, 't': 30208, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 83),
/* {'track': 1, 'velocity': 81, 't': 30208, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 81),
/* {'track': 1, 'velocity': 81, 't': 30208, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 81),
/* {'track': 1, 'velocity': 0, 't': 30240, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 91, 't': 30272, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 91),
/* {'track': 1, 'velocity': 0, 't': 30304, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 30324, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 30324, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 30324, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 99, 't': 30336, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 99),
/* {'track': 1, 'velocity': 74, 't': 30336, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 74),
/* {'track': 1, 'velocity': 75, 't': 30336, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 75),
/* {'track': 1, 'velocity': 75, 't': 30336, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 75),
/* {'track': 1, 'velocity': 0, 't': 30368, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 86, 't': 30400, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 30432, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 30452, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 30452, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 30452, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 85, 't': 30464, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 85),
/* {'track': 1, 'velocity': 0, 't': 30496, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 85, 't': 30528, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 85),
/* {'track': 1, 'velocity': 0, 't': 30560, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 101, 't': 30592, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 101),
/* {'track': 1, 'velocity': 70, 't': 30592, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 70),
/* {'track': 1, 'velocity': 67, 't': 30592, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 67),
/* {'track': 1, 'velocity': 69, 't': 30592, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 69),
/* {'track': 1, 'velocity': 0, 't': 30624, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 106, 't': 30656, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 106),
/* {'track': 1, 'velocity': 0, 't': 30688, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 30708, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 30708, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 30708, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 106, 't': 30720, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 106),
/* {'track': 1, 'velocity': 75, 't': 30720, 'channel': 2, 'pitch': 51} */
NOTE(8, 51, 75),
/* {'track': 1, 'velocity': 75, 't': 30720, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 75),
/* {'track': 1, 'velocity': 75, 't': 30720, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 75),
/* {'track': 1, 'velocity': 72, 't': 30720, 'channel': 2, 'pitch': 57} */
NOTE(11, 57, 72),
/* {'track': 1, 'velocity': 0, 't': 30752, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 93, 't': 30784, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 93),
/* {'track': 1, 'velocity': 0, 't': 30816, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 30836, 'channel': 2, 'pitch': 51} */
PAUSE(20),
NOTE(8, 51, 0),
/* {'track': 1, 'velocity': 0, 't': 30836, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 30836, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 98, 't': 30848, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 98),
/* {'track': 1, 'velocity': 74, 't': 30848, 'channel': 2, 'pitch': 51} */
NOTE(8, 51, 74),
/* {'track': 1, 'velocity': 75, 't': 30848, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 75),
/* {'track': 1, 'velocity': 76, 't': 30848, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 76),
/* {'track': 1, 'velocity': 0, 't': 30880, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 85, 't': 30912, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 85),
/* {'track': 1, 'velocity': 0, 't': 30944, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 30964, 'channel': 2, 'pitch': 51} */
PAUSE(20),
NOTE(8, 51, 0),
/* {'track': 1, 'velocity': 0, 't': 30964, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 30964, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 84, 't': 30976, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 84),
/* {'track': 1, 'velocity': 0, 't': 31008, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 82, 't': 31040, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 82),
/* {'track': 1, 'velocity': 0, 't': 31072, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 103, 't': 31104, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 103),
/* {'track': 1, 'velocity': 69, 't': 31104, 'channel': 2, 'pitch': 51} */
NOTE(8, 51, 69),
/* {'track': 1, 'velocity': 69, 't': 31104, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 69),
/* {'track': 1, 'velocity': 66, 't': 31104, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 66),
/* {'track': 1, 'velocity': 0, 't': 31136, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 106, 't': 31168, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 106),
/* {'track': 1, 'velocity': 0, 't': 31200, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 31220, 'channel': 2, 'pitch': 51} */
PAUSE(20),
NOTE(8, 51, 0),
/* {'track': 1, 'velocity': 0, 't': 31220, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 31220, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 114, 't': 31232, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 114),
/* {'track': 1, 'velocity': 77, 't': 31232, 'channel': 2, 'pitch': 51} */
NOTE(8, 51, 77),
/* {'track': 1, 'velocity': 75, 't': 31232, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 75),
/* {'track': 1, 'velocity': 79, 't': 31232, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 79),
/* {'track': 1, 'velocity': 0, 't': 31264, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 92, 't': 31296, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 92),
/* {'track': 1, 'velocity': 0, 't': 31328, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 31348, 'channel': 2, 'pitch': 51} */
PAUSE(20),
NOTE(8, 51, 0),
/* {'track': 1, 'velocity': 0, 't': 31348, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 31348, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 99, 't': 31360, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 99),
/* {'track': 1, 'velocity': 74, 't': 31360, 'channel': 2, 'pitch': 51} */
NOTE(8, 51, 74),
/* {'track': 1, 'velocity': 78, 't': 31360, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 78),
/* {'track': 1, 'velocity': 74, 't': 31360, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 74),
/* {'track': 1, 'velocity': 0, 't': 31392, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 86, 't': 31424, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 86),
/* {'track': 1, 'velocity': 0, 't': 31456, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 31476, 'channel': 2, 'pitch': 51} */
PAUSE(20),
NOTE(8, 51, 0),
/* {'track': 1, 'velocity': 0, 't': 31476, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 31476, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 87, 't': 31488, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 87),
/* {'track': 1, 'velocity': 0, 't': 31520, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 82, 't': 31552, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 82),
/* {'track': 1, 'velocity': 0, 't': 31584, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 102, 't': 31616, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 102),
/* {'track': 1, 'velocity': 66, 't': 31616, 'channel': 2, 'pitch': 51} */
NOTE(8, 51, 66),
/* {'track': 1, 'velocity': 68, 't': 31616, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 68),
/* {'track': 1, 'velocity': 66, 't': 31616, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 66),
/* {'track': 1, 'velocity': 0, 't': 31648, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 104, 't': 31680, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 104),
/* {'track': 1, 'velocity': 0, 't': 31694, 'channel': 2, 'pitch': 57} */
PAUSE(14),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 31712, 'channel': 1, 'pitch': 78} */
PAUSE(18),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 31732, 'channel': 2, 'pitch': 51} */
PAUSE(20),
NOTE(8, 51, 0),
/* {'track': 1, 'velocity': 0, 't': 31732, 'channel': 2, 'pitch': 54} */
NOTE(9, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 31732, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 118, 't': 31744, 'channel': 1, 'pitch': 85} */
PAUSE(12),
NOTE(0, 85, 118),
/* {'track': 1, 'velocity': 76, 't': 31744, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 76),
/* {'track': 1, 'velocity': 79, 't': 31744, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 79),
/* {'track': 1, 'velocity': 78, 't': 31744, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 78),
/* {'track': 1, 'velocity': 69, 't': 31744, 'channel': 2, 'pitch': 55} */
NOTE(11, 55, 69),
/* {'track': 1, 'velocity': 0, 't': 31776, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 83, 't': 31808, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 83),
/* {'track': 1, 'velocity': 0, 't': 31840, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 31860, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 31860, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 31860, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 107, 't': 31872, 'channel': 1, 'pitch': 85} */
PAUSE(12),
NOTE(0, 85, 107),
/* {'track': 1, 'velocity': 77, 't': 31872, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 77),
/* {'track': 1, 'velocity': 75, 't': 31872, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 75),
/* {'track': 1, 'velocity': 77, 't': 31872, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 77),
/* {'track': 1, 'velocity': 0, 't': 31904, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 82, 't': 31936, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 82),
/* {'track': 1, 'velocity': 0, 't': 31968, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 31988, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 31988, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 31988, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 84, 't': 32000, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 84),
/* {'track': 1, 'velocity': 0, 't': 32032, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 85, 't': 32064, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 85),
/* {'track': 1, 'velocity': 0, 't': 32096, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 103, 't': 32128, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 103),
/* {'track': 1, 'velocity': 67, 't': 32128, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 67),
/* {'track': 1, 'velocity': 70, 't': 32128, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 70),
/* {'track': 1, 'velocity': 66, 't': 32128, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 66),
/* {'track': 1, 'velocity': 0, 't': 32160, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 32192, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 104),
/* {'track': 1, 'velocity': 0, 't': 32206, 'channel': 2, 'pitch': 55} */
PAUSE(14),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 32224, 'channel': 1, 'pitch': 79} */
PAUSE(18),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 32244, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 32244, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 32244, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 119, 't': 32256, 'channel': 1, 'pitch': 87} */
PAUSE(12),
NOTE(0, 87, 119),
/* {'track': 1, 'velocity': 78, 't': 32256, 'channel': 2, 'pitch': 54} */
NOTE(8, 54, 78),
/* {'track': 1, 'velocity': 76, 't': 32256, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 76),
/* {'track': 1, 'velocity': 77, 't': 32256, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 77),
/* {'track': 1, 'velocity': 70, 't': 32256, 'channel': 2, 'pitch': 54} */
NOTE(11, 54, 70),
/* {'track': 1, 'velocity': 0, 't': 32288, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 87, 't': 32320, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 87),
/* {'track': 1, 'velocity': 0, 't': 32352, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 32372, 'channel': 2, 'pitch': 54} */
PAUSE(20),
NOTE(8, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 32372, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 32372, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 107, 't': 32384, 'channel': 1, 'pitch': 87} */
PAUSE(12),
NOTE(0, 87, 107),
/* {'track': 1, 'velocity': 77, 't': 32384, 'channel': 2, 'pitch': 54} */
NOTE(8, 54, 77),
/* {'track': 1, 'velocity': 75, 't': 32384, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 75),
/* {'track': 1, 'velocity': 75, 't': 32384, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 75),
/* {'track': 1, 'velocity': 0, 't': 32416, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 89, 't': 32448, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 89),
/* {'track': 1, 'velocity': 0, 't': 32480, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 32500, 'channel': 2, 'pitch': 54} */
PAUSE(20),
NOTE(8, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 32500, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 32500, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 89, 't': 32512, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 89),
/* {'track': 1, 'velocity': 0, 't': 32544, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 78, 't': 32576, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 78),
/* {'track': 1, 'velocity': 0, 't': 32608, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 109, 't': 32640, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 109),
/* {'track': 1, 'velocity': 69, 't': 32640, 'channel': 2, 'pitch': 54} */
NOTE(8, 54, 69),
/* {'track': 1, 'velocity': 67, 't': 32640, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 67),
/* {'track': 1, 'velocity': 67, 't': 32640, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 67),
/* {'track': 1, 'velocity': 0, 't': 32672, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 103, 't': 32704, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 103),
/* {'track': 1, 'velocity': 0, 't': 32718, 'channel': 2, 'pitch': 54} */
PAUSE(14),
NOTE(8, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 32736, 'channel': 1, 'pitch': 83} */
PAUSE(18),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 32756, 'channel': 2, 'pitch': 54} */
PAUSE(20),
NOTE(8, 54, 0),
/* {'track': 1, 'velocity': 0, 't': 32756, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 32756, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 111, 't': 32768, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 111),
/* {'track': 1, 'velocity': 77, 't': 32768, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 77),
/* {'track': 1, 'velocity': 76, 't': 32768, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 76),
/* {'track': 1, 'velocity': 74, 't': 32768, 'channel': 2, 'pitch': 52} */
NOTE(10, 52, 74),
/* {'track': 1, 'velocity': 0, 't': 32800, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 93, 't': 32832, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 93),
/* {'track': 1, 'velocity': 0, 't': 32864, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 0, 't': 32884, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 32884, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 99, 't': 32896, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 99),
/* {'track': 1, 'velocity': 74, 't': 32896, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 74),
/* {'track': 1, 'velocity': 77, 't': 32896, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 77),
/* {'track': 1, 'velocity': 0, 't': 32928, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 86, 't': 32960, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 86),
/* {'track': 1, 'velocity': 0, 't': 32992, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 33012, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 33012, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 85, 't': 33024, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 85),
/* {'track': 1, 'velocity': 0, 't': 33056, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 85, 't': 33088, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 85),
/* {'track': 1, 'velocity': 0, 't': 33120, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 104, 't': 33152, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 104),
/* {'track': 1, 'velocity': 69, 't': 33152, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 69),
/* {'track': 1, 'velocity': 66, 't': 33152, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 66),
/* {'track': 1, 'velocity': 0, 't': 33184, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 105, 't': 33216, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 105),
/* {'track': 1, 'velocity': 0, 't': 33248, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 33268, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 33268, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 113, 't': 33280, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 113),
/* {'track': 1, 'velocity': 87, 't': 33280, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 87),
/* {'track': 1, 'velocity': 85, 't': 33280, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 85),
/* {'track': 1, 'velocity': 0, 't': 33312, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 94, 't': 33344, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 94),
/* {'track': 1, 'velocity': 0, 't': 33376, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 0, 't': 33396, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 33396, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 100, 't': 33408, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 100),
/* {'track': 1, 'velocity': 76, 't': 33408, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 76),
/* {'track': 1, 'velocity': 77, 't': 33408, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 77),
/* {'track': 1, 'velocity': 0, 't': 33440, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 84, 't': 33472, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 84),
/* {'track': 1, 'velocity': 0, 't': 33504, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 33524, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 33524, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 83, 't': 33536, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 83),
/* {'track': 1, 'velocity': 0, 't': 33568, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 87, 't': 33600, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 87),
/* {'track': 1, 'velocity': 0, 't': 33632, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 101, 't': 33664, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 101),
/* {'track': 1, 'velocity': 69, 't': 33664, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 69),
/* {'track': 1, 'velocity': 66, 't': 33664, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 66),
/* {'track': 1, 'velocity': 68, 't': 33664, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 68),
/* {'track': 1, 'velocity': 0, 't': 33696, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 109, 't': 33728, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 109),
/* {'track': 1, 'velocity': 0, 't': 33760, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 33780, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 33780, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 33780, 'channel': 2, 'pitch': 59} */
NOTE(10, 59, 0),
/* {'track': 1, 'velocity': 103, 't': 33792, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 103),
/* {'track': 1, 'velocity': 82, 't': 33792, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 82),
/* {'track': 1, 'velocity': 80, 't': 33792, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 80),
/* {'track': 1, 'velocity': 80, 't': 33792, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 80),
/* {'track': 1, 'velocity': 0, 't': 33824, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 92, 't': 33856, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 92),
/* {'track': 1, 'velocity': 0, 't': 33888, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 33908, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 33908, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 33908, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 101, 't': 33920, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 101),
/* {'track': 1, 'velocity': 75, 't': 33920, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 75),
/* {'track': 1, 'velocity': 77, 't': 33920, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 77),
/* {'track': 1, 'velocity': 75, 't': 33920, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 75),
/* {'track': 1, 'velocity': 0, 't': 33952, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 93, 't': 33984, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 93),
/* {'track': 1, 'velocity': 0, 't': 34016, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 34036, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 34036, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 34036, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 83, 't': 34048, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 83),
/* {'track': 1, 'velocity': 0, 't': 34080, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 87, 't': 34112, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 87),
/* {'track': 1, 'velocity': 0, 't': 34144, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 101, 't': 34176, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 101),
/* {'track': 1, 'velocity': 67, 't': 34176, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 67),
/* {'track': 1, 'velocity': 69, 't': 34176, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 69),
/* {'track': 1, 'velocity': 70, 't': 34176, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 70),
/* {'track': 1, 'velocity': 0, 't': 34208, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 106, 't': 34240, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 106),
/* {'track': 1, 'velocity': 0, 't': 34254, 'channel': 2, 'pitch': 52} */
PAUSE(14),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 34272, 'channel': 1, 'pitch': 83} */
PAUSE(18),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 34292, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 34292, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 34292, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 107, 't': 34304, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 107),
/* {'track': 1, 'velocity': 81, 't': 34304, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 81),
/* {'track': 1, 'velocity': 82, 't': 34304, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 82),
/* {'track': 1, 'velocity': 81, 't': 34304, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 81),
/* {'track': 1, 'velocity': 0, 't': 34336, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 89, 't': 34368, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 89),
/* {'track': 1, 'velocity': 0, 't': 34400, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 34420, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 34420, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 34420, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 101, 't': 34432, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 101),
/* {'track': 1, 'velocity': 77, 't': 34432, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 77),
/* {'track': 1, 'velocity': 75, 't': 34432, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 75),
/* {'track': 1, 'velocity': 77, 't': 34432, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 77),
/* {'track': 1, 'velocity': 0, 't': 34464, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 89, 't': 34496, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 89),
/* {'track': 1, 'velocity': 0, 't': 34528, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 34548, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 34548, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 34548, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 85, 't': 34560, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 85),
/* {'track': 1, 'velocity': 0, 't': 34592, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 88, 't': 34624, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 88),
/* {'track': 1, 'velocity': 0, 't': 34656, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 102, 't': 34688, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 102),
/* {'track': 1, 'velocity': 67, 't': 34688, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 67),
/* {'track': 1, 'velocity': 68, 't': 34688, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 68),
/* {'track': 1, 'velocity': 67, 't': 34688, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 67),
/* {'track': 1, 'velocity': 0, 't': 34720, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 107, 't': 34752, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 107),
/* {'track': 1, 'velocity': 0, 't': 34784, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 34804, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 34804, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 34804, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 104, 't': 34816, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 104),
/* {'track': 1, 'velocity': 73, 't': 34816, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 73),
/* {'track': 1, 'velocity': 72, 't': 34816, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 72),
/* {'track': 1, 'velocity': 75, 't': 34816, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 75),
/* {'track': 1, 'velocity': 69, 't': 34816, 'channel': 2, 'pitch': 46} */
NOTE(11, 46, 69),
/* {'track': 1, 'velocity': 0, 't': 34848, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 91, 't': 34880, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 91),
/* {'track': 1, 'velocity': 0, 't': 34912, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 34932, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 34932, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 34932, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 100, 't': 34944, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 100),
/* {'track': 1, 'velocity': 76, 't': 34944, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 76),
/* {'track': 1, 'velocity': 74, 't': 34944, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 74),
/* {'track': 1, 'velocity': 76, 't': 34944, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 76),
/* {'track': 1, 'velocity': 0, 't': 34976, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 85, 't': 35008, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 85),
/* {'track': 1, 'velocity': 0, 't': 35040, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 35060, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 35060, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 35060, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 85, 't': 35072, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 85),
/* {'track': 1, 'velocity': 0, 't': 35104, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 83, 't': 35136, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 83),
/* {'track': 1, 'velocity': 0, 't': 35168, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 104, 't': 35200, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 104),
/* {'track': 1, 'velocity': 67, 't': 35200, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 67),
/* {'track': 1, 'velocity': 67, 't': 35200, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 67),
/* {'track': 1, 'velocity': 0, 't': 35232, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 106, 't': 35264, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 106),
/* {'track': 1, 'velocity': 0, 't': 35296, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 35316, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 35316, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 114, 't': 35328, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 114),
/* {'track': 1, 'velocity': 87, 't': 35328, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 87),
/* {'track': 1, 'velocity': 86, 't': 35328, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 86),
/* {'track': 1, 'velocity': 87, 't': 35328, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 87),
/* {'track': 1, 'velocity': 0, 't': 35360, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 93, 't': 35392, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 93),
/* {'track': 1, 'velocity': 0, 't': 35424, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 35444, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 35444, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 35444, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 99, 't': 35456, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 99),
/* {'track': 1, 'velocity': 75, 't': 35456, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 75),
/* {'track': 1, 'velocity': 77, 't': 35456, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 77),
/* {'track': 1, 'velocity': 79, 't': 35456, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 79),
/* {'track': 1, 'velocity': 0, 't': 35488, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 86, 't': 35520, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 86),
/* {'track': 1, 'velocity': 0, 't': 35552, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 35572, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 35572, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 35572, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 85, 't': 35584, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 85),
/* {'track': 1, 'velocity': 0, 't': 35616, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 82, 't': 35648, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 82),
/* {'track': 1, 'velocity': 0, 't': 35680, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 103, 't': 35712, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 103),
/* {'track': 1, 'velocity': 68, 't': 35712, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 68),
/* {'track': 1, 'velocity': 69, 't': 35712, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 69),
/* {'track': 1, 'velocity': 0, 't': 35744, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 106, 't': 35776, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 106),
/* {'track': 1, 'velocity': 0, 't': 35790, 'channel': 2, 'pitch': 46} */
PAUSE(14),
NOTE(8, 46, 0),
/* {'track': 1, 'velocity': 0, 't': 35808, 'channel': 1, 'pitch': 79} */
PAUSE(18),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 35828, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 35828, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 119, 't': 35840, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 119),
/* {'track': 1, 'velocity': 91, 't': 35840, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 91),
/* {'track': 1, 'velocity': 90, 't': 35840, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 90),
/* {'track': 1, 'velocity': 91, 't': 35840, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 91),
/* {'track': 1, 'velocity': 90, 't': 35840, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 90),
/* {'track': 1, 'velocity': 70, 't': 35840, 'channel': 2, 'pitch': 45} */
NOTE(12, 45, 70),
/* {'track': 1, 'velocity': 0, 't': 35872, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 95, 't': 35904, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 95),
/* {'track': 1, 'velocity': 0, 't': 35936, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 35956, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 35956, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 35956, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 35956, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 0),
/* {'track': 1, 'velocity': 100, 't': 35968, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 100),
/* {'track': 1, 'velocity': 76, 't': 35968, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 76),
/* {'track': 1, 'velocity': 75, 't': 35968, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 75),
/* {'track': 1, 'velocity': 75, 't': 35968, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 75),
/* {'track': 1, 'velocity': 78, 't': 35968, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 78),
/* {'track': 1, 'velocity': 0, 't': 36000, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 86, 't': 36032, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 36064, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 36084, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 36084, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 36084, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 36084, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 0),
/* {'track': 1, 'velocity': 84, 't': 36096, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 84),
/* {'track': 1, 'velocity': 0, 't': 36128, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 83, 't': 36160, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 83),
/* {'track': 1, 'velocity': 0, 't': 36192, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 100, 't': 36224, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 100),
/* {'track': 1, 'velocity': 67, 't': 36224, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 67),
/* {'track': 1, 'velocity': 67, 't': 36224, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 67),
/* {'track': 1, 'velocity': 70, 't': 36224, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 70),
/* {'track': 1, 'velocity': 67, 't': 36224, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 67),
/* {'track': 1, 'velocity': 0, 't': 36256, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 106, 't': 36288, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 106),
/* {'track': 1, 'velocity': 0, 't': 36302, 'channel': 2, 'pitch': 45} */
PAUSE(14),
NOTE(8, 45, 0),
/* {'track': 1, 'velocity': 0, 't': 36320, 'channel': 1, 'pitch': 81} */
PAUSE(18),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 36340, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 36340, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 36340, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 36340, 'channel': 2, 'pitch': 62} */
NOTE(11, 62, 0),
/* {'track': 1, 'velocity': 116, 't': 36352, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 116),
/* {'track': 1, 'velocity': 83, 't': 36352, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 83),
/* {'track': 1, 'velocity': 82, 't': 36352, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 82),
/* {'track': 1, 'velocity': 80, 't': 36352, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 80),
/* {'track': 1, 'velocity': 80, 't': 36352, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 80),
/* {'track': 1, 'velocity': 69, 't': 36352, 'channel': 2, 'pitch': 43} */
NOTE(12, 43, 69),
/* {'track': 1, 'velocity': 0, 't': 36384, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 96, 't': 36416, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 96),
/* {'track': 1, 'velocity': 0, 't': 36448, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 0, 't': 36468, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 36468, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 36468, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 36468, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 100, 't': 36480, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 100),
/* {'track': 1, 'velocity': 77, 't': 36480, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 77),
/* {'track': 1, 'velocity': 77, 't': 36480, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 77),
/* {'track': 1, 'velocity': 78, 't': 36480, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 78),
/* {'track': 1, 'velocity': 77, 't': 36480, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 77),
/* {'track': 1, 'velocity': 0, 't': 36512, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 86, 't': 36544, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 86),
/* {'track': 1, 'velocity': 0, 't': 36576, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 36596, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 36596, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 36596, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 36596, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 86, 't': 36608, 'channel': 1, 'pitch': 82} */
PAUSE(12),
NOTE(0, 82, 86),
/* {'track': 1, 'velocity': 0, 't': 36640, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 89, 't': 36672, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 89),
/* {'track': 1, 'velocity': 0, 't': 36704, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 103, 't': 36736, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 103),
/* {'track': 1, 'velocity': 69, 't': 36736, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 69),
/* {'track': 1, 'velocity': 68, 't': 36736, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 68),
/* {'track': 1, 'velocity': 66, 't': 36736, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 66),
/* {'track': 1, 'velocity': 70, 't': 36736, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 70),
/* {'track': 1, 'velocity': 0, 't': 36768, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 109, 't': 36800, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 109),
/* {'track': 1, 'velocity': 0, 't': 36814, 'channel': 2, 'pitch': 43} */
PAUSE(14),
NOTE(8, 43, 0),
/* {'track': 1, 'velocity': 0, 't': 36832, 'channel': 1, 'pitch': 88} */
PAUSE(18),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 0, 't': 36852, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 36852, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 36852, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 36852, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 105, 't': 36864, 'channel': 1, 'pitch': 89} */
PAUSE(12),
NOTE(0, 89, 105),
/* {'track': 1, 'velocity': 80, 't': 36864, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 80),
/* {'track': 1, 'velocity': 80, 't': 36864, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 80),
/* {'track': 1, 'velocity': 82, 't': 36864, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 82),
/* {'track': 1, 'velocity': 82, 't': 36864, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 82),
/* {'track': 1, 'velocity': 75, 't': 36864, 'channel': 2, 'pitch': 41} */
NOTE(12, 41, 75),
/* {'track': 1, 'velocity': 0, 't': 36896, 'channel': 1, 'pitch': 89} */
PAUSE(32),
NOTE(0, 89, 0),
/* {'track': 1, 'velocity': 93, 't': 36928, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 93),
/* {'track': 1, 'velocity': 0, 't': 36960, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 0, 't': 36980, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 36980, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 36980, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 36980, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 0),
/* {'track': 1, 'velocity': 100, 't': 36992, 'channel': 1, 'pitch': 89} */
PAUSE(12),
NOTE(0, 89, 100),
/* {'track': 1, 'velocity': 78, 't': 36992, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 78),
/* {'track': 1, 'velocity': 78, 't': 36992, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 78),
/* {'track': 1, 'velocity': 77, 't': 36992, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 77),
/* {'track': 1, 'velocity': 75, 't': 36992, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 75),
/* {'track': 1, 'velocity': 0, 't': 37024, 'channel': 1, 'pitch': 89} */
PAUSE(32),
NOTE(0, 89, 0),
/* {'track': 1, 'velocity': 82, 't': 37056, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 82),
/* {'track': 1, 'velocity': 0, 't': 37088, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 37108, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 37108, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 37108, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 37108, 'channel': 2, 'pitch': 65} */
NOTE(11, 65, 0),
/* {'track': 1, 'velocity': 84, 't': 37120, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 84),
/* {'track': 1, 'velocity': 0, 't': 37152, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 85, 't': 37184, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 85),
/* {'track': 1, 'velocity': 0, 't': 37216, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 105, 't': 37248, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 105),
/* {'track': 1, 'velocity': 69, 't': 37248, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 69),
/* {'track': 1, 'velocity': 67, 't': 37248, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 67),
/* {'track': 1, 'velocity': 68, 't': 37248, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 68),
/* {'track': 1, 'velocity': 0, 't': 37280, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 105, 't': 37312, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 105),
/* {'track': 1, 'velocity': 0, 't': 37344, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 0, 't': 37364, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 37364, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 37364, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 110, 't': 37376, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 110),
/* {'track': 1, 'velocity': 83, 't': 37376, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 83),
/* {'track': 1, 'velocity': 83, 't': 37376, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 83),
/* {'track': 1, 'velocity': 82, 't': 37376, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 82),
/* {'track': 1, 'velocity': 82, 't': 37376, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 82),
/* {'track': 1, 'velocity': 0, 't': 37408, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 91, 't': 37440, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 91),
/* {'track': 1, 'velocity': 0, 't': 37472, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 0, 't': 37492, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 37492, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 37492, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 37492, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 102, 't': 37504, 'channel': 1, 'pitch': 88} */
PAUSE(12),
NOTE(0, 88, 102),
/* {'track': 1, 'velocity': 78, 't': 37504, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 78),
/* {'track': 1, 'velocity': 78, 't': 37504, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 78),
/* {'track': 1, 'velocity': 77, 't': 37504, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 77),
/* {'track': 1, 'velocity': 74, 't': 37504, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 74),
/* {'track': 1, 'velocity': 0, 't': 37536, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 89, 't': 37568, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 89),
/* {'track': 1, 'velocity': 0, 't': 37600, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 37620, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 37620, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 37620, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 37620, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 89, 't': 37632, 'channel': 1, 'pitch': 82} */
PAUSE(12),
NOTE(0, 82, 89),
/* {'track': 1, 'velocity': 0, 't': 37664, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 85, 't': 37696, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 85),
/* {'track': 1, 'velocity': 0, 't': 37728, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 102, 't': 37760, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 102),
/* {'track': 1, 'velocity': 69, 't': 37760, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 69),
/* {'track': 1, 'velocity': 70, 't': 37760, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 70),
/* {'track': 1, 'velocity': 67, 't': 37760, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 67),
/* {'track': 1, 'velocity': 67, 't': 37760, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 67),
/* {'track': 1, 'velocity': 0, 't': 37792, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 105, 't': 37824, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 105),
/* {'track': 1, 'velocity': 0, 't': 37838, 'channel': 2, 'pitch': 41} */
PAUSE(14),
NOTE(8, 41, 0),
/* {'track': 1, 'velocity': 0, 't': 37856, 'channel': 1, 'pitch': 85} */
PAUSE(18),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 37876, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 37876, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 37876, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 37876, 'channel': 2, 'pitch': 64} */
NOTE(11, 64, 0),
/* {'track': 1, 'velocity': 106, 't': 37888, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 106),
/* {'track': 1, 'velocity': 74, 't': 37888, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 74),
/* {'track': 1, 'velocity': 75, 't': 37888, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 75),
/* {'track': 1, 'velocity': 72, 't': 37888, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 72),
/* {'track': 1, 'velocity': 0, 't': 37920, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 93, 't': 37952, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 93),
/* {'track': 1, 'velocity': 0, 't': 37984, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 38004, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 38004, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 38004, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 99, 't': 38016, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 99),
/* {'track': 1, 'velocity': 73, 't': 38016, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 73),
/* {'track': 1, 'velocity': 74, 't': 38016, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 74),
/* {'track': 1, 'velocity': 77, 't': 38016, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 77),
/* {'track': 1, 'velocity': 0, 't': 38048, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 82, 't': 38080, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 82),
/* {'track': 1, 'velocity': 0, 't': 38112, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 38132, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 38132, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 38132, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 81, 't': 38144, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 81),
/* {'track': 1, 'velocity': 0, 't': 38176, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 84, 't': 38208, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 84),
/* {'track': 1, 'velocity': 0, 't': 38240, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 101, 't': 38272, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 101),
/* {'track': 1, 'velocity': 67, 't': 38272, 'channel': 2, 'pitch': 53} */
NOTE(8, 53, 67),
/* {'track': 1, 'velocity': 69, 't': 38272, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 69),
/* {'track': 1, 'velocity': 69, 't': 38272, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 69),
/* {'track': 1, 'velocity': 0, 't': 38304, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 106, 't': 38336, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 106),
/* {'track': 1, 'velocity': 0, 't': 38368, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 38388, 'channel': 2, 'pitch': 53} */
PAUSE(20),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 38388, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 38388, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 109, 't': 38400, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 109),
/* {'track': 1, 'velocity': 72, 't': 38400, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 72),
/* {'track': 1, 'velocity': 74, 't': 38400, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 74),
/* {'track': 1, 'velocity': 73, 't': 38400, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 73),
/* {'track': 1, 'velocity': 0, 't': 38432, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 87, 't': 38464, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 87),
/* {'track': 1, 'velocity': 0, 't': 38496, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 38516, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 38516, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 38516, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 103, 't': 38528, 'channel': 1, 'pitch': 84} */
PAUSE(12),
NOTE(0, 84, 103),
/* {'track': 1, 'velocity': 75, 't': 38528, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 75),
/* {'track': 1, 'velocity': 74, 't': 38528, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 74),
/* {'track': 1, 'velocity': 76, 't': 38528, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 76),
/* {'track': 1, 'velocity': 0, 't': 38560, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 89, 't': 38592, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 89),
/* {'track': 1, 'velocity': 0, 't': 38624, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 38644, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 38644, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 38644, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 83, 't': 38656, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 83),
/* {'track': 1, 'velocity': 0, 't': 38688, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 85, 't': 38720, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 85),
/* {'track': 1, 'velocity': 0, 't': 38752, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 105, 't': 38784, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 105),
/* {'track': 1, 'velocity': 68, 't': 38784, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 68),
/* {'track': 1, 'velocity': 70, 't': 38784, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 70),
/* {'track': 1, 'velocity': 69, 't': 38784, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 69),
/* {'track': 1, 'velocity': 0, 't': 38816, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 111, 't': 38848, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 111),
/* {'track': 1, 'velocity': 0, 't': 38880, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 38900, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 38900, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 38900, 'channel': 2, 'pitch': 60} */
NOTE(10, 60, 0),
/* {'track': 1, 'velocity': 103, 't': 38912, 'channel': 1, 'pitch': 82} */
PAUSE(12),
NOTE(0, 82, 103),
/* {'track': 1, 'velocity': 73, 't': 38912, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 73),
/* {'track': 1, 'velocity': 75, 't': 38912, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 75),
/* {'track': 1, 'velocity': 73, 't': 38912, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 73),
/* {'track': 1, 'velocity': 0, 't': 38944, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 90, 't': 38976, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 90),
/* {'track': 1, 'velocity': 0, 't': 39008, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 39028, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 39028, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 39028, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 0),
/* {'track': 1, 'velocity': 99, 't': 39040, 'channel': 1, 'pitch': 82} */
PAUSE(12),
NOTE(0, 82, 99),
/* {'track': 1, 'velocity': 75, 't': 39040, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 75),
/* {'track': 1, 'velocity': 77, 't': 39040, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 77),
/* {'track': 1, 'velocity': 74, 't': 39040, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 74),
/* {'track': 1, 'velocity': 0, 't': 39072, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 92, 't': 39104, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 92),
/* {'track': 1, 'velocity': 0, 't': 39136, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 39156, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 39156, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 39156, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 0),
/* {'track': 1, 'velocity': 86, 't': 39168, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 86),
/* {'track': 1, 'velocity': 0, 't': 39200, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 77, 't': 39232, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 77),
/* {'track': 1, 'velocity': 0, 't': 39264, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 108, 't': 39296, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 108),
/* {'track': 1, 'velocity': 69, 't': 39296, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 69),
/* {'track': 1, 'velocity': 67, 't': 39296, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 67),
/* {'track': 1, 'velocity': 70, 't': 39296, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 70),
/* {'track': 1, 'velocity': 0, 't': 39328, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 107, 't': 39360, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 107),
/* {'track': 1, 'velocity': 0, 't': 39392, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 39412, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 39412, 'channel': 2, 'pitch': 57} */
NOTE(9, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 39412, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 0),
/* {'track': 1, 'velocity': 107, 't': 39424, 'channel': 1, 'pitch': 82} */
PAUSE(12),
NOTE(0, 82, 107),
/* {'track': 1, 'velocity': 79, 't': 39424, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 79),
/* {'track': 1, 'velocity': 77, 't': 39424, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 77),
/* {'track': 1, 'velocity': 77, 't': 39424, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 77),
/* {'track': 1, 'velocity': 0, 't': 39456, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 90, 't': 39488, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 90),
/* {'track': 1, 'velocity': 0, 't': 39520, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 39540, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 39540, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 39540, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 0),
/* {'track': 1, 'velocity': 104, 't': 39552, 'channel': 1, 'pitch': 82} */
PAUSE(12),
NOTE(0, 82, 104),
/* {'track': 1, 'velocity': 76, 't': 39552, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 76),
/* {'track': 1, 'velocity': 77, 't': 39552, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 77),
/* {'track': 1, 'velocity': 75, 't': 39552, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 75),
/* {'track': 1, 'velocity': 0, 't': 39584, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 87, 't': 39616, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 87),
/* {'track': 1, 'velocity': 0, 't': 39648, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 39668, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 39668, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 39668, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 0),
/* {'track': 1, 'velocity': 86, 't': 39680, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 86),
/* {'track': 1, 'velocity': 0, 't': 39712, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 80, 't': 39744, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 80),
/* {'track': 1, 'velocity': 0, 't': 39776, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 106, 't': 39808, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 106),
/* {'track': 1, 'velocity': 68, 't': 39808, 'channel': 2, 'pitch': 52} */
NOTE(8, 52, 68),
/* {'track': 1, 'velocity': 66, 't': 39808, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 66),
/* {'track': 1, 'velocity': 67, 't': 39808, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 67),
/* {'track': 1, 'velocity': 0, 't': 39840, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 106, 't': 39872, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 106),
/* {'track': 1, 'velocity': 0, 't': 39904, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 39924, 'channel': 2, 'pitch': 52} */
PAUSE(20),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 0, 't': 39924, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 39924, 'channel': 2, 'pitch': 58} */
NOTE(10, 58, 0),
/* {'track': 1, 'velocity': 108, 't': 39936, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 108),
/* {'track': 1, 'velocity': 74, 't': 39936, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 74),
/* {'track': 1, 'velocity': 75, 't': 39936, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 75),
/* {'track': 1, 'velocity': 74, 't': 39936, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 74),
/* {'track': 1, 'velocity': 0, 't': 39968, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 91, 't': 40000, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 91),
/* {'track': 1, 'velocity': 0, 't': 40032, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 40052, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 40052, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 40052, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 99, 't': 40064, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 99),
/* {'track': 1, 'velocity': 74, 't': 40064, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 74),
/* {'track': 1, 'velocity': 73, 't': 40064, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 73),
/* {'track': 1, 'velocity': 74, 't': 40064, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 74),
/* {'track': 1, 'velocity': 0, 't': 40096, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 89, 't': 40128, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 89),
/* {'track': 1, 'velocity': 0, 't': 40160, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 40180, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 40180, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 40180, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 87, 't': 40192, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 87),
/* {'track': 1, 'velocity': 0, 't': 40224, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 76, 't': 40256, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 76),
/* {'track': 1, 'velocity': 0, 't': 40288, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 110, 't': 40320, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 110),
/* {'track': 1, 'velocity': 69, 't': 40320, 'channel': 2, 'pitch': 49} */
NOTE(8, 49, 69),
/* {'track': 1, 'velocity': 69, 't': 40320, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 69),
/* {'track': 1, 'velocity': 70, 't': 40320, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 70),
/* {'track': 1, 'velocity': 0, 't': 40352, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 106, 't': 40384, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 106),
/* {'track': 1, 'velocity': 0, 't': 40416, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 40436, 'channel': 2, 'pitch': 49} */
PAUSE(20),
NOTE(8, 49, 0),
/* {'track': 1, 'velocity': 0, 't': 40436, 'channel': 2, 'pitch': 55} */
NOTE(9, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 40436, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 107, 't': 40448, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 107),
/* {'track': 1, 'velocity': 78, 't': 40448, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 78),
/* {'track': 1, 'velocity': 77, 't': 40448, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 77),
/* {'track': 1, 'velocity': 78, 't': 40448, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 78),
/* {'track': 1, 'velocity': 0, 't': 40480, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 86, 't': 40512, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 86),
/* {'track': 1, 'velocity': 0, 't': 40544, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 40564, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 40564, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 40564, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 107, 't': 40576, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 107),
/* {'track': 1, 'velocity': 75, 't': 40576, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 75),
/* {'track': 1, 'velocity': 75, 't': 40576, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 75),
/* {'track': 1, 'velocity': 77, 't': 40576, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 77),
/* {'track': 1, 'velocity': 0, 't': 40608, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 86, 't': 40640, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 86),
/* {'track': 1, 'velocity': 0, 't': 40672, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 40692, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 40692, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 40692, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 85, 't': 40704, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 85),
/* {'track': 1, 'velocity': 0, 't': 40736, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 81, 't': 40768, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 81),
/* {'track': 1, 'velocity': 0, 't': 40800, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 105, 't': 40832, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 105),
/* {'track': 1, 'velocity': 67, 't': 40832, 'channel': 2, 'pitch': 50} */
NOTE(8, 50, 67),
/* {'track': 1, 'velocity': 67, 't': 40832, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 67),
/* {'track': 1, 'velocity': 68, 't': 40832, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 68),
/* {'track': 1, 'velocity': 0, 't': 40864, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 106, 't': 40896, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 106),
/* {'track': 1, 'velocity': 0, 't': 40928, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 40948, 'channel': 2, 'pitch': 50} */
PAUSE(20),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 40948, 'channel': 2, 'pitch': 53} */
NOTE(9, 53, 0),
/* {'track': 1, 'velocity': 0, 't': 40948, 'channel': 2, 'pitch': 57} */
NOTE(10, 57, 0),
/* {'track': 1, 'velocity': 113, 't': 40960, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 113),
/* {'track': 1, 'velocity': 113, 't': 40960, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 113),
/* {'track': 1, 'velocity': 111, 't': 40960, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 111),
/* {'track': 1, 'velocity': 96, 't': 40960, 'channel': 2, 'pitch': 69} */
NOTE(8, 69, 96),
/* {'track': 1, 'velocity': 70, 't': 40960, 'channel': 2, 'pitch': 46} */
NOTE(9, 46, 70),
/* {'track': 1, 'velocity': 0, 't': 40992, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 74, 't': 41024, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 74),
/* {'track': 1, 'velocity': 0, 't': 41056, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 41076, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 41076, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 41076, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 100, 't': 41088, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 100),
/* {'track': 1, 'velocity': 96, 't': 41088, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 96),
/* {'track': 1, 'velocity': 99, 't': 41088, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 99),
/* {'track': 1, 'velocity': 81, 't': 41088, 'channel': 2, 'pitch': 69} */
NOTE(8, 69, 81),
/* {'track': 1, 'velocity': 0, 't': 41120, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 71, 't': 41152, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 71),
/* {'track': 1, 'velocity': 0, 't': 41184, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 41204, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 41204, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 41204, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 66, 't': 41216, 'channel': 2, 'pitch': 62} */
PAUSE(12),
NOTE(8, 62, 66),
/* {'track': 1, 'velocity': 0, 't': 41248, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 66, 't': 41280, 'channel': 2, 'pitch': 58} */
PAUSE(32),
NOTE(8, 58, 66),
/* {'track': 1, 'velocity': 0, 't': 41312, 'channel': 2, 'pitch': 58} */
PAUSE(32),
NOTE(8, 58, 0),
/* {'track': 1, 'velocity': 85, 't': 41344, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 85),
/* {'track': 1, 'velocity': 85, 't': 41344, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 85),
/* {'track': 1, 'velocity': 84, 't': 41344, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 84),
/* {'track': 1, 'velocity': 80, 't': 41344, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 80),
/* {'track': 1, 'velocity': 0, 't': 41376, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 86, 't': 41408, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 86),
/* {'track': 1, 'velocity': 0, 't': 41440, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 41460, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 41460, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 41460, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 110, 't': 41472, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 110),
/* {'track': 1, 'velocity': 110, 't': 41472, 'channel': 1, 'pitch': 79} */
NOTE(1, 79, 110),
/* {'track': 1, 'velocity': 110, 't': 41472, 'channel': 1, 'pitch': 82} */
NOTE(2, 82, 110),
/* {'track': 1, 'velocity': 111, 't': 41472, 'channel': 1, 'pitch': 86} */
NOTE(3, 86, 111),
/* {'track': 1, 'velocity': 87, 't': 41472, 'channel': 2, 'pitch': 70} */
NOTE(8, 70, 87),
/* {'track': 1, 'velocity': 0, 't': 41504, 'channel': 2, 'pitch': 70} */
PAUSE(32),
NOTE(8, 70, 0),
/* {'track': 1, 'velocity': 72, 't': 41536, 'channel': 2, 'pitch': 67} */
PAUSE(32),
NOTE(8, 67, 72),
/* {'track': 1, 'velocity': 0, 't': 41568, 'channel': 2, 'pitch': 67} */
PAUSE(32),
NOTE(8, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 41588, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 41588, 'channel': 1, 'pitch': 79} */
NOTE(1, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 41588, 'channel': 1, 'pitch': 82} */
NOTE(2, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 41588, 'channel': 1, 'pitch': 86} */
NOTE(3, 86, 0),
/* {'track': 1, 'velocity': 98, 't': 41600, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 98),
/* {'track': 1, 'velocity': 95, 't': 41600, 'channel': 1, 'pitch': 79} */
NOTE(1, 79, 95),
/* {'track': 1, 'velocity': 98, 't': 41600, 'channel': 1, 'pitch': 82} */
NOTE(2, 82, 98),
/* {'track': 1, 'velocity': 98, 't': 41600, 'channel': 1, 'pitch': 86} */
NOTE(3, 86, 98),
/* {'track': 1, 'velocity': 79, 't': 41600, 'channel': 2, 'pitch': 70} */
NOTE(8, 70, 79),
/* {'track': 1, 'velocity': 0, 't': 41632, 'channel': 2, 'pitch': 70} */
PAUSE(32),
NOTE(8, 70, 0),
/* {'track': 1, 'velocity': 69, 't': 41664, 'channel': 2, 'pitch': 67} */
PAUSE(32),
NOTE(8, 67, 69),
/* {'track': 1, 'velocity': 0, 't': 41696, 'channel': 2, 'pitch': 67} */
PAUSE(32),
NOTE(8, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 41716, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 41716, 'channel': 1, 'pitch': 79} */
NOTE(1, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 41716, 'channel': 1, 'pitch': 82} */
NOTE(2, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 41716, 'channel': 1, 'pitch': 86} */
NOTE(3, 86, 0),
/* {'track': 1, 'velocity': 64, 't': 41728, 'channel': 2, 'pitch': 62} */
PAUSE(12),
NOTE(8, 62, 64),
/* {'track': 1, 'velocity': 0, 't': 41760, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 64, 't': 41792, 'channel': 2, 'pitch': 58} */
PAUSE(32),
NOTE(8, 58, 64),
/* {'track': 1, 'velocity': 0, 't': 41824, 'channel': 2, 'pitch': 58} */
PAUSE(32),
NOTE(8, 58, 0),
/* {'track': 1, 'velocity': 88, 't': 41856, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 88),
/* {'track': 1, 'velocity': 88, 't': 41856, 'channel': 1, 'pitch': 79} */
NOTE(1, 79, 88),
/* {'track': 1, 'velocity': 85, 't': 41856, 'channel': 1, 'pitch': 82} */
NOTE(2, 82, 85),
/* {'track': 1, 'velocity': 85, 't': 41856, 'channel': 1, 'pitch': 86} */
NOTE(3, 86, 85),
/* {'track': 1, 'velocity': 84, 't': 41856, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 84),
/* {'track': 1, 'velocity': 0, 't': 41888, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 86, 't': 41920, 'channel': 2, 'pitch': 67} */
PAUSE(32),
NOTE(8, 67, 86),
/* {'track': 1, 'velocity': 0, 't': 41934, 'channel': 2, 'pitch': 46} */
PAUSE(14),
NOTE(8, 46, 0),
/* {'track': 1, 'velocity': 0, 't': 41952, 'channel': 2, 'pitch': 67} */
PAUSE(18),
NOTE(8, 67, 0),
/* {'track': 1, 'velocity': 0, 't': 41972, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 41972, 'channel': 1, 'pitch': 79} */
NOTE(1, 79, 0),
/* {'track': 1, 'velocity': 0, 't': 41972, 'channel': 1, 'pitch': 82} */
NOTE(2, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 41972, 'channel': 1, 'pitch': 86} */
NOTE(3, 86, 0),
/* {'track': 1, 'velocity': 79, 't': 41984, 'channel': 1, 'pitch': 70} */
PAUSE(12),
NOTE(0, 70, 79),
/* {'track': 1, 'velocity': 80, 't': 41984, 'channel': 1, 'pitch': 77} */
NOTE(1, 77, 80),
/* {'track': 1, 'velocity': 81, 't': 41984, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 81),
/* {'track': 1, 'velocity': 80, 't': 41984, 'channel': 2, 'pitch': 67} */
NOTE(8, 67, 80),
/* {'track': 1, 'velocity': 80, 't': 41984, 'channel': 2, 'pitch': 48} */
NOTE(9, 48, 80),
/* {'track': 1, 'velocity': 0, 't': 42016, 'channel': 2, 'pitch': 67} */
PAUSE(32),
NOTE(8, 67, 0),
/* {'track': 1, 'velocity': 70, 't': 42048, 'channel': 2, 'pitch': 65} */
PAUSE(32),
NOTE(8, 65, 70),
/* {'track': 1, 'velocity': 0, 't': 42080, 'channel': 2, 'pitch': 65} */
PAUSE(32),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 42100, 'channel': 1, 'pitch': 70} */
PAUSE(20),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 42100, 'channel': 1, 'pitch': 77} */
NOTE(1, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 42100, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 0),
/* {'track': 1, 'velocity': 93, 't': 42112, 'channel': 1, 'pitch': 70} */
PAUSE(12),
NOTE(0, 70, 93),
/* {'track': 1, 'velocity': 94, 't': 42112, 'channel': 1, 'pitch': 77} */
NOTE(1, 77, 94),
/* {'track': 1, 'velocity': 95, 't': 42112, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 95),
/* {'track': 1, 'velocity': 80, 't': 42112, 'channel': 2, 'pitch': 67} */
NOTE(8, 67, 80),
/* {'track': 1, 'velocity': 0, 't': 42144, 'channel': 2, 'pitch': 67} */
PAUSE(32),
NOTE(8, 67, 0),
/* {'track': 1, 'velocity': 69, 't': 42176, 'channel': 2, 'pitch': 65} */
PAUSE(32),
NOTE(8, 65, 69),
/* {'track': 1, 'velocity': 0, 't': 42208, 'channel': 2, 'pitch': 65} */
PAUSE(32),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 42228, 'channel': 1, 'pitch': 70} */
PAUSE(20),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 42228, 'channel': 1, 'pitch': 77} */
NOTE(1, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 42228, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 0),
/* {'track': 1, 'velocity': 66, 't': 42240, 'channel': 2, 'pitch': 62} */
PAUSE(12),
NOTE(8, 62, 66),
/* {'track': 1, 'velocity': 0, 't': 42272, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 71, 't': 42304, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 71),
/* {'track': 1, 'velocity': 0, 't': 42336, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 88, 't': 42368, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 88),
/* {'track': 1, 'velocity': 87, 't': 42368, 'channel': 1, 'pitch': 77} */
NOTE(1, 77, 87),
/* {'track': 1, 'velocity': 84, 't': 42368, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 84),
/* {'track': 1, 'velocity': 79, 't': 42368, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 79),
/* {'track': 1, 'velocity': 0, 't': 42400, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 85, 't': 42432, 'channel': 2, 'pitch': 65} */
PAUSE(32),
NOTE(8, 65, 85),
/* {'track': 1, 'velocity': 0, 't': 42464, 'channel': 2, 'pitch': 65} */
PAUSE(32),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 42484, 'channel': 1, 'pitch': 70} */
PAUSE(20),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 42484, 'channel': 1, 'pitch': 77} */
NOTE(1, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 42484, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 0),
/* {'track': 1, 'velocity': 98, 't': 42496, 'channel': 1, 'pitch': 70} */
PAUSE(12),
NOTE(0, 70, 98),
/* {'track': 1, 'velocity': 98, 't': 42496, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 98),
/* {'track': 1, 'velocity': 95, 't': 42496, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 95),
/* {'track': 1, 'velocity': 85, 't': 42496, 'channel': 2, 'pitch': 67} */
NOTE(8, 67, 85),
/* {'track': 1, 'velocity': 0, 't': 42528, 'channel': 2, 'pitch': 67} */
PAUSE(32),
NOTE(8, 67, 0),
/* {'track': 1, 'velocity': 69, 't': 42560, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 69),
/* {'track': 1, 'velocity': 0, 't': 42592, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 42612, 'channel': 1, 'pitch': 70} */
PAUSE(20),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 42612, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 42612, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 0),
/* {'track': 1, 'velocity': 97, 't': 42624, 'channel': 1, 'pitch': 70} */
PAUSE(12),
NOTE(0, 70, 97),
/* {'track': 1, 'velocity': 97, 't': 42624, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 97),
/* {'track': 1, 'velocity': 95, 't': 42624, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 95),
/* {'track': 1, 'velocity': 81, 't': 42624, 'channel': 2, 'pitch': 67} */
NOTE(8, 67, 81),
/* {'track': 1, 'velocity': 0, 't': 42656, 'channel': 2, 'pitch': 67} */
PAUSE(32),
NOTE(8, 67, 0),
/* {'track': 1, 'velocity': 68, 't': 42688, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 68),
/* {'track': 1, 'velocity': 0, 't': 42720, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 42740, 'channel': 1, 'pitch': 70} */
PAUSE(20),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 42740, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 42740, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 0),
/* {'track': 1, 'velocity': 69, 't': 42752, 'channel': 2, 'pitch': 62} */
PAUSE(12),
NOTE(8, 62, 69),
/* {'track': 1, 'velocity': 0, 't': 42784, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 70, 't': 42816, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 70),
/* {'track': 1, 'velocity': 0, 't': 42848, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 85, 't': 42880, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 85),
/* {'track': 1, 'velocity': 85, 't': 42880, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 85),
/* {'track': 1, 'velocity': 87, 't': 42880, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 87),
/* {'track': 1, 'velocity': 79, 't': 42880, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 79),
/* {'track': 1, 'velocity': 0, 't': 42912, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 80, 't': 42944, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 80),
/* {'track': 1, 'velocity': 0, 't': 42958, 'channel': 2, 'pitch': 48} */
PAUSE(14),
NOTE(8, 48, 0),
/* {'track': 1, 'velocity': 0, 't': 42976, 'channel': 2, 'pitch': 64} */
PAUSE(18),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 42996, 'channel': 1, 'pitch': 70} */
PAUSE(20),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 42996, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 42996, 'channel': 1, 'pitch': 79} */
NOTE(2, 79, 0),
/* {'track': 1, 'velocity': 91, 't': 43008, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 91),
/* {'track': 1, 'velocity': 85, 't': 43008, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 85),
/* {'track': 1, 'velocity': 82, 't': 43008, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 82),
/* {'track': 1, 'velocity': 83, 't': 43008, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 83),
/* {'track': 1, 'velocity': 66, 't': 43008, 'channel': 2, 'pitch': 41} */
NOTE(11, 41, 66),
/* {'track': 1, 'velocity': 0, 't': 43040, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 88, 't': 43072, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 88),
/* {'track': 1, 'velocity': 0, 't': 43104, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 43124, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 43124, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 43124, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 0),
/* {'track': 1, 'velocity': 101, 't': 43136, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 101),
/* {'track': 1, 'velocity': 76, 't': 43136, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 76),
/* {'track': 1, 'velocity': 77, 't': 43136, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 77),
/* {'track': 1, 'velocity': 76, 't': 43136, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 76),
/* {'track': 1, 'velocity': 0, 't': 43168, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 84, 't': 43200, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 84),
/* {'track': 1, 'velocity': 0, 't': 43232, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 43252, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 43252, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 43252, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 0),
/* {'track': 1, 'velocity': 84, 't': 43264, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 84),
/* {'track': 1, 'velocity': 0, 't': 43296, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 84, 't': 43328, 'channel': 1, 'pitch': 65} */
PAUSE(32),
NOTE(0, 65, 84),
/* {'track': 1, 'velocity': 0, 't': 43360, 'channel': 1, 'pitch': 65} */
PAUSE(32),
NOTE(0, 65, 0),
/* {'track': 1, 'velocity': 102, 't': 43392, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 102),
/* {'track': 1, 'velocity': 68, 't': 43392, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 68),
/* {'track': 1, 'velocity': 67, 't': 43392, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 67),
/* {'track': 1, 'velocity': 67, 't': 43392, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 67),
/* {'track': 1, 'velocity': 0, 't': 43424, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 104, 't': 43456, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 104),
/* {'track': 1, 'velocity': 0, 't': 43488, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 43508, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 43508, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 43508, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 0),
/* {'track': 1, 'velocity': 113, 't': 43520, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 113),
/* {'track': 1, 'velocity': 73, 't': 43520, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 73),
/* {'track': 1, 'velocity': 75, 't': 43520, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 75),
/* {'track': 1, 'velocity': 74, 't': 43520, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 74),
/* {'track': 1, 'velocity': 0, 't': 43552, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 92, 't': 43584, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 92),
/* {'track': 1, 'velocity': 0, 't': 43616, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 43636, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 43636, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 43636, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 102, 't': 43648, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 102),
/* {'track': 1, 'velocity': 76, 't': 43648, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 76),
/* {'track': 1, 'velocity': 75, 't': 43648, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 75),
/* {'track': 1, 'velocity': 75, 't': 43648, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 75),
/* {'track': 1, 'velocity': 0, 't': 43680, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 84, 't': 43712, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 84),
/* {'track': 1, 'velocity': 0, 't': 43744, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 43764, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 43764, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 43764, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 87, 't': 43776, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 87),
/* {'track': 1, 'velocity': 0, 't': 43808, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 85, 't': 43840, 'channel': 1, 'pitch': 65} */
PAUSE(32),
NOTE(0, 65, 85),
/* {'track': 1, 'velocity': 0, 't': 43872, 'channel': 1, 'pitch': 65} */
PAUSE(32),
NOTE(0, 65, 0),
/* {'track': 1, 'velocity': 103, 't': 43904, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 103),
/* {'track': 1, 'velocity': 69, 't': 43904, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 69),
/* {'track': 1, 'velocity': 69, 't': 43904, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 69),
/* {'track': 1, 'velocity': 70, 't': 43904, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 70),
/* {'track': 1, 'velocity': 0, 't': 43936, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 105, 't': 43968, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 105),
/* {'track': 1, 'velocity': 0, 't': 43982, 'channel': 2, 'pitch': 41} */
PAUSE(14),
NOTE(8, 41, 0),
/* {'track': 1, 'velocity': 0, 't': 44000, 'channel': 1, 'pitch': 72} */
PAUSE(18),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 44020, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 44020, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 44020, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 105, 't': 44032, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 105),
/* {'track': 1, 'velocity': 73, 't': 44032, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 73),
/* {'track': 1, 'velocity': 72, 't': 44032, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 72),
/* {'track': 1, 'velocity': 71, 't': 44032, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 71),
/* {'track': 1, 'velocity': 0, 't': 44064, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 91, 't': 44096, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 91),
/* {'track': 1, 'velocity': 0, 't': 44128, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 44148, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 44148, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 44148, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 101, 't': 44160, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 101),
/* {'track': 1, 'velocity': 74, 't': 44160, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 74),
/* {'track': 1, 'velocity': 77, 't': 44160, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 77),
/* {'track': 1, 'velocity': 74, 't': 44160, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 74),
/* {'track': 1, 'velocity': 0, 't': 44192, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 90, 't': 44224, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 90),
/* {'track': 1, 'velocity': 0, 't': 44256, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 44276, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 44276, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 44276, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 89, 't': 44288, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 89),
/* {'track': 1, 'velocity': 0, 't': 44320, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 85, 't': 44352, 'channel': 1, 'pitch': 65} */
PAUSE(32),
NOTE(0, 65, 85),
/* {'track': 1, 'velocity': 0, 't': 44384, 'channel': 1, 'pitch': 65} */
PAUSE(32),
NOTE(0, 65, 0),
/* {'track': 1, 'velocity': 105, 't': 44416, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 105),
/* {'track': 1, 'velocity': 68, 't': 44416, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 68),
/* {'track': 1, 'velocity': 69, 't': 44416, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 69),
/* {'track': 1, 'velocity': 67, 't': 44416, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 67),
/* {'track': 1, 'velocity': 0, 't': 44448, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 104, 't': 44480, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 104),
/* {'track': 1, 'velocity': 0, 't': 44512, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 44532, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 44532, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 44532, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 111, 't': 44544, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 111),
/* {'track': 1, 'velocity': 82, 't': 44544, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 82),
/* {'track': 1, 'velocity': 82, 't': 44544, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 82),
/* {'track': 1, 'velocity': 84, 't': 44544, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 84),
/* {'track': 1, 'velocity': 0, 't': 44576, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 94, 't': 44608, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 94),
/* {'track': 1, 'velocity': 0, 't': 44640, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 44660, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 44660, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 44660, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 104, 't': 44672, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 104),
/* {'track': 1, 'velocity': 75, 't': 44672, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 75),
/* {'track': 1, 'velocity': 75, 't': 44672, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 75),
/* {'track': 1, 'velocity': 77, 't': 44672, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 77),
/* {'track': 1, 'velocity': 0, 't': 44704, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 88, 't': 44736, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 88),
/* {'track': 1, 'velocity': 0, 't': 44768, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 44788, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 44788, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 44788, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 84, 't': 44800, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 84),
/* {'track': 1, 'velocity': 0, 't': 44832, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 85, 't': 44864, 'channel': 1, 'pitch': 65} */
PAUSE(32),
NOTE(0, 65, 85),
/* {'track': 1, 'velocity': 0, 't': 44896, 'channel': 1, 'pitch': 65} */
PAUSE(32),
NOTE(0, 65, 0),
/* {'track': 1, 'velocity': 104, 't': 44928, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 104),
/* {'track': 1, 'velocity': 69, 't': 44928, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 69),
/* {'track': 1, 'velocity': 66, 't': 44928, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 66),
/* {'track': 1, 'velocity': 67, 't': 44928, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 67),
/* {'track': 1, 'velocity': 0, 't': 44960, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 107, 't': 44992, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 107),
/* {'track': 1, 'velocity': 0, 't': 45024, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 45044, 'channel': 2, 'pitch': 57} */
PAUSE(20),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 0, 't': 45044, 'channel': 2, 'pitch': 60} */
NOTE(9, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 45044, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 114, 't': 45056, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 114),
/* {'track': 1, 'velocity': 113, 't': 45056, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 113),
/* {'track': 1, 'velocity': 113, 't': 45056, 'channel': 1, 'pitch': 77} */
NOTE(2, 77, 113),
/* {'track': 1, 'velocity': 82, 't': 45056, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 82),
/* {'track': 1, 'velocity': 0, 't': 45088, 'channel': 2, 'pitch': 65} */
PAUSE(32),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 73, 't': 45120, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 73),
/* {'track': 1, 'velocity': 0, 't': 45152, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 45172, 'channel': 1, 'pitch': 69} */
PAUSE(20),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 45172, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 45172, 'channel': 1, 'pitch': 77} */
NOTE(2, 77, 0),
/* {'track': 1, 'velocity': 97, 't': 45184, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 97),
/* {'track': 1, 'velocity': 98, 't': 45184, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 98),
/* {'track': 1, 'velocity': 97, 't': 45184, 'channel': 1, 'pitch': 77} */
NOTE(2, 77, 97),
/* {'track': 1, 'velocity': 80, 't': 45184, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 80),
/* {'track': 1, 'velocity': 0, 't': 45216, 'channel': 2, 'pitch': 65} */
PAUSE(32),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 65, 't': 45248, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 65),
/* {'track': 1, 'velocity': 0, 't': 45280, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 45300, 'channel': 1, 'pitch': 69} */
PAUSE(20),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 45300, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 45300, 'channel': 1, 'pitch': 77} */
NOTE(2, 77, 0),
/* {'track': 1, 'velocity': 65, 't': 45312, 'channel': 2, 'pitch': 57} */
PAUSE(12),
NOTE(8, 57, 65),
/* {'track': 1, 'velocity': 0, 't': 45344, 'channel': 2, 'pitch': 57} */
PAUSE(32),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 67, 't': 45376, 'channel': 2, 'pitch': 53} */
PAUSE(32),
NOTE(8, 53, 67),
/* {'track': 1, 'velocity': 0, 't': 45408, 'channel': 2, 'pitch': 53} */
PAUSE(32),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 86, 't': 45440, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 86),
/* {'track': 1, 'velocity': 88, 't': 45440, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 88),
/* {'track': 1, 'velocity': 86, 't': 45440, 'channel': 1, 'pitch': 77} */
NOTE(2, 77, 86),
/* {'track': 1, 'velocity': 81, 't': 45440, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 81),
/* {'track': 1, 'velocity': 0, 't': 45472, 'channel': 2, 'pitch': 57} */
PAUSE(32),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 82, 't': 45504, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 82),
/* {'track': 1, 'velocity': 0, 't': 45536, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 45556, 'channel': 1, 'pitch': 69} */
PAUSE(20),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 45556, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 45556, 'channel': 1, 'pitch': 77} */
NOTE(2, 77, 0),
/* {'track': 1, 'velocity': 94, 't': 45568, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 94),
/* {'track': 1, 'velocity': 94, 't': 45568, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 94),
/* {'track': 1, 'velocity': 92, 't': 45568, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 92),
/* {'track': 1, 'velocity': 86, 't': 45568, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 86),
/* {'track': 1, 'velocity': 0, 't': 45600, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 73, 't': 45632, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 73),
/* {'track': 1, 'velocity': 0, 't': 45664, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 45684, 'channel': 1, 'pitch': 69} */
PAUSE(20),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 45684, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 45684, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 0),
/* {'track': 1, 'velocity': 96, 't': 45696, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 96),
/* {'track': 1, 'velocity': 96, 't': 45696, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 96),
/* {'track': 1, 'velocity': 96, 't': 45696, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 96),
/* {'track': 1, 'velocity': 78, 't': 45696, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 78),
/* {'track': 1, 'velocity': 0, 't': 45728, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 68, 't': 45760, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 68),
/* {'track': 1, 'velocity': 0, 't': 45792, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 45812, 'channel': 1, 'pitch': 69} */
PAUSE(20),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 45812, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 45812, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 0),
/* {'track': 1, 'velocity': 67, 't': 45824, 'channel': 2, 'pitch': 57} */
PAUSE(12),
NOTE(8, 57, 67),
/* {'track': 1, 'velocity': 0, 't': 45856, 'channel': 2, 'pitch': 57} */
PAUSE(32),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 65, 't': 45888, 'channel': 2, 'pitch': 53} */
PAUSE(32),
NOTE(8, 53, 65),
/* {'track': 1, 'velocity': 0, 't': 45920, 'channel': 2, 'pitch': 53} */
PAUSE(32),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 86, 't': 45952, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 86),
/* {'track': 1, 'velocity': 86, 't': 45952, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 86),
/* {'track': 1, 'velocity': 84, 't': 45952, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 84),
/* {'track': 1, 'velocity': 81, 't': 45952, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 81),
/* {'track': 1, 'velocity': 0, 't': 45984, 'channel': 2, 'pitch': 57} */
PAUSE(32),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 84, 't': 46016, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 84),
/* {'track': 1, 'velocity': 0, 't': 46048, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 46068, 'channel': 1, 'pitch': 69} */
PAUSE(20),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 46068, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 46068, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 0),
/* {'track': 1, 'velocity': 90, 't': 46080, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 90),
/* {'track': 1, 'velocity': 92, 't': 46080, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 92),
/* {'track': 1, 'velocity': 90, 't': 46080, 'channel': 1, 'pitch': 74} */
NOTE(2, 74, 90),
/* {'track': 1, 'velocity': 85, 't': 46080, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 85),
/* {'track': 1, 'velocity': 0, 't': 46112, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 72, 't': 46144, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 72),
/* {'track': 1, 'velocity': 0, 't': 46176, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 46196, 'channel': 1, 'pitch': 69} */
PAUSE(20),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 46196, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 46196, 'channel': 1, 'pitch': 74} */
NOTE(2, 74, 0),
/* {'track': 1, 'velocity': 94, 't': 46208, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 94),
/* {'track': 1, 'velocity': 94, 't': 46208, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 94),
/* {'track': 1, 'velocity': 96, 't': 46208, 'channel': 1, 'pitch': 74} */
NOTE(2, 74, 96),
/* {'track': 1, 'velocity': 81, 't': 46208, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 81),
/* {'track': 1, 'velocity': 0, 't': 46240, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 72, 't': 46272, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 72),
/* {'track': 1, 'velocity': 0, 't': 46304, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 46324, 'channel': 1, 'pitch': 69} */
PAUSE(20),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 46324, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 46324, 'channel': 1, 'pitch': 74} */
NOTE(2, 74, 0),
/* {'track': 1, 'velocity': 67, 't': 46336, 'channel': 2, 'pitch': 57} */
PAUSE(12),
NOTE(8, 57, 67),
/* {'track': 1, 'velocity': 0, 't': 46368, 'channel': 2, 'pitch': 57} */
PAUSE(32),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 65, 't': 46400, 'channel': 2, 'pitch': 53} */
PAUSE(32),
NOTE(8, 53, 65),
/* {'track': 1, 'velocity': 0, 't': 46432, 'channel': 2, 'pitch': 53} */
PAUSE(32),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 85, 't': 46464, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 85),
/* {'track': 1, 'velocity': 84, 't': 46464, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 84),
/* {'track': 1, 'velocity': 88, 't': 46464, 'channel': 1, 'pitch': 74} */
NOTE(2, 74, 88),
/* {'track': 1, 'velocity': 83, 't': 46464, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 83),
/* {'track': 1, 'velocity': 0, 't': 46496, 'channel': 2, 'pitch': 57} */
PAUSE(32),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 82, 't': 46528, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 82),
/* {'track': 1, 'velocity': 0, 't': 46560, 'channel': 2, 'pitch': 60} */
PAUSE(32),
NOTE(8, 60, 0),
/* {'track': 1, 'velocity': 0, 't': 46580, 'channel': 1, 'pitch': 69} */
PAUSE(20),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 46580, 'channel': 1, 'pitch': 72} */
NOTE(1, 72, 0),
/* {'track': 1, 'velocity': 0, 't': 46580, 'channel': 1, 'pitch': 74} */
NOTE(2, 74, 0),
/* {'track': 1, 'velocity': 115, 't': 46592, 'channel': 1, 'pitch': 71} */
PAUSE(12),
NOTE(0, 71, 115),
/* {'track': 1, 'velocity': 113, 't': 46592, 'channel': 1, 'pitch': 74} */
NOTE(1, 74, 113),
/* {'track': 1, 'velocity': 113, 't': 46592, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 113),
/* {'track': 1, 'velocity': 84, 't': 46592, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 84),
/* {'track': 1, 'velocity': 0, 't': 46624, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 70, 't': 46656, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 70),
/* {'track': 1, 'velocity': 0, 't': 46688, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 46708, 'channel': 1, 'pitch': 71} */
PAUSE(20),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 46708, 'channel': 1, 'pitch': 74} */
NOTE(1, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 46708, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 99, 't': 46720, 'channel': 1, 'pitch': 71} */
PAUSE(12),
NOTE(0, 71, 99),
/* {'track': 1, 'velocity': 100, 't': 46720, 'channel': 1, 'pitch': 74} */
NOTE(1, 74, 100),
/* {'track': 1, 'velocity': 97, 't': 46720, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 97),
/* {'track': 1, 'velocity': 80, 't': 46720, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 80),
/* {'track': 1, 'velocity': 0, 't': 46752, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 68, 't': 46784, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 68),
/* {'track': 1, 'velocity': 0, 't': 46816, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 46836, 'channel': 1, 'pitch': 71} */
PAUSE(20),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 46836, 'channel': 1, 'pitch': 74} */
NOTE(1, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 46836, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 71, 't': 46848, 'channel': 2, 'pitch': 57} */
PAUSE(12),
NOTE(8, 57, 71),
/* {'track': 1, 'velocity': 0, 't': 46880, 'channel': 2, 'pitch': 57} */
PAUSE(32),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 65, 't': 46912, 'channel': 2, 'pitch': 53} */
PAUSE(32),
NOTE(8, 53, 65),
/* {'track': 1, 'velocity': 0, 't': 46944, 'channel': 2, 'pitch': 53} */
PAUSE(32),
NOTE(8, 53, 0),
/* {'track': 1, 'velocity': 84, 't': 46976, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 84),
/* {'track': 1, 'velocity': 85, 't': 46976, 'channel': 1, 'pitch': 74} */
NOTE(1, 74, 85),
/* {'track': 1, 'velocity': 87, 't': 46976, 'channel': 1, 'pitch': 83} */
NOTE(2, 83, 87),
/* {'track': 1, 'velocity': 84, 't': 46976, 'channel': 2, 'pitch': 57} */
NOTE(8, 57, 84),
/* {'track': 1, 'velocity': 0, 't': 47008, 'channel': 2, 'pitch': 57} */
PAUSE(32),
NOTE(8, 57, 0),
/* {'track': 1, 'velocity': 82, 't': 47040, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 82),
/* {'track': 1, 'velocity': 0, 't': 47072, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 47092, 'channel': 1, 'pitch': 71} */
PAUSE(20),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 47092, 'channel': 1, 'pitch': 74} */
NOTE(1, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 47092, 'channel': 1, 'pitch': 83} */
NOTE(2, 83, 0),
/* {'track': 1, 'velocity': 79, 't': 47104, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 79),
/* {'track': 1, 'velocity': 88, 't': 47104, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 88),
/* {'track': 1, 'velocity': 88, 't': 47104, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 88),
/* {'track': 1, 'velocity': 90, 't': 47104, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 90),
/* {'track': 1, 'velocity': 0, 't': 47136, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 88, 't': 47168, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 88),
/* {'track': 1, 'velocity': 0, 't': 47200, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 0, 't': 47220, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 47220, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 47220, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 97, 't': 47232, 'channel': 1, 'pitch': 76} */
PAUSE(12),
NOTE(0, 76, 97),
/* {'track': 1, 'velocity': 78, 't': 47232, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 78),
/* {'track': 1, 'velocity': 77, 't': 47232, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 77),
/* {'track': 1, 'velocity': 78, 't': 47232, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 78),
/* {'track': 1, 'velocity': 0, 't': 47264, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 81, 't': 47296, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 81),
/* {'track': 1, 'velocity': 0, 't': 47328, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 47348, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 47348, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 47348, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 83, 't': 47360, 'channel': 1, 'pitch': 68} */
PAUSE(12),
NOTE(0, 68, 83),
/* {'track': 1, 'velocity': 0, 't': 47392, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 83, 't': 47424, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 83),
/* {'track': 1, 'velocity': 0, 't': 47456, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 105, 't': 47488, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 105),
/* {'track': 1, 'velocity': 69, 't': 47488, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 69),
/* {'track': 1, 'velocity': 67, 't': 47488, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 67),
/* {'track': 1, 'velocity': 67, 't': 47488, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 67),
/* {'track': 1, 'velocity': 0, 't': 47520, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 104, 't': 47552, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 104),
/* {'track': 1, 'velocity': 0, 't': 47584, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 47604, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 47604, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 47604, 'channel': 2, 'pitch': 64} */
NOTE(10, 64, 0),
/* {'track': 1, 'velocity': 113, 't': 47616, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 113),
/* {'track': 1, 'velocity': 75, 't': 47616, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 75),
/* {'track': 1, 'velocity': 74, 't': 47616, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 74),
/* {'track': 1, 'velocity': 76, 't': 47616, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 76),
/* {'track': 1, 'velocity': 0, 't': 47648, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 92, 't': 47680, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 92),
/* {'track': 1, 'velocity': 0, 't': 47712, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 0, 't': 47732, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 47732, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 47732, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 0),
/* {'track': 1, 'velocity': 101, 't': 47744, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 101),
/* {'track': 1, 'velocity': 76, 't': 47744, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 76),
/* {'track': 1, 'velocity': 75, 't': 47744, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 75),
/* {'track': 1, 'velocity': 73, 't': 47744, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 73),
/* {'track': 1, 'velocity': 0, 't': 47776, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 84, 't': 47808, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 84),
/* {'track': 1, 'velocity': 0, 't': 47840, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 47860, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 47860, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 47860, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 0),
/* {'track': 1, 'velocity': 87, 't': 47872, 'channel': 1, 'pitch': 68} */
PAUSE(12),
NOTE(0, 68, 87),
/* {'track': 1, 'velocity': 0, 't': 47904, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 83, 't': 47936, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 83),
/* {'track': 1, 'velocity': 0, 't': 47968, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 102, 't': 48000, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 102),
/* {'track': 1, 'velocity': 67, 't': 48000, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 67),
/* {'track': 1, 'velocity': 69, 't': 48000, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 69),
/* {'track': 1, 'velocity': 69, 't': 48000, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 69),
/* {'track': 1, 'velocity': 0, 't': 48032, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 103, 't': 48064, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 103),
/* {'track': 1, 'velocity': 0, 't': 48096, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 48116, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 48116, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 48116, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 0),
/* {'track': 1, 'velocity': 107, 't': 48128, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 107),
/* {'track': 1, 'velocity': 73, 't': 48128, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 73),
/* {'track': 1, 'velocity': 73, 't': 48128, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 73),
/* {'track': 1, 'velocity': 72, 't': 48128, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 72),
/* {'track': 1, 'velocity': 0, 't': 48160, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 91, 't': 48192, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 91),
/* {'track': 1, 'velocity': 0, 't': 48224, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 48244, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 48244, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 48244, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 0),
/* {'track': 1, 'velocity': 102, 't': 48256, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 102),
/* {'track': 1, 'velocity': 74, 't': 48256, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 74),
/* {'track': 1, 'velocity': 74, 't': 48256, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 74),
/* {'track': 1, 'velocity': 74, 't': 48256, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 74),
/* {'track': 1, 'velocity': 0, 't': 48288, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 89, 't': 48320, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 89),
/* {'track': 1, 'velocity': 0, 't': 48352, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 48372, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 48372, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 48372, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 0),
/* {'track': 1, 'velocity': 87, 't': 48384, 'channel': 1, 'pitch': 68} */
PAUSE(12),
NOTE(0, 68, 87),
/* {'track': 1, 'velocity': 0, 't': 48416, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 84, 't': 48448, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 84),
/* {'track': 1, 'velocity': 0, 't': 48480, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 106, 't': 48512, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 106),
/* {'track': 1, 'velocity': 68, 't': 48512, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 68),
/* {'track': 1, 'velocity': 69, 't': 48512, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 69),
/* {'track': 1, 'velocity': 69, 't': 48512, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 69),
/* {'track': 1, 'velocity': 0, 't': 48544, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 103, 't': 48576, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 103),
/* {'track': 1, 'velocity': 0, 't': 48608, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 48628, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 48628, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 48628, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 0),
/* {'track': 1, 'velocity': 109, 't': 48640, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 109),
/* {'track': 1, 'velocity': 80, 't': 48640, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 80),
/* {'track': 1, 'velocity': 81, 't': 48640, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 81),
/* {'track': 1, 'velocity': 82, 't': 48640, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 82),
/* {'track': 1, 'velocity': 0, 't': 48672, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 88, 't': 48704, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 88),
/* {'track': 1, 'velocity': 0, 't': 48736, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 48756, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 48756, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 48756, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 0),
/* {'track': 1, 'velocity': 104, 't': 48768, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 104),
/* {'track': 1, 'velocity': 77, 't': 48768, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 77),
/* {'track': 1, 'velocity': 76, 't': 48768, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 76),
/* {'track': 1, 'velocity': 76, 't': 48768, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 76),
/* {'track': 1, 'velocity': 0, 't': 48800, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 86, 't': 48832, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 86),
/* {'track': 1, 'velocity': 0, 't': 48864, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 48884, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 48884, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 48884, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 0),
/* {'track': 1, 'velocity': 86, 't': 48896, 'channel': 1, 'pitch': 68} */
PAUSE(12),
NOTE(0, 68, 86),
/* {'track': 1, 'velocity': 0, 't': 48928, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 84, 't': 48960, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 84),
/* {'track': 1, 'velocity': 0, 't': 48992, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 104, 't': 49024, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 104),
/* {'track': 1, 'velocity': 67, 't': 49024, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 67),
/* {'track': 1, 'velocity': 67, 't': 49024, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 67),
/* {'track': 1, 'velocity': 69, 't': 49024, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 69),
/* {'track': 1, 'velocity': 0, 't': 49056, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 104, 't': 49088, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 104),
/* {'track': 1, 'velocity': 0, 't': 49120, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 49140, 'channel': 2, 'pitch': 56} */
PAUSE(20),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 0, 't': 49140, 'channel': 2, 'pitch': 59} */
NOTE(9, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 49140, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 0),
/* {'track': 1, 'velocity': 112, 't': 49152, 'channel': 1, 'pitch': 68} */
PAUSE(12),
NOTE(0, 68, 112),
/* {'track': 1, 'velocity': 114, 't': 49152, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 114),
/* {'track': 1, 'velocity': 113, 't': 49152, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 113),
/* {'track': 1, 'velocity': 82, 't': 49152, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 82),
/* {'track': 1, 'velocity': 0, 't': 49184, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 73, 't': 49216, 'channel': 2, 'pitch': 63} */
PAUSE(32),
NOTE(8, 63, 73),
/* {'track': 1, 'velocity': 0, 't': 49248, 'channel': 2, 'pitch': 63} */
PAUSE(32),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 49268, 'channel': 1, 'pitch': 68} */
PAUSE(20),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 49268, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 49268, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 0),
/* {'track': 1, 'velocity': 99, 't': 49280, 'channel': 1, 'pitch': 68} */
PAUSE(12),
NOTE(0, 68, 99),
/* {'track': 1, 'velocity': 97, 't': 49280, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 97),
/* {'track': 1, 'velocity': 99, 't': 49280, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 99),
/* {'track': 1, 'velocity': 76, 't': 49280, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 76),
/* {'track': 1, 'velocity': 0, 't': 49312, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 63, 't': 49344, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 63),
/* {'track': 1, 'velocity': 0, 't': 49376, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 49396, 'channel': 1, 'pitch': 68} */
PAUSE(20),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 49396, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 49396, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 0),
/* {'track': 1, 'velocity': 65, 't': 49408, 'channel': 2, 'pitch': 56} */
PAUSE(12),
NOTE(8, 56, 65),
/* {'track': 1, 'velocity': 0, 't': 49440, 'channel': 2, 'pitch': 56} */
PAUSE(32),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 67, 't': 49472, 'channel': 2, 'pitch': 52} */
PAUSE(32),
NOTE(8, 52, 67),
/* {'track': 1, 'velocity': 0, 't': 49504, 'channel': 2, 'pitch': 52} */
PAUSE(32),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 85, 't': 49536, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 85),
/* {'track': 1, 'velocity': 85, 't': 49536, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 85),
/* {'track': 1, 'velocity': 87, 't': 49536, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 87),
/* {'track': 1, 'velocity': 83, 't': 49536, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 83),
/* {'track': 1, 'velocity': 0, 't': 49568, 'channel': 2, 'pitch': 56} */
PAUSE(32),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 82, 't': 49600, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 82),
/* {'track': 1, 'velocity': 0, 't': 49632, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 49652, 'channel': 1, 'pitch': 68} */
PAUSE(20),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 49652, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 49652, 'channel': 1, 'pitch': 76} */
NOTE(2, 76, 0),
/* {'track': 1, 'velocity': 93, 't': 49664, 'channel': 1, 'pitch': 68} */
PAUSE(12),
NOTE(0, 68, 93),
/* {'track': 1, 'velocity': 95, 't': 49664, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 95),
/* {'track': 1, 'velocity': 94, 't': 49664, 'channel': 1, 'pitch': 75} */
NOTE(2, 75, 94),
/* {'track': 1, 'velocity': 90, 't': 49664, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 90),
/* {'track': 1, 'velocity': 0, 't': 49696, 'channel': 2, 'pitch': 63} */
PAUSE(32),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 71, 't': 49728, 'channel': 2, 'pitch': 61} */
PAUSE(32),
NOTE(8, 61, 71),
/* {'track': 1, 'velocity': 0, 't': 49760, 'channel': 2, 'pitch': 61} */
PAUSE(32),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 49780, 'channel': 1, 'pitch': 68} */
PAUSE(20),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 49780, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 49780, 'channel': 1, 'pitch': 75} */
NOTE(2, 75, 0),
/* {'track': 1, 'velocity': 95, 't': 49792, 'channel': 1, 'pitch': 68} */
PAUSE(12),
NOTE(0, 68, 95),
/* {'track': 1, 'velocity': 93, 't': 49792, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 93),
/* {'track': 1, 'velocity': 96, 't': 49792, 'channel': 1, 'pitch': 75} */
NOTE(2, 75, 96),
/* {'track': 1, 'velocity': 81, 't': 49792, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 81),
/* {'track': 1, 'velocity': 0, 't': 49824, 'channel': 2, 'pitch': 63} */
PAUSE(32),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 67, 't': 49856, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 67),
/* {'track': 1, 'velocity': 0, 't': 49888, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 49908, 'channel': 1, 'pitch': 68} */
PAUSE(20),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 49908, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 49908, 'channel': 1, 'pitch': 75} */
NOTE(2, 75, 0),
/* {'track': 1, 'velocity': 66, 't': 49920, 'channel': 2, 'pitch': 56} */
PAUSE(12),
NOTE(8, 56, 66),
/* {'track': 1, 'velocity': 0, 't': 49952, 'channel': 2, 'pitch': 56} */
PAUSE(32),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 65, 't': 49984, 'channel': 2, 'pitch': 52} */
PAUSE(32),
NOTE(8, 52, 65),
/* {'track': 1, 'velocity': 0, 't': 50016, 'channel': 2, 'pitch': 52} */
PAUSE(32),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 86, 't': 50048, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 86),
/* {'track': 1, 'velocity': 85, 't': 50048, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 85),
/* {'track': 1, 'velocity': 85, 't': 50048, 'channel': 1, 'pitch': 75} */
NOTE(2, 75, 85),
/* {'track': 1, 'velocity': 82, 't': 50048, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 82),
/* {'track': 1, 'velocity': 0, 't': 50080, 'channel': 2, 'pitch': 56} */
PAUSE(32),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 82, 't': 50112, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 82),
/* {'track': 1, 'velocity': 0, 't': 50144, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 50164, 'channel': 1, 'pitch': 68} */
PAUSE(20),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 50164, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 50164, 'channel': 1, 'pitch': 75} */
NOTE(2, 75, 0),
/* {'track': 1, 'velocity': 92, 't': 50176, 'channel': 1, 'pitch': 68} */
PAUSE(12),
NOTE(0, 68, 92),
/* {'track': 1, 'velocity': 91, 't': 50176, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 91),
/* {'track': 1, 'velocity': 90, 't': 50176, 'channel': 1, 'pitch': 73} */
NOTE(2, 73, 90),
/* {'track': 1, 'velocity': 85, 't': 50176, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 85),
/* {'track': 1, 'velocity': 0, 't': 50208, 'channel': 2, 'pitch': 61} */
PAUSE(32),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 70, 't': 50240, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 70),
/* {'track': 1, 'velocity': 0, 't': 50272, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 50292, 'channel': 1, 'pitch': 68} */
PAUSE(20),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 50292, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 50292, 'channel': 1, 'pitch': 73} */
NOTE(2, 73, 0),
/* {'track': 1, 'velocity': 95, 't': 50304, 'channel': 1, 'pitch': 68} */
PAUSE(12),
NOTE(0, 68, 95),
/* {'track': 1, 'velocity': 95, 't': 50304, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 95),
/* {'track': 1, 'velocity': 93, 't': 50304, 'channel': 1, 'pitch': 73} */
NOTE(2, 73, 93),
/* {'track': 1, 'velocity': 80, 't': 50304, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 80),
/* {'track': 1, 'velocity': 0, 't': 50336, 'channel': 2, 'pitch': 61} */
PAUSE(32),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 73, 't': 50368, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 73),
/* {'track': 1, 'velocity': 0, 't': 50400, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 50420, 'channel': 1, 'pitch': 68} */
PAUSE(20),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 50420, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 50420, 'channel': 1, 'pitch': 73} */
NOTE(2, 73, 0),
/* {'track': 1, 'velocity': 68, 't': 50432, 'channel': 2, 'pitch': 56} */
PAUSE(12),
NOTE(8, 56, 68),
/* {'track': 1, 'velocity': 0, 't': 50464, 'channel': 2, 'pitch': 56} */
PAUSE(32),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 64, 't': 50496, 'channel': 2, 'pitch': 52} */
PAUSE(32),
NOTE(8, 52, 64),
/* {'track': 1, 'velocity': 0, 't': 50528, 'channel': 2, 'pitch': 52} */
PAUSE(32),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 85, 't': 50560, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 85),
/* {'track': 1, 'velocity': 84, 't': 50560, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 84),
/* {'track': 1, 'velocity': 86, 't': 50560, 'channel': 1, 'pitch': 73} */
NOTE(2, 73, 86),
/* {'track': 1, 'velocity': 83, 't': 50560, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 83),
/* {'track': 1, 'velocity': 0, 't': 50592, 'channel': 2, 'pitch': 56} */
PAUSE(32),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 84, 't': 50624, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 84),
/* {'track': 1, 'velocity': 0, 't': 50656, 'channel': 2, 'pitch': 59} */
PAUSE(32),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 50676, 'channel': 1, 'pitch': 68} */
PAUSE(20),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 50676, 'channel': 1, 'pitch': 71} */
NOTE(1, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 50676, 'channel': 1, 'pitch': 73} */
NOTE(2, 73, 0),
/* {'track': 1, 'velocity': 113, 't': 50688, 'channel': 1, 'pitch': 70} */
PAUSE(12),
NOTE(0, 70, 113),
/* {'track': 1, 'velocity': 116, 't': 50688, 'channel': 1, 'pitch': 73} */
NOTE(1, 73, 116),
/* {'track': 1, 'velocity': 114, 't': 50688, 'channel': 1, 'pitch': 80} */
NOTE(2, 80, 114),
/* {'track': 1, 'velocity': 85, 't': 50688, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 85),
/* {'track': 1, 'velocity': 0, 't': 50720, 'channel': 2, 'pitch': 61} */
PAUSE(32),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 71, 't': 50752, 'channel': 2, 'pitch': 58} */
PAUSE(32),
NOTE(8, 58, 71),
/* {'track': 1, 'velocity': 0, 't': 50784, 'channel': 2, 'pitch': 58} */
PAUSE(32),
NOTE(8, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 50804, 'channel': 1, 'pitch': 70} */
PAUSE(20),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 50804, 'channel': 1, 'pitch': 73} */
NOTE(1, 73, 0),
/* {'track': 1, 'velocity': 0, 't': 50804, 'channel': 1, 'pitch': 80} */
NOTE(2, 80, 0),
/* {'track': 1, 'velocity': 97, 't': 50816, 'channel': 1, 'pitch': 70} */
PAUSE(12),
NOTE(0, 70, 97),
/* {'track': 1, 'velocity': 96, 't': 50816, 'channel': 1, 'pitch': 73} */
NOTE(1, 73, 96),
/* {'track': 1, 'velocity': 98, 't': 50816, 'channel': 1, 'pitch': 80} */
NOTE(2, 80, 98),
/* {'track': 1, 'velocity': 82, 't': 50816, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 82),
/* {'track': 1, 'velocity': 0, 't': 50848, 'channel': 2, 'pitch': 61} */
PAUSE(32),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 70, 't': 50880, 'channel': 2, 'pitch': 58} */
PAUSE(32),
NOTE(8, 58, 70),
/* {'track': 1, 'velocity': 0, 't': 50912, 'channel': 2, 'pitch': 58} */
PAUSE(32),
NOTE(8, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 50932, 'channel': 1, 'pitch': 70} */
PAUSE(20),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 50932, 'channel': 1, 'pitch': 73} */
NOTE(1, 73, 0),
/* {'track': 1, 'velocity': 0, 't': 50932, 'channel': 1, 'pitch': 80} */
NOTE(2, 80, 0),
/* {'track': 1, 'velocity': 68, 't': 50944, 'channel': 2, 'pitch': 56} */
PAUSE(12),
NOTE(8, 56, 68),
/* {'track': 1, 'velocity': 0, 't': 50976, 'channel': 2, 'pitch': 56} */
PAUSE(32),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 67, 't': 51008, 'channel': 2, 'pitch': 52} */
PAUSE(32),
NOTE(8, 52, 67),
/* {'track': 1, 'velocity': 0, 't': 51040, 'channel': 2, 'pitch': 52} */
PAUSE(32),
NOTE(8, 52, 0),
/* {'track': 1, 'velocity': 87, 't': 51072, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 87),
/* {'track': 1, 'velocity': 84, 't': 51072, 'channel': 1, 'pitch': 73} */
NOTE(1, 73, 84),
/* {'track': 1, 'velocity': 85, 't': 51072, 'channel': 1, 'pitch': 82} */
NOTE(2, 82, 85),
/* {'track': 1, 'velocity': 82, 't': 51072, 'channel': 2, 'pitch': 56} */
NOTE(8, 56, 82),
/* {'track': 1, 'velocity': 0, 't': 51104, 'channel': 2, 'pitch': 56} */
PAUSE(32),
NOTE(8, 56, 0),
/* {'track': 1, 'velocity': 81, 't': 51136, 'channel': 2, 'pitch': 58} */
PAUSE(32),
NOTE(8, 58, 81),
/* {'track': 1, 'velocity': 0, 't': 51168, 'channel': 2, 'pitch': 58} */
PAUSE(32),
NOTE(8, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 51188, 'channel': 1, 'pitch': 70} */
PAUSE(20),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 51188, 'channel': 1, 'pitch': 73} */
NOTE(1, 73, 0),
/* {'track': 1, 'velocity': 0, 't': 51188, 'channel': 1, 'pitch': 82} */
NOTE(2, 82, 0),
/* {'track': 1, 'velocity': 81, 't': 51200, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 81),
/* {'track': 1, 'velocity': 88, 't': 51200, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 88),
/* {'track': 1, 'velocity': 88, 't': 51200, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 88),
/* {'track': 1, 'velocity': 88, 't': 51200, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 88),
/* {'track': 1, 'velocity': 0, 't': 51232, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 88, 't': 51264, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 88),
/* {'track': 1, 'velocity': 0, 't': 51296, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 51316, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 51316, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 51316, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 0),
/* {'track': 1, 'velocity': 100, 't': 51328, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 100),
/* {'track': 1, 'velocity': 79, 't': 51328, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 79),
/* {'track': 1, 'velocity': 75, 't': 51328, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 75),
/* {'track': 1, 'velocity': 79, 't': 51328, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 79),
/* {'track': 1, 'velocity': 0, 't': 51360, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 82, 't': 51392, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 82),
/* {'track': 1, 'velocity': 0, 't': 51424, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 51444, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 51444, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 51444, 'channel': 2, 'pitch': 63} */
NOTE(10, 63, 0),
/* {'track': 1, 'velocity': 84, 't': 51456, 'channel': 1, 'pitch': 67} */
PAUSE(12),
NOTE(0, 67, 84),
/* {'track': 1, 'velocity': 0, 't': 51488, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 85, 't': 51520, 'channel': 1, 'pitch': 63} */
PAUSE(32),
NOTE(0, 63, 85),
/* {'track': 1, 'velocity': 0, 't': 51552, 'channel': 1, 'pitch': 63} */
PAUSE(32),
NOTE(0, 63, 0),
/* {'track': 1, 'velocity': 105, 't': 51584, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 105),
/* {'track': 1, 'velocity': 68, 't': 51584, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 68),
/* {'track': 1, 'velocity': 67, 't': 51584, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 67),
/* {'track': 1, 'velocity': 0, 't': 51616, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 106, 't': 51648, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 106),
/* {'track': 1, 'velocity': 0, 't': 51680, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 51700, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 51700, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 110, 't': 51712, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 110),
/* {'track': 1, 'velocity': 85, 't': 51712, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 85),
/* {'track': 1, 'velocity': 85, 't': 51712, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 85),
/* {'track': 1, 'velocity': 85, 't': 51712, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 85),
/* {'track': 1, 'velocity': 0, 't': 51744, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 88, 't': 51776, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 88),
/* {'track': 1, 'velocity': 0, 't': 51808, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 51828, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 51828, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 51828, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 103, 't': 51840, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 103),
/* {'track': 1, 'velocity': 77, 't': 51840, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 77),
/* {'track': 1, 'velocity': 76, 't': 51840, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 76),
/* {'track': 1, 'velocity': 77, 't': 51840, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 77),
/* {'track': 1, 'velocity': 0, 't': 51872, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 87, 't': 51904, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 87),
/* {'track': 1, 'velocity': 0, 't': 51936, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 51956, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 51956, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 51956, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 87, 't': 51968, 'channel': 1, 'pitch': 67} */
PAUSE(12),
NOTE(0, 67, 87),
/* {'track': 1, 'velocity': 0, 't': 52000, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 85, 't': 52032, 'channel': 1, 'pitch': 63} */
PAUSE(32),
NOTE(0, 63, 85),
/* {'track': 1, 'velocity': 0, 't': 52064, 'channel': 1, 'pitch': 63} */
PAUSE(32),
NOTE(0, 63, 0),
/* {'track': 1, 'velocity': 104, 't': 52096, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 104),
/* {'track': 1, 'velocity': 69, 't': 52096, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 69),
/* {'track': 1, 'velocity': 69, 't': 52096, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 69),
/* {'track': 1, 'velocity': 66, 't': 52096, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 66),
/* {'track': 1, 'velocity': 0, 't': 52128, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 105, 't': 52160, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 105),
/* {'track': 1, 'velocity': 0, 't': 52192, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 52212, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 52212, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 52212, 'channel': 2, 'pitch': 62} */
NOTE(10, 62, 0),
/* {'track': 1, 'velocity': 108, 't': 52224, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 108),
/* {'track': 1, 'velocity': 74, 't': 52224, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 74),
/* {'track': 1, 'velocity': 74, 't': 52224, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 74),
/* {'track': 1, 'velocity': 74, 't': 52224, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 74),
/* {'track': 1, 'velocity': 0, 't': 52256, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 91, 't': 52288, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 91),
/* {'track': 1, 'velocity': 0, 't': 52320, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 52340, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 52340, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 52340, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 0),
/* {'track': 1, 'velocity': 104, 't': 52352, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 104),
/* {'track': 1, 'velocity': 74, 't': 52352, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 74),
/* {'track': 1, 'velocity': 76, 't': 52352, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 76),
/* {'track': 1, 'velocity': 76, 't': 52352, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 76),
/* {'track': 1, 'velocity': 0, 't': 52384, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 89, 't': 52416, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 89),
/* {'track': 1, 'velocity': 0, 't': 52448, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 52468, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 52468, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 52468, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 0),
/* {'track': 1, 'velocity': 88, 't': 52480, 'channel': 1, 'pitch': 67} */
PAUSE(12),
NOTE(0, 67, 88),
/* {'track': 1, 'velocity': 0, 't': 52512, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 84, 't': 52544, 'channel': 1, 'pitch': 63} */
PAUSE(32),
NOTE(0, 63, 84),
/* {'track': 1, 'velocity': 0, 't': 52576, 'channel': 1, 'pitch': 63} */
PAUSE(32),
NOTE(0, 63, 0),
/* {'track': 1, 'velocity': 104, 't': 52608, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 104),
/* {'track': 1, 'velocity': 66, 't': 52608, 'channel': 2, 'pitch': 55} */
NOTE(8, 55, 66),
/* {'track': 1, 'velocity': 66, 't': 52608, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 66),
/* {'track': 1, 'velocity': 68, 't': 52608, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 68),
/* {'track': 1, 'velocity': 0, 't': 52640, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 105, 't': 52672, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 105),
/* {'track': 1, 'velocity': 0, 't': 52704, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 52724, 'channel': 2, 'pitch': 55} */
PAUSE(20),
NOTE(8, 55, 0),
/* {'track': 1, 'velocity': 0, 't': 52724, 'channel': 2, 'pitch': 58} */
NOTE(9, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 52724, 'channel': 2, 'pitch': 61} */
NOTE(10, 61, 0),
/* {'track': 1, 'velocity': 122, 't': 52736, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 122),
/* {'track': 1, 'velocity': 89, 't': 52736, 'channel': 2, 'pitch': 58} */
NOTE(8, 58, 89),
/* {'track': 1, 'velocity': 90, 't': 52736, 'channel': 2, 'pitch': 61} */
NOTE(9, 61, 90),
/* {'track': 1, 'velocity': 89, 't': 52736, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 89),
/* {'track': 1, 'velocity': 0, 't': 52768, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 93, 't': 52800, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 93),
/* {'track': 1, 'velocity': 0, 't': 52832, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 52852, 'channel': 2, 'pitch': 58} */
PAUSE(20),
NOTE(8, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 52852, 'channel': 2, 'pitch': 61} */
NOTE(9, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 52852, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 101, 't': 52864, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 101),
/* {'track': 1, 'velocity': 75, 't': 52864, 'channel': 2, 'pitch': 58} */
NOTE(8, 58, 75),
/* {'track': 1, 'velocity': 75, 't': 52864, 'channel': 2, 'pitch': 61} */
NOTE(9, 61, 75),
/* {'track': 1, 'velocity': 77, 't': 52864, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 77),
/* {'track': 1, 'velocity': 0, 't': 52896, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 79, 't': 52928, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 79),
/* {'track': 1, 'velocity': 0, 't': 52960, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 0, 't': 52980, 'channel': 2, 'pitch': 58} */
PAUSE(20),
NOTE(8, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 52980, 'channel': 2, 'pitch': 61} */
NOTE(9, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 52980, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 83, 't': 52992, 'channel': 1, 'pitch': 70} */
PAUSE(12),
NOTE(0, 70, 83),
/* {'track': 1, 'velocity': 0, 't': 53024, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 88, 't': 53056, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 88),
/* {'track': 1, 'velocity': 0, 't': 53088, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 101, 't': 53120, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 101),
/* {'track': 1, 'velocity': 67, 't': 53120, 'channel': 2, 'pitch': 58} */
NOTE(8, 58, 67),
/* {'track': 1, 'velocity': 69, 't': 53120, 'channel': 2, 'pitch': 61} */
NOTE(9, 61, 69),
/* {'track': 1, 'velocity': 68, 't': 53120, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 68),
/* {'track': 1, 'velocity': 0, 't': 53152, 'channel': 1, 'pitch': 70} */
PAUSE(32),
NOTE(0, 70, 0),
/* {'track': 1, 'velocity': 105, 't': 53184, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 105),
/* {'track': 1, 'velocity': 0, 't': 53216, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 0, 't': 53236, 'channel': 2, 'pitch': 58} */
PAUSE(20),
NOTE(8, 58, 0),
/* {'track': 1, 'velocity': 0, 't': 53236, 'channel': 2, 'pitch': 61} */
NOTE(9, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 53236, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 113, 't': 53248, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 113),
/* {'track': 1, 'velocity': 78, 't': 53248, 'channel': 2, 'pitch': 59} */
NOTE(8, 59, 78),
/* {'track': 1, 'velocity': 78, 't': 53248, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 78),
/* {'track': 1, 'velocity': 76, 't': 53248, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 76),
/* {'track': 1, 'velocity': 0, 't': 53280, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 94, 't': 53312, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 94),
/* {'track': 1, 'velocity': 0, 't': 53344, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 53364, 'channel': 2, 'pitch': 59} */
PAUSE(20),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 53364, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 53364, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 99, 't': 53376, 'channel': 1, 'pitch': 79} */
PAUSE(12),
NOTE(0, 79, 99),
/* {'track': 1, 'velocity': 74, 't': 53376, 'channel': 2, 'pitch': 59} */
NOTE(8, 59, 74),
/* {'track': 1, 'velocity': 76, 't': 53376, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 76),
/* {'track': 1, 'velocity': 77, 't': 53376, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 77),
/* {'track': 1, 'velocity': 0, 't': 53408, 'channel': 1, 'pitch': 79} */
PAUSE(32),
NOTE(0, 79, 0),
/* {'track': 1, 'velocity': 83, 't': 53440, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 83),
/* {'track': 1, 'velocity': 0, 't': 53472, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 53492, 'channel': 2, 'pitch': 59} */
PAUSE(20),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 53492, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 53492, 'channel': 2, 'pitch': 67} */
NOTE(10, 67, 0),
/* {'track': 1, 'velocity': 86, 't': 53504, 'channel': 1, 'pitch': 71} */
PAUSE(12),
NOTE(0, 71, 86),
/* {'track': 1, 'velocity': 0, 't': 53536, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 83, 't': 53568, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 83),
/* {'track': 1, 'velocity': 0, 't': 53600, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 102, 't': 53632, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 102),
/* {'track': 1, 'velocity': 69, 't': 53632, 'channel': 2, 'pitch': 59} */
NOTE(8, 59, 69),
/* {'track': 1, 'velocity': 67, 't': 53632, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 67),
/* {'track': 1, 'velocity': 0, 't': 53664, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 106, 't': 53696, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 106),
/* {'track': 1, 'velocity': 0, 't': 53728, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 53748, 'channel': 2, 'pitch': 59} */
PAUSE(20),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 53748, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 110, 't': 53760, 'channel': 1, 'pitch': 78} */
PAUSE(12),
NOTE(0, 78, 110),
/* {'track': 1, 'velocity': 87, 't': 53760, 'channel': 2, 'pitch': 59} */
NOTE(8, 59, 87),
/* {'track': 1, 'velocity': 85, 't': 53760, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 85),
/* {'track': 1, 'velocity': 87, 't': 53760, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 87),
/* {'track': 1, 'velocity': 0, 't': 53792, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 89, 't': 53824, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 89),
/* {'track': 1, 'velocity': 0, 't': 53856, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 53876, 'channel': 2, 'pitch': 59} */
PAUSE(20),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 53876, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 53876, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 0),
/* {'track': 1, 'velocity': 105, 't': 53888, 'channel': 1, 'pitch': 78} */
PAUSE(12),
NOTE(0, 78, 105),
/* {'track': 1, 'velocity': 79, 't': 53888, 'channel': 2, 'pitch': 59} */
NOTE(8, 59, 79),
/* {'track': 1, 'velocity': 77, 't': 53888, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 77),
/* {'track': 1, 'velocity': 77, 't': 53888, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 77),
/* {'track': 1, 'velocity': 0, 't': 53920, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 86, 't': 53952, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 53984, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 54004, 'channel': 2, 'pitch': 59} */
PAUSE(20),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 54004, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 54004, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 0),
/* {'track': 1, 'velocity': 86, 't': 54016, 'channel': 1, 'pitch': 71} */
PAUSE(12),
NOTE(0, 71, 86),
/* {'track': 1, 'velocity': 0, 't': 54048, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 85, 't': 54080, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 85),
/* {'track': 1, 'velocity': 0, 't': 54112, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 105, 't': 54144, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 105),
/* {'track': 1, 'velocity': 66, 't': 54144, 'channel': 2, 'pitch': 59} */
NOTE(8, 59, 66),
/* {'track': 1, 'velocity': 67, 't': 54144, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 67),
/* {'track': 1, 'velocity': 70, 't': 54144, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 70),
/* {'track': 1, 'velocity': 0, 't': 54176, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 106, 't': 54208, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 106),
/* {'track': 1, 'velocity': 0, 't': 54240, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 54260, 'channel': 2, 'pitch': 59} */
PAUSE(20),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 54260, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 54260, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 0),
/* {'track': 1, 'velocity': 107, 't': 54272, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 107),
/* {'track': 1, 'velocity': 75, 't': 54272, 'channel': 2, 'pitch': 59} */
NOTE(8, 59, 75),
/* {'track': 1, 'velocity': 73, 't': 54272, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 73),
/* {'track': 1, 'velocity': 74, 't': 54272, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 74),
/* {'track': 1, 'velocity': 0, 't': 54304, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 91, 't': 54336, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 91),
/* {'track': 1, 'velocity': 0, 't': 54368, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 54388, 'channel': 2, 'pitch': 59} */
PAUSE(20),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 54388, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 54388, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 0),
/* {'track': 1, 'velocity': 102, 't': 54400, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 102),
/* {'track': 1, 'velocity': 76, 't': 54400, 'channel': 2, 'pitch': 59} */
NOTE(8, 59, 76),
/* {'track': 1, 'velocity': 76, 't': 54400, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 76),
/* {'track': 1, 'velocity': 73, 't': 54400, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 73),
/* {'track': 1, 'velocity': 0, 't': 54432, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 87, 't': 54464, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 87),
/* {'track': 1, 'velocity': 0, 't': 54496, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 54516, 'channel': 2, 'pitch': 59} */
PAUSE(20),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 54516, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 54516, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 0),
/* {'track': 1, 'velocity': 86, 't': 54528, 'channel': 1, 'pitch': 71} */
PAUSE(12),
NOTE(0, 71, 86),
/* {'track': 1, 'velocity': 0, 't': 54560, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 85, 't': 54592, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 85),
/* {'track': 1, 'velocity': 0, 't': 54624, 'channel': 1, 'pitch': 67} */
PAUSE(32),
NOTE(0, 67, 0),
/* {'track': 1, 'velocity': 103, 't': 54656, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 103),
/* {'track': 1, 'velocity': 70, 't': 54656, 'channel': 2, 'pitch': 59} */
NOTE(8, 59, 70),
/* {'track': 1, 'velocity': 70, 't': 54656, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 70),
/* {'track': 1, 'velocity': 69, 't': 54656, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 69),
/* {'track': 1, 'velocity': 0, 't': 54688, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 107, 't': 54720, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 107),
/* {'track': 1, 'velocity': 0, 't': 54752, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 54772, 'channel': 2, 'pitch': 59} */
PAUSE(20),
NOTE(8, 59, 0),
/* {'track': 1, 'velocity': 0, 't': 54772, 'channel': 2, 'pitch': 62} */
NOTE(9, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 54772, 'channel': 2, 'pitch': 65} */
NOTE(10, 65, 0),
/* {'track': 1, 'velocity': 122, 't': 54784, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 122),
/* {'track': 1, 'velocity': 90, 't': 54784, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 90),
/* {'track': 1, 'velocity': 90, 't': 54784, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 90),
/* {'track': 1, 'velocity': 90, 't': 54784, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 90),
/* {'track': 1, 'velocity': 0, 't': 54816, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 95, 't': 54848, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 95),
/* {'track': 1, 'velocity': 0, 't': 54880, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 54900, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 54900, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 54900, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 0),
/* {'track': 1, 'velocity': 98, 't': 54912, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 98),
/* {'track': 1, 'velocity': 75, 't': 54912, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 75),
/* {'track': 1, 'velocity': 77, 't': 54912, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 77),
/* {'track': 1, 'velocity': 78, 't': 54912, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 78),
/* {'track': 1, 'velocity': 0, 't': 54944, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 81, 't': 54976, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 81),
/* {'track': 1, 'velocity': 0, 't': 55008, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 55028, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 55028, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 55028, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 0),
/* {'track': 1, 'velocity': 84, 't': 55040, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 84),
/* {'track': 1, 'velocity': 0, 't': 55072, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 88, 't': 55104, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 88),
/* {'track': 1, 'velocity': 0, 't': 55136, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 102, 't': 55168, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 102),
/* {'track': 1, 'velocity': 69, 't': 55168, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 69),
/* {'track': 1, 'velocity': 68, 't': 55168, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 68),
/* {'track': 1, 'velocity': 68, 't': 55168, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 68),
/* {'track': 1, 'velocity': 0, 't': 55200, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 105, 't': 55232, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 105),
/* {'track': 1, 'velocity': 0, 't': 55264, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 0, 't': 55284, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 55284, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 55284, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 0),
/* {'track': 1, 'velocity': 116, 't': 55296, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 116),
/* {'track': 1, 'velocity': 77, 't': 55296, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 77),
/* {'track': 1, 'velocity': 76, 't': 55296, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 76),
/* {'track': 1, 'velocity': 77, 't': 55296, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 77),
/* {'track': 1, 'velocity': 0, 't': 55328, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 93, 't': 55360, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 93),
/* {'track': 1, 'velocity': 0, 't': 55392, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 55412, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 55412, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 55412, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 0),
/* {'track': 1, 'velocity': 99, 't': 55424, 'channel': 1, 'pitch': 83} */
PAUSE(12),
NOTE(0, 83, 99),
/* {'track': 1, 'velocity': 77, 't': 55424, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 77),
/* {'track': 1, 'velocity': 77, 't': 55424, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 77),
/* {'track': 1, 'velocity': 77, 't': 55424, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 77),
/* {'track': 1, 'velocity': 0, 't': 55456, 'channel': 1, 'pitch': 83} */
PAUSE(32),
NOTE(0, 83, 0),
/* {'track': 1, 'velocity': 86, 't': 55488, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 86),
/* {'track': 1, 'velocity': 0, 't': 55520, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 55540, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 55540, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 55540, 'channel': 2, 'pitch': 71} */
NOTE(10, 71, 0),
/* {'track': 1, 'velocity': 87, 't': 55552, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 87),
/* {'track': 1, 'velocity': 0, 't': 55584, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 86, 't': 55616, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 86),
/* {'track': 1, 'velocity': 0, 't': 55648, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 105, 't': 55680, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 105),
/* {'track': 1, 'velocity': 70, 't': 55680, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 70),
/* {'track': 1, 'velocity': 69, 't': 55680, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 69),
/* {'track': 1, 'velocity': 0, 't': 55712, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 103, 't': 55744, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 103),
/* {'track': 1, 'velocity': 0, 't': 55776, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 55796, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 55796, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 112, 't': 55808, 'channel': 1, 'pitch': 82} */
PAUSE(12),
NOTE(0, 82, 112),
/* {'track': 1, 'velocity': 88, 't': 55808, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 88),
/* {'track': 1, 'velocity': 86, 't': 55808, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 86),
/* {'track': 1, 'velocity': 85, 't': 55808, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 85),
/* {'track': 1, 'velocity': 0, 't': 55840, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 88, 't': 55872, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 88),
/* {'track': 1, 'velocity': 0, 't': 55904, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 55924, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 55924, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 55924, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 104, 't': 55936, 'channel': 1, 'pitch': 82} */
PAUSE(12),
NOTE(0, 82, 104),
/* {'track': 1, 'velocity': 76, 't': 55936, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 76),
/* {'track': 1, 'velocity': 76, 't': 55936, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 76),
/* {'track': 1, 'velocity': 75, 't': 55936, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 75),
/* {'track': 1, 'velocity': 0, 't': 55968, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 86, 't': 56000, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 86),
/* {'track': 1, 'velocity': 0, 't': 56032, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 56052, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 56052, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 56052, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 84, 't': 56064, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 84),
/* {'track': 1, 'velocity': 0, 't': 56096, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 84, 't': 56128, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 84),
/* {'track': 1, 'velocity': 0, 't': 56160, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 105, 't': 56192, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 105),
/* {'track': 1, 'velocity': 70, 't': 56192, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 70),
/* {'track': 1, 'velocity': 69, 't': 56192, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 69),
/* {'track': 1, 'velocity': 67, 't': 56192, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 67),
/* {'track': 1, 'velocity': 0, 't': 56224, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 106, 't': 56256, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 106),
/* {'track': 1, 'velocity': 0, 't': 56288, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 56308, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 56308, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 56308, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 107, 't': 56320, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 107),
/* {'track': 1, 'velocity': 75, 't': 56320, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 75),
/* {'track': 1, 'velocity': 73, 't': 56320, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 73),
/* {'track': 1, 'velocity': 72, 't': 56320, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 72),
/* {'track': 1, 'velocity': 0, 't': 56352, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 91, 't': 56384, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 91),
/* {'track': 1, 'velocity': 0, 't': 56416, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 56436, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 56436, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 56436, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 104, 't': 56448, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 104),
/* {'track': 1, 'velocity': 76, 't': 56448, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 76),
/* {'track': 1, 'velocity': 77, 't': 56448, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 77),
/* {'track': 1, 'velocity': 75, 't': 56448, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 75),
/* {'track': 1, 'velocity': 0, 't': 56480, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 90, 't': 56512, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 90),
/* {'track': 1, 'velocity': 0, 't': 56544, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 56564, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 56564, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 56564, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 87, 't': 56576, 'channel': 1, 'pitch': 75} */
PAUSE(12),
NOTE(0, 75, 87),
/* {'track': 1, 'velocity': 0, 't': 56608, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 83, 't': 56640, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 83),
/* {'track': 1, 'velocity': 0, 't': 56672, 'channel': 1, 'pitch': 71} */
PAUSE(32),
NOTE(0, 71, 0),
/* {'track': 1, 'velocity': 104, 't': 56704, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 104),
/* {'track': 1, 'velocity': 68, 't': 56704, 'channel': 2, 'pitch': 63} */
NOTE(8, 63, 68),
/* {'track': 1, 'velocity': 67, 't': 56704, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 67),
/* {'track': 1, 'velocity': 67, 't': 56704, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 67),
/* {'track': 1, 'velocity': 0, 't': 56736, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 104, 't': 56768, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 104),
/* {'track': 1, 'velocity': 0, 't': 56800, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 56820, 'channel': 2, 'pitch': 63} */
PAUSE(20),
NOTE(8, 63, 0),
/* {'track': 1, 'velocity': 0, 't': 56820, 'channel': 2, 'pitch': 66} */
NOTE(9, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 56820, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 121, 't': 56832, 'channel': 1, 'pitch': 87} */
PAUSE(12),
NOTE(0, 87, 121),
/* {'track': 1, 'velocity': 91, 't': 56832, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 91),
/* {'track': 1, 'velocity': 90, 't': 56832, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 90),
/* {'track': 1, 'velocity': 88, 't': 56832, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 88),
/* {'track': 1, 'velocity': 0, 't': 56864, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 83, 't': 56896, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 83),
/* {'track': 1, 'velocity': 0, 't': 56928, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 56948, 'channel': 2, 'pitch': 66} */
PAUSE(20),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 56948, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 56948, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 0),
/* {'track': 1, 'velocity': 110, 't': 56960, 'channel': 1, 'pitch': 87} */
PAUSE(12),
NOTE(0, 87, 110),
/* {'track': 1, 'velocity': 79, 't': 56960, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 79),
/* {'track': 1, 'velocity': 75, 't': 56960, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 75),
/* {'track': 1, 'velocity': 79, 't': 56960, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 79),
/* {'track': 1, 'velocity': 0, 't': 56992, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 85, 't': 57024, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 85),
/* {'track': 1, 'velocity': 0, 't': 57056, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 57076, 'channel': 2, 'pitch': 66} */
PAUSE(20),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 57076, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 57076, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 0),
/* {'track': 1, 'velocity': 85, 't': 57088, 'channel': 1, 'pitch': 78} */
PAUSE(12),
NOTE(0, 78, 85),
/* {'track': 1, 'velocity': 0, 't': 57120, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 84, 't': 57152, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 84),
/* {'track': 1, 'velocity': 0, 't': 57184, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 104, 't': 57216, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 104),
/* {'track': 1, 'velocity': 67, 't': 57216, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 67),
/* {'track': 1, 'velocity': 67, 't': 57216, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 67),
/* {'track': 1, 'velocity': 68, 't': 57216, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 68),
/* {'track': 1, 'velocity': 0, 't': 57248, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 106, 't': 57280, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 106),
/* {'track': 1, 'velocity': 0, 't': 57312, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 57332, 'channel': 2, 'pitch': 66} */
PAUSE(20),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 57332, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 57332, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 0),
/* {'track': 1, 'velocity': 112, 't': 57344, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 112),
/* {'track': 1, 'velocity': 74, 't': 57344, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 74),
/* {'track': 1, 'velocity': 74, 't': 57344, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 74),
/* {'track': 1, 'velocity': 74, 't': 57344, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 74),
/* {'track': 1, 'velocity': 0, 't': 57376, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 93, 't': 57408, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 93),
/* {'track': 1, 'velocity': 0, 't': 57440, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 57460, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 57460, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 57460, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 99, 't': 57472, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 99),
/* {'track': 1, 'velocity': 74, 't': 57472, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 74),
/* {'track': 1, 'velocity': 73, 't': 57472, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 73),
/* {'track': 1, 'velocity': 77, 't': 57472, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 77),
/* {'track': 1, 'velocity': 0, 't': 57504, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 85, 't': 57536, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 85),
/* {'track': 1, 'velocity': 0, 't': 57568, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 57588, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 57588, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 57588, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 82, 't': 57600, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 82),
/* {'track': 1, 'velocity': 0, 't': 57632, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 84, 't': 57664, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 84),
/* {'track': 1, 'velocity': 0, 't': 57696, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 102, 't': 57728, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 102),
/* {'track': 1, 'velocity': 69, 't': 57728, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 69),
/* {'track': 1, 'velocity': 66, 't': 57728, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 66),
/* {'track': 1, 'velocity': 66, 't': 57728, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 66),
/* {'track': 1, 'velocity': 0, 't': 57760, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 107, 't': 57792, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 107),
/* {'track': 1, 'velocity': 0, 't': 57824, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 57844, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 57844, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 57844, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 113, 't': 57856, 'channel': 1, 'pitch': 87} */
PAUSE(12),
NOTE(0, 87, 113),
/* {'track': 1, 'velocity': 81, 't': 57856, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 81),
/* {'track': 1, 'velocity': 83, 't': 57856, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 83),
/* {'track': 1, 'velocity': 82, 't': 57856, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 82),
/* {'track': 1, 'velocity': 0, 't': 57888, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 84, 't': 57920, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 84),
/* {'track': 1, 'velocity': 0, 't': 57952, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 57972, 'channel': 2, 'pitch': 66} */
PAUSE(20),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 57972, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 57972, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 0),
/* {'track': 1, 'velocity': 108, 't': 57984, 'channel': 1, 'pitch': 87} */
PAUSE(12),
NOTE(0, 87, 108),
/* {'track': 1, 'velocity': 76, 't': 57984, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 76),
/* {'track': 1, 'velocity': 77, 't': 57984, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 77),
/* {'track': 1, 'velocity': 74, 't': 57984, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 74),
/* {'track': 1, 'velocity': 0, 't': 58016, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 82, 't': 58048, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 82),
/* {'track': 1, 'velocity': 0, 't': 58080, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 58100, 'channel': 2, 'pitch': 66} */
PAUSE(20),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 58100, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 58100, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 0),
/* {'track': 1, 'velocity': 85, 't': 58112, 'channel': 1, 'pitch': 78} */
PAUSE(12),
NOTE(0, 78, 85),
/* {'track': 1, 'velocity': 0, 't': 58144, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 87, 't': 58176, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 87),
/* {'track': 1, 'velocity': 0, 't': 58208, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 100, 't': 58240, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 100),
/* {'track': 1, 'velocity': 67, 't': 58240, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 67),
/* {'track': 1, 'velocity': 68, 't': 58240, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 68),
/* {'track': 1, 'velocity': 0, 't': 58272, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 104, 't': 58304, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 104),
/* {'track': 1, 'velocity': 0, 't': 58336, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 58356, 'channel': 2, 'pitch': 66} */
PAUSE(20),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 58356, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 112, 't': 58368, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 112),
/* {'track': 1, 'velocity': 88, 't': 58368, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 88),
/* {'track': 1, 'velocity': 88, 't': 58368, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 88),
/* {'track': 1, 'velocity': 89, 't': 58368, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 89),
/* {'track': 1, 'velocity': 0, 't': 58400, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 93, 't': 58432, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 93),
/* {'track': 1, 'velocity': 0, 't': 58464, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 58484, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 58484, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 58484, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 101, 't': 58496, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 101),
/* {'track': 1, 'velocity': 76, 't': 58496, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 76),
/* {'track': 1, 'velocity': 77, 't': 58496, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 77),
/* {'track': 1, 'velocity': 76, 't': 58496, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 76),
/* {'track': 1, 'velocity': 0, 't': 58528, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 84, 't': 58560, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 84),
/* {'track': 1, 'velocity': 0, 't': 58592, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 58612, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 58612, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 58612, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 81, 't': 58624, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 81),
/* {'track': 1, 'velocity': 0, 't': 58656, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 85, 't': 58688, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 85),
/* {'track': 1, 'velocity': 0, 't': 58720, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 102, 't': 58752, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 102),
/* {'track': 1, 'velocity': 66, 't': 58752, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 66),
/* {'track': 1, 'velocity': 69, 't': 58752, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 69),
/* {'track': 1, 'velocity': 67, 't': 58752, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 67),
/* {'track': 1, 'velocity': 0, 't': 58784, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 110, 't': 58816, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 110),
/* {'track': 1, 'velocity': 0, 't': 58848, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 58868, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 58868, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 58868, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 112, 't': 58880, 'channel': 1, 'pitch': 87} */
PAUSE(12),
NOTE(0, 87, 112),
/* {'track': 1, 'velocity': 79, 't': 58880, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 79),
/* {'track': 1, 'velocity': 80, 't': 58880, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 80),
/* {'track': 1, 'velocity': 80, 't': 58880, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 80),
/* {'track': 1, 'velocity': 0, 't': 58912, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 84, 't': 58944, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 84),
/* {'track': 1, 'velocity': 0, 't': 58976, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 58996, 'channel': 2, 'pitch': 66} */
PAUSE(20),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 58996, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 58996, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 0),
/* {'track': 1, 'velocity': 107, 't': 59008, 'channel': 1, 'pitch': 87} */
PAUSE(12),
NOTE(0, 87, 107),
/* {'track': 1, 'velocity': 76, 't': 59008, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 76),
/* {'track': 1, 'velocity': 75, 't': 59008, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 75),
/* {'track': 1, 'velocity': 78, 't': 59008, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 78),
/* {'track': 1, 'velocity': 0, 't': 59040, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 84, 't': 59072, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 84),
/* {'track': 1, 'velocity': 0, 't': 59104, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 59124, 'channel': 2, 'pitch': 66} */
PAUSE(20),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 59124, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 59124, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 0),
/* {'track': 1, 'velocity': 83, 't': 59136, 'channel': 1, 'pitch': 78} */
PAUSE(12),
NOTE(0, 78, 83),
/* {'track': 1, 'velocity': 0, 't': 59168, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 88, 't': 59200, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 88),
/* {'track': 1, 'velocity': 0, 't': 59232, 'channel': 1, 'pitch': 75} */
PAUSE(32),
NOTE(0, 75, 0),
/* {'track': 1, 'velocity': 101, 't': 59264, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 101),
/* {'track': 1, 'velocity': 67, 't': 59264, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 67),
/* {'track': 1, 'velocity': 68, 't': 59264, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 68),
/* {'track': 1, 'velocity': 68, 't': 59264, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 68),
/* {'track': 1, 'velocity': 0, 't': 59296, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 104, 't': 59328, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 104),
/* {'track': 1, 'velocity': 0, 't': 59360, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 59380, 'channel': 2, 'pitch': 66} */
PAUSE(20),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 59380, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 59380, 'channel': 2, 'pitch': 75} */
NOTE(10, 75, 0),
/* {'track': 1, 'velocity': 112, 't': 59392, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 112),
/* {'track': 1, 'velocity': 73, 't': 59392, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 73),
/* {'track': 1, 'velocity': 73, 't': 59392, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 73),
/* {'track': 1, 'velocity': 75, 't': 59392, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 75),
/* {'track': 1, 'velocity': 0, 't': 59424, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 93, 't': 59456, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 93),
/* {'track': 1, 'velocity': 0, 't': 59488, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 59508, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 59508, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 59508, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 101, 't': 59520, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 101),
/* {'track': 1, 'velocity': 74, 't': 59520, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 74),
/* {'track': 1, 'velocity': 77, 't': 59520, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 77),
/* {'track': 1, 'velocity': 74, 't': 59520, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 74),
/* {'track': 1, 'velocity': 0, 't': 59552, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 86, 't': 59584, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 86),
/* {'track': 1, 'velocity': 0, 't': 59616, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 59636, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 59636, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 59636, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 83, 't': 59648, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 83),
/* {'track': 1, 'velocity': 0, 't': 59680, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 86, 't': 59712, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 59744, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 103, 't': 59776, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 103),
/* {'track': 1, 'velocity': 68, 't': 59776, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 68),
/* {'track': 1, 'velocity': 69, 't': 59776, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 69),
/* {'track': 1, 'velocity': 67, 't': 59776, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 67),
/* {'track': 1, 'velocity': 0, 't': 59808, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 108, 't': 59840, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 108),
/* {'track': 1, 'velocity': 0, 't': 59872, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 59892, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 59892, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 59892, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 111, 't': 59904, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 111),
/* {'track': 1, 'velocity': 85, 't': 59904, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 85),
/* {'track': 1, 'velocity': 86, 't': 59904, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 86),
/* {'track': 1, 'velocity': 86, 't': 59904, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 59936, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 92, 't': 59968, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 92),
/* {'track': 1, 'velocity': 0, 't': 60000, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 60020, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 60020, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 60020, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 100, 't': 60032, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 100),
/* {'track': 1, 'velocity': 76, 't': 60032, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 76),
/* {'track': 1, 'velocity': 77, 't': 60032, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 77),
/* {'track': 1, 'velocity': 76, 't': 60032, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 76),
/* {'track': 1, 'velocity': 0, 't': 60064, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 86, 't': 60096, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 86),
/* {'track': 1, 'velocity': 0, 't': 60128, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 60148, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 60148, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 60148, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 81, 't': 60160, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 81),
/* {'track': 1, 'velocity': 0, 't': 60192, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 87, 't': 60224, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 87),
/* {'track': 1, 'velocity': 0, 't': 60256, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 103, 't': 60288, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 103),
/* {'track': 1, 'velocity': 67, 't': 60288, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 67),
/* {'track': 1, 'velocity': 66, 't': 60288, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 66),
/* {'track': 1, 'velocity': 70, 't': 60288, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 70),
/* {'track': 1, 'velocity': 0, 't': 60320, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 110, 't': 60352, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 110),
/* {'track': 1, 'velocity': 0, 't': 60384, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 60404, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 60404, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 60404, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 110, 't': 60416, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 110),
/* {'track': 1, 'velocity': 88, 't': 60416, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 88),
/* {'track': 1, 'velocity': 85, 't': 60416, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 85),
/* {'track': 1, 'velocity': 85, 't': 60416, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 85),
/* {'track': 1, 'velocity': 0, 't': 60448, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 94, 't': 60480, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 94),
/* {'track': 1, 'velocity': 0, 't': 60512, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 60532, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 60532, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 60532, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 100, 't': 60544, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 100),
/* {'track': 1, 'velocity': 76, 't': 60544, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 76),
/* {'track': 1, 'velocity': 77, 't': 60544, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 77),
/* {'track': 1, 'velocity': 75, 't': 60544, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 75),
/* {'track': 1, 'velocity': 0, 't': 60576, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 87, 't': 60608, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 87),
/* {'track': 1, 'velocity': 0, 't': 60640, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 60660, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 60660, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 60660, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 83, 't': 60672, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 83),
/* {'track': 1, 'velocity': 0, 't': 60704, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 86, 't': 60736, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 60768, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 102, 't': 60800, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 102),
/* {'track': 1, 'velocity': 67, 't': 60800, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 67),
/* {'track': 1, 'velocity': 69, 't': 60800, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 69),
/* {'track': 1, 'velocity': 70, 't': 60800, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 70),
/* {'track': 1, 'velocity': 0, 't': 60832, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 108, 't': 60864, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 108),
/* {'track': 1, 'velocity': 0, 't': 60896, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 60916, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 60916, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 60916, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 110, 't': 60928, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 110),
/* {'track': 1, 'velocity': 86, 't': 60928, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 86),
/* {'track': 1, 'velocity': 86, 't': 60928, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 86),
/* {'track': 1, 'velocity': 86, 't': 60928, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 60960, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 93, 't': 60992, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 93),
/* {'track': 1, 'velocity': 0, 't': 61024, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 61044, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 61044, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 61044, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 99, 't': 61056, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 99),
/* {'track': 1, 'velocity': 79, 't': 61056, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 79),
/* {'track': 1, 'velocity': 77, 't': 61056, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 77),
/* {'track': 1, 'velocity': 75, 't': 61056, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 75),
/* {'track': 1, 'velocity': 0, 't': 61088, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 85, 't': 61120, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 85),
/* {'track': 1, 'velocity': 0, 't': 61152, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 61172, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 61172, 'channel': 2, 'pitch': 70} */
NOTE(9, 70, 0),
/* {'track': 1, 'velocity': 0, 't': 61172, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 80, 't': 61184, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 80),
/* {'track': 1, 'velocity': 0, 't': 61216, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 85, 't': 61248, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 85),
/* {'track': 1, 'velocity': 0, 't': 61280, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 103, 't': 61312, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 103),
/* {'track': 1, 'velocity': 67, 't': 61312, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 67),
/* {'track': 1, 'velocity': 66, 't': 61312, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 66),
/* {'track': 1, 'velocity': 68, 't': 61312, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 68),
/* {'track': 1, 'velocity': 0, 't': 61344, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 107, 't': 61376, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 107),
/* {'track': 1, 'velocity': 0, 't': 61408, 'channel': 1, 'pitch': 82} */
PAUSE(32),
NOTE(0, 82, 0),
/* {'track': 1, 'velocity': 0, 't': 61428, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 61428, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 61428, 'channel': 2, 'pitch': 70} */
NOTE(10, 70, 0),
/* {'track': 1, 'velocity': 113, 't': 61440, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 113),
/* {'track': 1, 'velocity': 84, 't': 61440, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 84),
/* {'track': 1, 'velocity': 85, 't': 61440, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 85),
/* {'track': 1, 'velocity': 86, 't': 61440, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 61472, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 94, 't': 61504, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 94),
/* {'track': 1, 'velocity': 0, 't': 61536, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 61556, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 61556, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 61556, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 99, 't': 61568, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 99),
/* {'track': 1, 'velocity': 76, 't': 61568, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 76),
/* {'track': 1, 'velocity': 76, 't': 61568, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 76),
/* {'track': 1, 'velocity': 79, 't': 61568, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 79),
/* {'track': 1, 'velocity': 0, 't': 61600, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 86, 't': 61632, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 61664, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 61684, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 61684, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 61684, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 82, 't': 61696, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 82),
/* {'track': 1, 'velocity': 0, 't': 61728, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 86, 't': 61760, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 61792, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 103, 't': 61824, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 103),
/* {'track': 1, 'velocity': 69, 't': 61824, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 69),
/* {'track': 1, 'velocity': 67, 't': 61824, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 67),
/* {'track': 1, 'velocity': 68, 't': 61824, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 68),
/* {'track': 1, 'velocity': 0, 't': 61856, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 106, 't': 61888, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 106),
/* {'track': 1, 'velocity': 0, 't': 61920, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 61940, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 61940, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 61940, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 112, 't': 61952, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 112),
/* {'track': 1, 'velocity': 85, 't': 61952, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 85),
/* {'track': 1, 'velocity': 86, 't': 61952, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 86),
/* {'track': 1, 'velocity': 87, 't': 61952, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 87),
/* {'track': 1, 'velocity': 0, 't': 61984, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 92, 't': 62016, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 92),
/* {'track': 1, 'velocity': 0, 't': 62048, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 62068, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 62068, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 62068, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 100, 't': 62080, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 100),
/* {'track': 1, 'velocity': 79, 't': 62080, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 79),
/* {'track': 1, 'velocity': 78, 't': 62080, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 78),
/* {'track': 1, 'velocity': 76, 't': 62080, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 76),
/* {'track': 1, 'velocity': 0, 't': 62112, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 85, 't': 62144, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 85),
/* {'track': 1, 'velocity': 0, 't': 62176, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 62196, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 62196, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 62196, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 82, 't': 62208, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 82),
/* {'track': 1, 'velocity': 0, 't': 62240, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 83, 't': 62272, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 83),
/* {'track': 1, 'velocity': 0, 't': 62304, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 101, 't': 62336, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 101),
/* {'track': 1, 'velocity': 69, 't': 62336, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 69),
/* {'track': 1, 'velocity': 69, 't': 62336, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 69),
/* {'track': 1, 'velocity': 66, 't': 62336, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 66),
/* {'track': 1, 'velocity': 0, 't': 62368, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 108, 't': 62400, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 108),
/* {'track': 1, 'velocity': 0, 't': 62432, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 62452, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 62452, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 62452, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 112, 't': 62464, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 112),
/* {'track': 1, 'velocity': 87, 't': 62464, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 87),
/* {'track': 1, 'velocity': 88, 't': 62464, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 88),
/* {'track': 1, 'velocity': 88, 't': 62464, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 88),
/* {'track': 1, 'velocity': 0, 't': 62496, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 95, 't': 62528, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 95),
/* {'track': 1, 'velocity': 0, 't': 62560, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 62580, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 62580, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 62580, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 100, 't': 62592, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 100),
/* {'track': 1, 'velocity': 76, 't': 62592, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 76),
/* {'track': 1, 'velocity': 75, 't': 62592, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 75),
/* {'track': 1, 'velocity': 76, 't': 62592, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 76),
/* {'track': 1, 'velocity': 0, 't': 62624, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 83, 't': 62656, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 83),
/* {'track': 1, 'velocity': 0, 't': 62688, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 62708, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 62708, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 62708, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 83, 't': 62720, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 83),
/* {'track': 1, 'velocity': 0, 't': 62752, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 83, 't': 62784, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 83),
/* {'track': 1, 'velocity': 0, 't': 62816, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 102, 't': 62848, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 102),
/* {'track': 1, 'velocity': 67, 't': 62848, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 67),
/* {'track': 1, 'velocity': 68, 't': 62848, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 68),
/* {'track': 1, 'velocity': 69, 't': 62848, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 69),
/* {'track': 1, 'velocity': 0, 't': 62880, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 108, 't': 62912, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 108),
/* {'track': 1, 'velocity': 0, 't': 62944, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 62964, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 62964, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 62964, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 113, 't': 62976, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 113),
/* {'track': 1, 'velocity': 86, 't': 62976, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 86),
/* {'track': 1, 'velocity': 87, 't': 62976, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 87),
/* {'track': 1, 'velocity': 86, 't': 62976, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 63008, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 92, 't': 63040, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 92),
/* {'track': 1, 'velocity': 0, 't': 63072, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 63092, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 63092, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 63092, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 99, 't': 63104, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 99),
/* {'track': 1, 'velocity': 76, 't': 63104, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 76),
/* {'track': 1, 'velocity': 75, 't': 63104, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 75),
/* {'track': 1, 'velocity': 76, 't': 63104, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 76),
/* {'track': 1, 'velocity': 0, 't': 63136, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 84, 't': 63168, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 84),
/* {'track': 1, 'velocity': 0, 't': 63200, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 63220, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 63220, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 63220, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 84, 't': 63232, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 84),
/* {'track': 1, 'velocity': 0, 't': 63264, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 85, 't': 63296, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 85),
/* {'track': 1, 'velocity': 0, 't': 63328, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 102, 't': 63360, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 102),
/* {'track': 1, 'velocity': 67, 't': 63360, 'channel': 2, 'pitch': 62} */
NOTE(8, 62, 67),
/* {'track': 1, 'velocity': 67, 't': 63360, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 67),
/* {'track': 1, 'velocity': 67, 't': 63360, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 67),
/* {'track': 1, 'velocity': 0, 't': 63392, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 106, 't': 63424, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 106),
/* {'track': 1, 'velocity': 0, 't': 63456, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 63476, 'channel': 2, 'pitch': 62} */
PAUSE(20),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 0, 't': 63476, 'channel': 2, 'pitch': 65} */
NOTE(9, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 63476, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 114, 't': 63488, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 114),
/* {'track': 1, 'velocity': 86, 't': 63488, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 86),
/* {'track': 1, 'velocity': 88, 't': 63488, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 88),
/* {'track': 1, 'velocity': 86, 't': 63488, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 63520, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 93, 't': 63552, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 93),
/* {'track': 1, 'velocity': 0, 't': 63584, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 63604, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 63604, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 63604, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 99, 't': 63616, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 99),
/* {'track': 1, 'velocity': 77, 't': 63616, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 77),
/* {'track': 1, 'velocity': 78, 't': 63616, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 78),
/* {'track': 1, 'velocity': 76, 't': 63616, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 76),
/* {'track': 1, 'velocity': 0, 't': 63648, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 79, 't': 63680, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 79),
/* {'track': 1, 'velocity': 0, 't': 63712, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 63732, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 63732, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 63732, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 87, 't': 63744, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 87),
/* {'track': 1, 'velocity': 0, 't': 63776, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 84, 't': 63808, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 84),
/* {'track': 1, 'velocity': 0, 't': 63840, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 103, 't': 63872, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 103),
/* {'track': 1, 'velocity': 69, 't': 63872, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 69),
/* {'track': 1, 'velocity': 68, 't': 63872, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 68),
/* {'track': 1, 'velocity': 0, 't': 63904, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 104, 't': 63936, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 104),
/* {'track': 1, 'velocity': 0, 't': 63968, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 63988, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 63988, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 117, 't': 64000, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 117),
/* {'track': 1, 'velocity': 88, 't': 64000, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 88),
/* {'track': 1, 'velocity': 89, 't': 64000, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 89),
/* {'track': 1, 'velocity': 88, 't': 64000, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 88),
/* {'track': 1, 'velocity': 0, 't': 64032, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 93, 't': 64064, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 93),
/* {'track': 1, 'velocity': 0, 't': 64096, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 64116, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 64116, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 64116, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 102, 't': 64128, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 102),
/* {'track': 1, 'velocity': 77, 't': 64128, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 77),
/* {'track': 1, 'velocity': 76, 't': 64128, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 76),
/* {'track': 1, 'velocity': 77, 't': 64128, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 77),
/* {'track': 1, 'velocity': 0, 't': 64160, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 82, 't': 64192, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 82),
/* {'track': 1, 'velocity': 0, 't': 64224, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 64244, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 64244, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 64244, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 86, 't': 64256, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 86),
/* {'track': 1, 'velocity': 0, 't': 64288, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 86, 't': 64320, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 64352, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 100, 't': 64384, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 100),
/* {'track': 1, 'velocity': 69, 't': 64384, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 69),
/* {'track': 1, 'velocity': 67, 't': 64384, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 67),
/* {'track': 1, 'velocity': 0, 't': 64416, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 106, 't': 64448, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 106),
/* {'track': 1, 'velocity': 0, 't': 64480, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 64500, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 64500, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 115, 't': 64512, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 115),
/* {'track': 1, 'velocity': 91, 't': 64512, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 91),
/* {'track': 1, 'velocity': 90, 't': 64512, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 90),
/* {'track': 1, 'velocity': 87, 't': 64512, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 87),
/* {'track': 1, 'velocity': 0, 't': 64544, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 94, 't': 64576, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 94),
/* {'track': 1, 'velocity': 0, 't': 64608, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 64628, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 64628, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 64628, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 100, 't': 64640, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 100),
/* {'track': 1, 'velocity': 76, 't': 64640, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 76),
/* {'track': 1, 'velocity': 76, 't': 64640, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 76),
/* {'track': 1, 'velocity': 79, 't': 64640, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 79),
/* {'track': 1, 'velocity': 0, 't': 64672, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 82, 't': 64704, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 82),
/* {'track': 1, 'velocity': 0, 't': 64736, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 64756, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 64756, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 64756, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 86, 't': 64768, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 86),
/* {'track': 1, 'velocity': 0, 't': 64800, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 86, 't': 64832, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 64864, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 101, 't': 64896, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 101),
/* {'track': 1, 'velocity': 70, 't': 64896, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 70),
/* {'track': 1, 'velocity': 69, 't': 64896, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 69),
/* {'track': 1, 'velocity': 0, 't': 64928, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 105, 't': 64960, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 105),
/* {'track': 1, 'velocity': 0, 't': 64992, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 65012, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 65012, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 114, 't': 65024, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 114),
/* {'track': 1, 'velocity': 90, 't': 65024, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 90),
/* {'track': 1, 'velocity': 91, 't': 65024, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 91),
/* {'track': 1, 'velocity': 89, 't': 65024, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 89),
/* {'track': 1, 'velocity': 0, 't': 65056, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 96, 't': 65088, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 96),
/* {'track': 1, 'velocity': 0, 't': 65120, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 65140, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 65140, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 65140, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 99, 't': 65152, 'channel': 1, 'pitch': 86} */
PAUSE(12),
NOTE(0, 86, 99),
/* {'track': 1, 'velocity': 78, 't': 65152, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 78),
/* {'track': 1, 'velocity': 77, 't': 65152, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 77),
/* {'track': 1, 'velocity': 77, 't': 65152, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 77),
/* {'track': 1, 'velocity': 0, 't': 65184, 'channel': 1, 'pitch': 86} */
PAUSE(32),
NOTE(0, 86, 0),
/* {'track': 1, 'velocity': 80, 't': 65216, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 80),
/* {'track': 1, 'velocity': 0, 't': 65248, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 65268, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 65268, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 65268, 'channel': 2, 'pitch': 74} */
NOTE(10, 74, 0),
/* {'track': 1, 'velocity': 84, 't': 65280, 'channel': 1, 'pitch': 77} */
PAUSE(12),
NOTE(0, 77, 84),
/* {'track': 1, 'velocity': 0, 't': 65312, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 86, 't': 65344, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 0, 't': 65376, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 101, 't': 65408, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 101),
/* {'track': 1, 'velocity': 68, 't': 65408, 'channel': 2, 'pitch': 65} */
NOTE(8, 65, 68),
/* {'track': 1, 'velocity': 68, 't': 65408, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 68),
/* {'track': 1, 'velocity': 0, 't': 65440, 'channel': 1, 'pitch': 77} */
PAUSE(32),
NOTE(0, 77, 0),
/* {'track': 1, 'velocity': 105, 't': 65472, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 105),
/* {'track': 1, 'velocity': 0, 't': 65504, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 65524, 'channel': 2, 'pitch': 65} */
PAUSE(20),
NOTE(8, 65, 0),
/* {'track': 1, 'velocity': 0, 't': 65524, 'channel': 2, 'pitch': 68} */
NOTE(9, 68, 0),
/* {'track': 1, 'velocity': 116, 't': 65536, 'channel': 1, 'pitch': 78} */
PAUSE(12),
NOTE(0, 78, 116),
/* {'track': 1, 'velocity': 114, 't': 65536, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 114),
/* {'track': 1, 'velocity': 115, 't': 65536, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 115),
/* {'track': 1, 'velocity': 91, 't': 65536, 'channel': 2, 'pitch': 74} */
NOTE(8, 74, 91),
/* {'track': 1, 'velocity': 0, 't': 65568, 'channel': 2, 'pitch': 74} */
PAUSE(32),
NOTE(8, 74, 0),
/* {'track': 1, 'velocity': 74, 't': 65600, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 74),
/* {'track': 1, 'velocity': 0, 't': 65632, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 0),
/* {'track': 1, 'velocity': 0, 't': 65652, 'channel': 1, 'pitch': 78} */
PAUSE(20),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 65652, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 65652, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 0),
/* {'track': 1, 'velocity': 98, 't': 65664, 'channel': 1, 'pitch': 78} */
PAUSE(12),
NOTE(0, 78, 98),
/* {'track': 1, 'velocity': 101, 't': 65664, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 101),
/* {'track': 1, 'velocity': 99, 't': 65664, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 99),
/* {'track': 1, 'velocity': 78, 't': 65664, 'channel': 2, 'pitch': 74} */
NOTE(8, 74, 78),
/* {'track': 1, 'velocity': 0, 't': 65696, 'channel': 2, 'pitch': 74} */
PAUSE(32),
NOTE(8, 74, 0),
/* {'track': 1, 'velocity': 66, 't': 65728, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 66),
/* {'track': 1, 'velocity': 0, 't': 65760, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 65780, 'channel': 1, 'pitch': 78} */
PAUSE(20),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 65780, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 65780, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 0),
/* {'track': 1, 'velocity': 71, 't': 65792, 'channel': 2, 'pitch': 66} */
PAUSE(12),
NOTE(8, 66, 71),
/* {'track': 1, 'velocity': 0, 't': 65824, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 65, 't': 65856, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 65),
/* {'track': 1, 'velocity': 0, 't': 65888, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 85, 't': 65920, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 85),
/* {'track': 1, 'velocity': 87, 't': 65920, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 87),
/* {'track': 1, 'velocity': 85, 't': 65920, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 85),
/* {'track': 1, 'velocity': 80, 't': 65920, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 80),
/* {'track': 1, 'velocity': 0, 't': 65952, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 82, 't': 65984, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 82),
/* {'track': 1, 'velocity': 0, 't': 66016, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 66036, 'channel': 1, 'pitch': 78} */
PAUSE(20),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 66036, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 66036, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 0),
/* {'track': 1, 'velocity': 94, 't': 66048, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 94),
/* {'track': 1, 'velocity': 93, 't': 66048, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 93),
/* {'track': 1, 'velocity': 91, 't': 66048, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 91),
/* {'track': 1, 'velocity': 92, 't': 66048, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 92),
/* {'track': 1, 'velocity': 87, 't': 66048, 'channel': 2, 'pitch': 73} */
NOTE(8, 73, 87),
/* {'track': 1, 'velocity': 0, 't': 66080, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 0),
/* {'track': 1, 'velocity': 75, 't': 66112, 'channel': 2, 'pitch': 71} */
PAUSE(32),
NOTE(8, 71, 75),
/* {'track': 1, 'velocity': 0, 't': 66144, 'channel': 2, 'pitch': 71} */
PAUSE(32),
NOTE(8, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 66164, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 66164, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 66164, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 66164, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 0),
/* {'track': 1, 'velocity': 96, 't': 66176, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 96),
/* {'track': 1, 'velocity': 93, 't': 66176, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 93),
/* {'track': 1, 'velocity': 93, 't': 66176, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 93),
/* {'track': 1, 'velocity': 97, 't': 66176, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 97),
/* {'track': 1, 'velocity': 80, 't': 66176, 'channel': 2, 'pitch': 73} */
NOTE(8, 73, 80),
/* {'track': 1, 'velocity': 0, 't': 66208, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 0),
/* {'track': 1, 'velocity': 70, 't': 66240, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 70),
/* {'track': 1, 'velocity': 0, 't': 66272, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 66292, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 66292, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 66292, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 66292, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 0),
/* {'track': 1, 'velocity': 71, 't': 66304, 'channel': 2, 'pitch': 66} */
PAUSE(12),
NOTE(8, 66, 71),
/* {'track': 1, 'velocity': 0, 't': 66336, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 67, 't': 66368, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 67),
/* {'track': 1, 'velocity': 0, 't': 66400, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 84, 't': 66432, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 84),
/* {'track': 1, 'velocity': 86, 't': 66432, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 86),
/* {'track': 1, 'velocity': 87, 't': 66432, 'channel': 1, 'pitch': 85} */
NOTE(2, 85, 87),
/* {'track': 1, 'velocity': 82, 't': 66432, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 82),
/* {'track': 1, 'velocity': 0, 't': 66464, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 84, 't': 66496, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 84),
/* {'track': 1, 'velocity': 0, 't': 66528, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 66548, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 66548, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 66548, 'channel': 1, 'pitch': 85} */
NOTE(2, 85, 0),
/* {'track': 1, 'velocity': 90, 't': 66560, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 90),
/* {'track': 1, 'velocity': 90, 't': 66560, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 90),
/* {'track': 1, 'velocity': 92, 't': 66560, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 92),
/* {'track': 1, 'velocity': 91, 't': 66560, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 91),
/* {'track': 1, 'velocity': 82, 't': 66560, 'channel': 2, 'pitch': 71} */
NOTE(8, 71, 82),
/* {'track': 1, 'velocity': 0, 't': 66592, 'channel': 2, 'pitch': 71} */
PAUSE(32),
NOTE(8, 71, 0),
/* {'track': 1, 'velocity': 69, 't': 66624, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 69),
/* {'track': 1, 'velocity': 0, 't': 66656, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 66676, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 66676, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 66676, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 66676, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 0),
/* {'track': 1, 'velocity': 93, 't': 66688, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 93),
/* {'track': 1, 'velocity': 94, 't': 66688, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 94),
/* {'track': 1, 'velocity': 96, 't': 66688, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 96),
/* {'track': 1, 'velocity': 96, 't': 66688, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 96),
/* {'track': 1, 'velocity': 79, 't': 66688, 'channel': 2, 'pitch': 71} */
NOTE(8, 71, 79),
/* {'track': 1, 'velocity': 0, 't': 66720, 'channel': 2, 'pitch': 71} */
PAUSE(32),
NOTE(8, 71, 0),
/* {'track': 1, 'velocity': 71, 't': 66752, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 71),
/* {'track': 1, 'velocity': 0, 't': 66784, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 66804, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 66804, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 66804, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 66804, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 0),
/* {'track': 1, 'velocity': 71, 't': 66816, 'channel': 2, 'pitch': 66} */
PAUSE(12),
NOTE(8, 66, 71),
/* {'track': 1, 'velocity': 0, 't': 66848, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 65, 't': 66880, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 65),
/* {'track': 1, 'velocity': 0, 't': 66912, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 87, 't': 66944, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 87),
/* {'track': 1, 'velocity': 85, 't': 66944, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 85),
/* {'track': 1, 'velocity': 85, 't': 66944, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 85),
/* {'track': 1, 'velocity': 86, 't': 66944, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 86),
/* {'track': 1, 'velocity': 83, 't': 66944, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 83),
/* {'track': 1, 'velocity': 0, 't': 66976, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 84, 't': 67008, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 84),
/* {'track': 1, 'velocity': 0, 't': 67040, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 67060, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 67060, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 67060, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 67060, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 0),
/* {'track': 1, 'velocity': 103, 't': 67072, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 103),
/* {'track': 1, 'velocity': 103, 't': 67072, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 103),
/* {'track': 1, 'velocity': 103, 't': 67072, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 103),
/* {'track': 1, 'velocity': 104, 't': 67072, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 104),
/* {'track': 1, 'velocity': 90, 't': 67072, 'channel': 2, 'pitch': 73} */
NOTE(8, 73, 90),
/* {'track': 1, 'velocity': 0, 't': 67104, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 0),
/* {'track': 1, 'velocity': 68, 't': 67136, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 68),
/* {'track': 1, 'velocity': 0, 't': 67168, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 67188, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 67188, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 67188, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 67188, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 0),
/* {'track': 1, 'velocity': 95, 't': 67200, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 95),
/* {'track': 1, 'velocity': 97, 't': 67200, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 97),
/* {'track': 1, 'velocity': 96, 't': 67200, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 96),
/* {'track': 1, 'velocity': 95, 't': 67200, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 95),
/* {'track': 1, 'velocity': 82, 't': 67200, 'channel': 2, 'pitch': 73} */
NOTE(8, 73, 82),
/* {'track': 1, 'velocity': 0, 't': 67232, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 0),
/* {'track': 1, 'velocity': 66, 't': 67264, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 66),
/* {'track': 1, 'velocity': 0, 't': 67296, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 67316, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 67316, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 67316, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 67316, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 0),
/* {'track': 1, 'velocity': 69, 't': 67328, 'channel': 2, 'pitch': 66} */
PAUSE(12),
NOTE(8, 66, 69),
/* {'track': 1, 'velocity': 0, 't': 67360, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 64, 't': 67392, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 64),
/* {'track': 1, 'velocity': 0, 't': 67424, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 86, 't': 67456, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 86),
/* {'track': 1, 'velocity': 86, 't': 67456, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 86),
/* {'track': 1, 'velocity': 86, 't': 67456, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 86),
/* {'track': 1, 'velocity': 86, 't': 67456, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 86),
/* {'track': 1, 'velocity': 80, 't': 67456, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 80),
/* {'track': 1, 'velocity': 0, 't': 67488, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 84, 't': 67520, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 84),
/* {'track': 1, 'velocity': 0, 't': 67552, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 67572, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 67572, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 67572, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 67572, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 0),
/* {'track': 1, 'velocity': 100, 't': 67584, 'channel': 1, 'pitch': 78} */
PAUSE(12),
NOTE(0, 78, 100),
/* {'track': 1, 'velocity': 102, 't': 67584, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 102),
/* {'track': 1, 'velocity': 101, 't': 67584, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 101),
/* {'track': 1, 'velocity': 91, 't': 67584, 'channel': 2, 'pitch': 74} */
NOTE(8, 74, 91),
/* {'track': 1, 'velocity': 0, 't': 67616, 'channel': 2, 'pitch': 74} */
PAUSE(32),
NOTE(8, 74, 0),
/* {'track': 1, 'velocity': 75, 't': 67648, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 75),
/* {'track': 1, 'velocity': 0, 't': 67680, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 0),
/* {'track': 1, 'velocity': 0, 't': 67700, 'channel': 1, 'pitch': 78} */
PAUSE(20),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 67700, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 67700, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 0),
/* {'track': 1, 'velocity': 95, 't': 67712, 'channel': 1, 'pitch': 78} */
PAUSE(12),
NOTE(0, 78, 95),
/* {'track': 1, 'velocity': 95, 't': 67712, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 95),
/* {'track': 1, 'velocity': 97, 't': 67712, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 97),
/* {'track': 1, 'velocity': 78, 't': 67712, 'channel': 2, 'pitch': 74} */
NOTE(8, 74, 78),
/* {'track': 1, 'velocity': 0, 't': 67744, 'channel': 2, 'pitch': 74} */
PAUSE(32),
NOTE(8, 74, 0),
/* {'track': 1, 'velocity': 65, 't': 67776, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 65),
/* {'track': 1, 'velocity': 0, 't': 67808, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 67828, 'channel': 1, 'pitch': 78} */
PAUSE(20),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 67828, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 67828, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 0),
/* {'track': 1, 'velocity': 71, 't': 67840, 'channel': 2, 'pitch': 66} */
PAUSE(12),
NOTE(8, 66, 71),
/* {'track': 1, 'velocity': 0, 't': 67872, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 65, 't': 67904, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 65),
/* {'track': 1, 'velocity': 0, 't': 67936, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 86, 't': 67968, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 86),
/* {'track': 1, 'velocity': 84, 't': 67968, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 84),
/* {'track': 1, 'velocity': 87, 't': 67968, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 87),
/* {'track': 1, 'velocity': 82, 't': 67968, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 82),
/* {'track': 1, 'velocity': 0, 't': 68000, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 82, 't': 68032, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 82),
/* {'track': 1, 'velocity': 0, 't': 68064, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 68084, 'channel': 1, 'pitch': 78} */
PAUSE(20),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 68084, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 68084, 'channel': 1, 'pitch': 86} */
NOTE(2, 86, 0),
/* {'track': 1, 'velocity': 93, 't': 68096, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 93),
/* {'track': 1, 'velocity': 93, 't': 68096, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 93),
/* {'track': 1, 'velocity': 92, 't': 68096, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 92),
/* {'track': 1, 'velocity': 94, 't': 68096, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 94),
/* {'track': 1, 'velocity': 90, 't': 68096, 'channel': 2, 'pitch': 73} */
NOTE(8, 73, 90),
/* {'track': 1, 'velocity': 0, 't': 68128, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 0),
/* {'track': 1, 'velocity': 71, 't': 68160, 'channel': 2, 'pitch': 71} */
PAUSE(32),
NOTE(8, 71, 71),
/* {'track': 1, 'velocity': 0, 't': 68192, 'channel': 2, 'pitch': 71} */
PAUSE(32),
NOTE(8, 71, 0),
/* {'track': 1, 'velocity': 0, 't': 68212, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 68212, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 68212, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 68212, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 0),
/* {'track': 1, 'velocity': 96, 't': 68224, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 96),
/* {'track': 1, 'velocity': 94, 't': 68224, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 94),
/* {'track': 1, 'velocity': 94, 't': 68224, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 94),
/* {'track': 1, 'velocity': 94, 't': 68224, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 94),
/* {'track': 1, 'velocity': 81, 't': 68224, 'channel': 2, 'pitch': 73} */
NOTE(8, 73, 81),
/* {'track': 1, 'velocity': 0, 't': 68256, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 0),
/* {'track': 1, 'velocity': 69, 't': 68288, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 69),
/* {'track': 1, 'velocity': 0, 't': 68320, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 68340, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 68340, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 68340, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 68340, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 0),
/* {'track': 1, 'velocity': 70, 't': 68352, 'channel': 2, 'pitch': 66} */
PAUSE(12),
NOTE(8, 66, 70),
/* {'track': 1, 'velocity': 0, 't': 68384, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 67, 't': 68416, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 67),
/* {'track': 1, 'velocity': 0, 't': 68448, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 87, 't': 68480, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 87),
/* {'track': 1, 'velocity': 87, 't': 68480, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 87),
/* {'track': 1, 'velocity': 85, 't': 68480, 'channel': 1, 'pitch': 85} */
NOTE(2, 85, 85),
/* {'track': 1, 'velocity': 82, 't': 68480, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 82),
/* {'track': 1, 'velocity': 0, 't': 68512, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 81, 't': 68544, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 81),
/* {'track': 1, 'velocity': 0, 't': 68576, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 68596, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 68596, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 68596, 'channel': 1, 'pitch': 85} */
NOTE(2, 85, 0),
/* {'track': 1, 'velocity': 92, 't': 68608, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 92),
/* {'track': 1, 'velocity': 90, 't': 68608, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 90),
/* {'track': 1, 'velocity': 91, 't': 68608, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 91),
/* {'track': 1, 'velocity': 91, 't': 68608, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 91),
/* {'track': 1, 'velocity': 85, 't': 68608, 'channel': 2, 'pitch': 71} */
NOTE(8, 71, 85),
/* {'track': 1, 'velocity': 0, 't': 68640, 'channel': 2, 'pitch': 71} */
PAUSE(32),
NOTE(8, 71, 0),
/* {'track': 1, 'velocity': 71, 't': 68672, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 71),
/* {'track': 1, 'velocity': 0, 't': 68704, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 68724, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 68724, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 68724, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 68724, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 0),
/* {'track': 1, 'velocity': 97, 't': 68736, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 97),
/* {'track': 1, 'velocity': 97, 't': 68736, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 97),
/* {'track': 1, 'velocity': 95, 't': 68736, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 95),
/* {'track': 1, 'velocity': 97, 't': 68736, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 97),
/* {'track': 1, 'velocity': 80, 't': 68736, 'channel': 2, 'pitch': 71} */
NOTE(8, 71, 80),
/* {'track': 1, 'velocity': 0, 't': 68768, 'channel': 2, 'pitch': 71} */
PAUSE(32),
NOTE(8, 71, 0),
/* {'track': 1, 'velocity': 71, 't': 68800, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 71),
/* {'track': 1, 'velocity': 0, 't': 68832, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 68852, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 68852, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 68852, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 68852, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 0),
/* {'track': 1, 'velocity': 69, 't': 68864, 'channel': 2, 'pitch': 66} */
PAUSE(12),
NOTE(8, 66, 69),
/* {'track': 1, 'velocity': 0, 't': 68896, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 68, 't': 68928, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 68),
/* {'track': 1, 'velocity': 0, 't': 68960, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 85, 't': 68992, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 85),
/* {'track': 1, 'velocity': 85, 't': 68992, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 85),
/* {'track': 1, 'velocity': 85, 't': 68992, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 85),
/* {'track': 1, 'velocity': 87, 't': 68992, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 87),
/* {'track': 1, 'velocity': 80, 't': 68992, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 80),
/* {'track': 1, 'velocity': 0, 't': 69024, 'channel': 2, 'pitch': 66} */
PAUSE(32),
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 82, 't': 69056, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 82),
/* {'track': 1, 'velocity': 0, 't': 69088, 'channel': 2, 'pitch': 69} */
PAUSE(32),
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 69108, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 69108, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 69108, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 69108, 'channel': 1, 'pitch': 83} */
NOTE(3, 83, 0),
/* {'track': 1, 'velocity': 104, 't': 69120, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 104),
/* {'track': 1, 'velocity': 101, 't': 69120, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 101),
/* {'track': 1, 'velocity': 102, 't': 69120, 'channel': 1, 'pitch': 80} */
NOTE(2, 80, 102),
/* {'track': 1, 'velocity': 103, 't': 69120, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 103),
/* {'track': 1, 'velocity': 86, 't': 69120, 'channel': 2, 'pitch': 73} */
NOTE(8, 73, 86),
/* {'track': 1, 'velocity': 0, 't': 69152, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 0),
/* {'track': 1, 'velocity': 66, 't': 69184, 'channel': 2, 'pitch': 68} */
PAUSE(32),
NOTE(8, 68, 66),
/* {'track': 1, 'velocity': 0, 't': 69216, 'channel': 2, 'pitch': 68} */
PAUSE(32),
NOTE(8, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 69236, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 69236, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 69236, 'channel': 1, 'pitch': 80} */
NOTE(2, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 69236, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 0),
/* {'track': 1, 'velocity': 95, 't': 69248, 'channel': 1, 'pitch': 74} */
PAUSE(12),
NOTE(0, 74, 95),
/* {'track': 1, 'velocity': 98, 't': 69248, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 98),
/* {'track': 1, 'velocity': 98, 't': 69248, 'channel': 1, 'pitch': 80} */
NOTE(2, 80, 98),
/* {'track': 1, 'velocity': 97, 't': 69248, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 97),
/* {'track': 1, 'velocity': 84, 't': 69248, 'channel': 2, 'pitch': 73} */
NOTE(8, 73, 84),
/* {'track': 1, 'velocity': 0, 't': 69280, 'channel': 2, 'pitch': 73} */
PAUSE(32),
NOTE(8, 73, 0),
/* {'track': 1, 'velocity': 68, 't': 69312, 'channel': 2, 'pitch': 68} */
PAUSE(32),
NOTE(8, 68, 68),
/* {'track': 1, 'velocity': 0, 't': 69344, 'channel': 2, 'pitch': 68} */
PAUSE(32),
NOTE(8, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 69364, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 69364, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 69364, 'channel': 1, 'pitch': 80} */
NOTE(2, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 69364, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 0),
/* {'track': 1, 'velocity': 70, 't': 69376, 'channel': 2, 'pitch': 64} */
PAUSE(12),
NOTE(8, 64, 70),
/* {'track': 1, 'velocity': 0, 't': 69408, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 68, 't': 69440, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 68),
/* {'track': 1, 'velocity': 0, 't': 69472, 'channel': 2, 'pitch': 62} */
PAUSE(32),
NOTE(8, 62, 0),
/* {'track': 1, 'velocity': 85, 't': 69504, 'channel': 1, 'pitch': 74} */
PAUSE(32),
NOTE(0, 74, 85),
/* {'track': 1, 'velocity': 86, 't': 69504, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 86),
/* {'track': 1, 'velocity': 86, 't': 69504, 'channel': 1, 'pitch': 80} */
NOTE(2, 80, 86),
/* {'track': 1, 'velocity': 84, 't': 69504, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 84),
/* {'track': 1, 'velocity': 80, 't': 69504, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 80),
/* {'track': 1, 'velocity': 0, 't': 69536, 'channel': 2, 'pitch': 64} */
PAUSE(32),
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 84, 't': 69568, 'channel': 2, 'pitch': 68} */
PAUSE(32),
NOTE(8, 68, 84),
/* {'track': 1, 'velocity': 0, 't': 69600, 'channel': 2, 'pitch': 68} */
PAUSE(32),
NOTE(8, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 69620, 'channel': 1, 'pitch': 74} */
PAUSE(20),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 69620, 'channel': 1, 'pitch': 76} */
NOTE(1, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 69620, 'channel': 1, 'pitch': 80} */
NOTE(2, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 69620, 'channel': 1, 'pitch': 85} */
NOTE(3, 85, 0),
/* {'track': 1, 'velocity': 88, 't': 69632, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 88),
/* {'track': 1, 'velocity': 84, 't': 69632, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 84),
/* {'track': 1, 'velocity': 84, 't': 69632, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 84),
/* {'track': 1, 'velocity': 82, 't': 69632, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 82),
/* {'track': 1, 'velocity': 0, 't': 69664, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 87, 't': 69696, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 87),
/* {'track': 1, 'velocity': 0, 't': 69728, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 69748, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 69748, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 69748, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 100, 't': 69760, 'channel': 1, 'pitch': 81} */
PAUSE(12),
NOTE(0, 81, 100),
/* {'track': 1, 'velocity': 77, 't': 69760, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 77),
/* {'track': 1, 'velocity': 76, 't': 69760, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 76),
/* {'track': 1, 'velocity': 78, 't': 69760, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 78),
/* {'track': 1, 'velocity': 0, 't': 69792, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 82, 't': 69824, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 82),
/* {'track': 1, 'velocity': 0, 't': 69856, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 69876, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 69876, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 69876, 'channel': 2, 'pitch': 69} */
NOTE(10, 69, 0),
/* {'track': 1, 'velocity': 86, 't': 69888, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 86),
/* {'track': 1, 'velocity': 0, 't': 69920, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 85, 't': 69952, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 85),
/* {'track': 1, 'velocity': 0, 't': 69984, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 104, 't': 70016, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 104),
/* {'track': 1, 'velocity': 70, 't': 70016, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 70),
/* {'track': 1, 'velocity': 69, 't': 70016, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 69),
/* {'track': 1, 'velocity': 0, 't': 70048, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 107, 't': 70080, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 107),
/* {'track': 1, 'velocity': 0, 't': 70112, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 70132, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 70132, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 111, 't': 70144, 'channel': 1, 'pitch': 80} */
PAUSE(12),
NOTE(0, 80, 111),
/* {'track': 1, 'velocity': 84, 't': 70144, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 84),
/* {'track': 1, 'velocity': 88, 't': 70144, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 88),
/* {'track': 1, 'velocity': 88, 't': 70144, 'channel': 2, 'pitch': 68} */
NOTE(10, 68, 88),
/* {'track': 1, 'velocity': 0, 't': 70176, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 91, 't': 70208, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 91),
/* {'track': 1, 'velocity': 0, 't': 70240, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 70260, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 70260, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 70260, 'channel': 2, 'pitch': 68} */
NOTE(10, 68, 0),
/* {'track': 1, 'velocity': 103, 't': 70272, 'channel': 1, 'pitch': 80} */
PAUSE(12),
NOTE(0, 80, 103),
/* {'track': 1, 'velocity': 78, 't': 70272, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 78),
/* {'track': 1, 'velocity': 77, 't': 70272, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 77),
/* {'track': 1, 'velocity': 78, 't': 70272, 'channel': 2, 'pitch': 68} */
NOTE(10, 68, 78),
/* {'track': 1, 'velocity': 0, 't': 70304, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 86, 't': 70336, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 86),
/* {'track': 1, 'velocity': 0, 't': 70368, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 70388, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 70388, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 70388, 'channel': 2, 'pitch': 68} */
NOTE(10, 68, 0),
/* {'track': 1, 'velocity': 90, 't': 70400, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 90),
/* {'track': 1, 'velocity': 0, 't': 70432, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 85, 't': 70464, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 85),
/* {'track': 1, 'velocity': 0, 't': 70496, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 103, 't': 70528, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 103),
/* {'track': 1, 'velocity': 67, 't': 70528, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 67),
/* {'track': 1, 'velocity': 69, 't': 70528, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 69),
/* {'track': 1, 'velocity': 0, 't': 70560, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 104, 't': 70592, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 104),
/* {'track': 1, 'velocity': 0, 't': 70624, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 70644, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 70644, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 106, 't': 70656, 'channel': 1, 'pitch': 78} */
PAUSE(12),
NOTE(0, 78, 106),
/* {'track': 1, 'velocity': 84, 't': 70656, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 84),
/* {'track': 1, 'velocity': 83, 't': 70656, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 83),
/* {'track': 1, 'velocity': 83, 't': 70656, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 83),
/* {'track': 1, 'velocity': 0, 't': 70688, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 89, 't': 70720, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 89),
/* {'track': 1, 'velocity': 0, 't': 70752, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 70772, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 70772, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 70772, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 0),
/* {'track': 1, 'velocity': 100, 't': 70784, 'channel': 1, 'pitch': 78} */
PAUSE(12),
NOTE(0, 78, 100),
/* {'track': 1, 'velocity': 77, 't': 70784, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 77),
/* {'track': 1, 'velocity': 75, 't': 70784, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 75),
/* {'track': 1, 'velocity': 77, 't': 70784, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 77),
/* {'track': 1, 'velocity': 0, 't': 70816, 'channel': 1, 'pitch': 78} */
PAUSE(32),
NOTE(0, 78, 0),
/* {'track': 1, 'velocity': 89, 't': 70848, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 89),
/* {'track': 1, 'velocity': 0, 't': 70880, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 70900, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 70900, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 70900, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 0),
/* {'track': 1, 'velocity': 91, 't': 70912, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 91),
/* {'track': 1, 'velocity': 0, 't': 70944, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 83, 't': 70976, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 83),
/* {'track': 1, 'velocity': 0, 't': 71008, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 105, 't': 71040, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 105),
/* {'track': 1, 'velocity': 67, 't': 71040, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 67),
/* {'track': 1, 'velocity': 70, 't': 71040, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 70),
/* {'track': 1, 'velocity': 68, 't': 71040, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 68),
/* {'track': 1, 'velocity': 0, 't': 71072, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 104, 't': 71104, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 104),
/* {'track': 1, 'velocity': 0, 't': 71136, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 71156, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 71156, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 71156, 'channel': 2, 'pitch': 66} */
NOTE(10, 66, 0),
/* {'track': 1, 'velocity': 111, 't': 71168, 'channel': 1, 'pitch': 80} */
PAUSE(12),
NOTE(0, 80, 111),
/* {'track': 1, 'velocity': 83, 't': 71168, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 83),
/* {'track': 1, 'velocity': 80, 't': 71168, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 80),
/* {'track': 1, 'velocity': 82, 't': 71168, 'channel': 2, 'pitch': 68} */
NOTE(10, 68, 82),
/* {'track': 1, 'velocity': 0, 't': 71200, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 87, 't': 71232, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 87),
/* {'track': 1, 'velocity': 0, 't': 71264, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 71284, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 71284, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 71284, 'channel': 2, 'pitch': 68} */
NOTE(10, 68, 0),
/* {'track': 1, 'velocity': 106, 't': 71296, 'channel': 1, 'pitch': 80} */
PAUSE(12),
NOTE(0, 80, 106),
/* {'track': 1, 'velocity': 76, 't': 71296, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 76),
/* {'track': 1, 'velocity': 76, 't': 71296, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 76),
/* {'track': 1, 'velocity': 75, 't': 71296, 'channel': 2, 'pitch': 68} */
NOTE(10, 68, 75),
/* {'track': 1, 'velocity': 0, 't': 71328, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 87, 't': 71360, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 87),
/* {'track': 1, 'velocity': 0, 't': 71392, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 71412, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 71412, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 71412, 'channel': 2, 'pitch': 68} */
NOTE(10, 68, 0),
/* {'track': 1, 'velocity': 90, 't': 71424, 'channel': 1, 'pitch': 73} */
PAUSE(12),
NOTE(0, 73, 90),
/* {'track': 1, 'velocity': 0, 't': 71456, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 84, 't': 71488, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 84),
/* {'track': 1, 'velocity': 0, 't': 71520, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 106, 't': 71552, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 106),
/* {'track': 1, 'velocity': 69, 't': 71552, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 69),
/* {'track': 1, 'velocity': 69, 't': 71552, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 69),
/* {'track': 1, 'velocity': 68, 't': 71552, 'channel': 2, 'pitch': 68} */
NOTE(10, 68, 68),
/* {'track': 1, 'velocity': 0, 't': 71584, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 107, 't': 71616, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 107),
/* {'track': 1, 'velocity': 0, 't': 71648, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 71668, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 71668, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 71668, 'channel': 2, 'pitch': 68} */
NOTE(10, 68, 0),
/* {'track': 1, 'velocity': 85, 't': 71680, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 85),
/* {'track': 1, 'velocity': 71, 't': 71680, 'channel': 2, 'pitch': 61} */
NOTE(8, 61, 71),
/* {'track': 1, 'velocity': 70, 't': 71680, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 70),
/* {'track': 1, 'velocity': 0, 't': 71712, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 89, 't': 71744, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 89),
/* {'track': 1, 'velocity': 0, 't': 71776, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 71796, 'channel': 2, 'pitch': 61} */
PAUSE(20),
NOTE(8, 61, 0),
/* {'track': 1, 'velocity': 0, 't': 71796, 'channel': 2, 'pitch': 64} */
NOTE(9, 64, 0),
/* {'track': 1, 'velocity': 101, 't': 71808, 'channel': 1, 'pitch': 69} */
PAUSE(12),
NOTE(0, 69, 101),
/* {'track': 1, 'velocity': 0, 't': 71840, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 81, 't': 71872, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 81),
/* {'track': 1, 'velocity': 0, 't': 71904, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 89, 't': 71936, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 89),
/* {'track': 1, 'velocity': 0, 't': 71968, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 84, 't': 72000, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 84),
/* {'track': 1, 'velocity': 0, 't': 72032, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 0),
/* {'track': 1, 'velocity': 105, 't': 72064, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 105),
/* {'track': 1, 'velocity': 0, 't': 72096, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 103, 't': 72128, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 103),
/* {'track': 1, 'velocity': 0, 't': 72160, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 113, 't': 72192, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 113),
/* {'track': 1, 'velocity': 0, 't': 72224, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 93, 't': 72256, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 93),
/* {'track': 1, 'velocity': 0, 't': 72288, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 101, 't': 72320, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 101),
/* {'track': 1, 'velocity': 0, 't': 72352, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 85, 't': 72384, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 85),
/* {'track': 1, 'velocity': 0, 't': 72416, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 86, 't': 72448, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 86),
/* {'track': 1, 'velocity': 0, 't': 72480, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 84, 't': 72512, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 84),
/* {'track': 1, 'velocity': 0, 't': 72544, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 0),
/* {'track': 1, 'velocity': 104, 't': 72576, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 104),
/* {'track': 1, 'velocity': 0, 't': 72608, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 104, 't': 72640, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 104),
/* {'track': 1, 'velocity': 0, 't': 72672, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 115, 't': 72704, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 115),
/* {'track': 1, 'velocity': 0, 't': 72736, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 91, 't': 72768, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 91),
/* {'track': 1, 'velocity': 0, 't': 72800, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 102, 't': 72832, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 102),
/* {'track': 1, 'velocity': 0, 't': 72864, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 85, 't': 72896, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 85),
/* {'track': 1, 'velocity': 0, 't': 72928, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 88, 't': 72960, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 88),
/* {'track': 1, 'velocity': 0, 't': 72992, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 86, 't': 73024, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 86),
/* {'track': 1, 'velocity': 0, 't': 73056, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 0),
/* {'track': 1, 'velocity': 103, 't': 73088, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 103),
/* {'track': 1, 'velocity': 0, 't': 73120, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 104, 't': 73152, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 104),
/* {'track': 1, 'velocity': 0, 't': 73184, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 113, 't': 73216, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 113),
/* {'track': 1, 'velocity': 0, 't': 73248, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 93, 't': 73280, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 93),
/* {'track': 1, 'velocity': 0, 't': 73312, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 99, 't': 73344, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 99),
/* {'track': 1, 'velocity': 0, 't': 73376, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 83, 't': 73408, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 83),
/* {'track': 1, 'velocity': 0, 't': 73440, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 89, 't': 73472, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 89),
/* {'track': 1, 'velocity': 0, 't': 73504, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 84, 't': 73536, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 84),
/* {'track': 1, 'velocity': 0, 't': 73568, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 0),
/* {'track': 1, 'velocity': 104, 't': 73600, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 104),
/* {'track': 1, 'velocity': 0, 't': 73632, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 106, 't': 73664, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 106),
/* {'track': 1, 'velocity': 0, 't': 73696, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 113, 't': 73728, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 113),
/* {'track': 1, 'velocity': 73, 't': 73728, 'channel': 2, 'pitch': 45} */
NOTE(8, 45, 73),
/* {'track': 1, 'velocity': 0, 't': 73760, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 92, 't': 73792, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 92),
/* {'track': 1, 'velocity': 0, 't': 73824, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 102, 't': 73856, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 102),
/* {'track': 1, 'velocity': 0, 't': 73888, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 82, 't': 73920, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 82),
/* {'track': 1, 'velocity': 0, 't': 73952, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 89, 't': 73984, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 89),
/* {'track': 1, 'velocity': 0, 't': 74016, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 85, 't': 74048, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 85),
/* {'track': 1, 'velocity': 0, 't': 74080, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 0),
/* {'track': 1, 'velocity': 105, 't': 74112, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 105),
/* {'track': 1, 'velocity': 0, 't': 74144, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 103, 't': 74176, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 103),
/* {'track': 1, 'velocity': 0, 't': 74208, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 120, 't': 74240, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 120),
/* {'track': 1, 'velocity': 0, 't': 74272, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 94, 't': 74304, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 94),
/* {'track': 1, 'velocity': 0, 't': 74336, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 100, 't': 74368, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 100),
/* {'track': 1, 'velocity': 0, 't': 74400, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 86, 't': 74432, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 86),
/* {'track': 1, 'velocity': 0, 't': 74464, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 90, 't': 74496, 'channel': 1, 'pitch': 66} */
PAUSE(32),
NOTE(0, 66, 90),
/* {'track': 1, 'velocity': 0, 't': 74528, 'channel': 1, 'pitch': 66} */
PAUSE(32),
NOTE(0, 66, 0),
/* {'track': 1, 'velocity': 80, 't': 74560, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 80),
/* {'track': 1, 'velocity': 0, 't': 74592, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 108, 't': 74624, 'channel': 1, 'pitch': 66} */
PAUSE(32),
NOTE(0, 66, 108),
/* {'track': 1, 'velocity': 0, 't': 74656, 'channel': 1, 'pitch': 66} */
PAUSE(32),
NOTE(0, 66, 0),
/* {'track': 1, 'velocity': 104, 't': 74688, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 104),
/* {'track': 1, 'velocity': 0, 't': 74720, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 100, 't': 74752, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 100),
/* {'track': 1, 'velocity': 0, 't': 74784, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 89, 't': 74816, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 89),
/* {'track': 1, 'velocity': 0, 't': 74848, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 100, 't': 74880, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 100),
/* {'track': 1, 'velocity': 0, 't': 74912, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 82, 't': 74944, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 82),
/* {'track': 1, 'velocity': 0, 't': 74976, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 89, 't': 75008, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 89),
/* {'track': 1, 'velocity': 0, 't': 75040, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 84, 't': 75072, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 84),
/* {'track': 1, 'velocity': 0, 't': 75104, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 0),
/* {'track': 1, 'velocity': 105, 't': 75136, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 105),
/* {'track': 1, 'velocity': 0, 't': 75168, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 106, 't': 75200, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 106),
/* {'track': 1, 'velocity': 0, 't': 75232, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 122, 't': 75264, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 122),
/* {'track': 1, 'velocity': 0, 't': 75296, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 95, 't': 75328, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 95),
/* {'track': 1, 'velocity': 0, 't': 75360, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 99, 't': 75392, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 99),
/* {'track': 1, 'velocity': 0, 't': 75424, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 88, 't': 75456, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 88),
/* {'track': 1, 'velocity': 0, 't': 75488, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 88, 't': 75520, 'channel': 1, 'pitch': 66} */
PAUSE(32),
NOTE(0, 66, 88),
/* {'track': 1, 'velocity': 0, 't': 75552, 'channel': 1, 'pitch': 66} */
PAUSE(32),
NOTE(0, 66, 0),
/* {'track': 1, 'velocity': 83, 't': 75584, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 83),
/* {'track': 1, 'velocity': 0, 't': 75616, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 105, 't': 75648, 'channel': 1, 'pitch': 66} */
PAUSE(32),
NOTE(0, 66, 105),
/* {'track': 1, 'velocity': 0, 't': 75680, 'channel': 1, 'pitch': 66} */
PAUSE(32),
NOTE(0, 66, 0),
/* {'track': 1, 'velocity': 103, 't': 75712, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 103),
/* {'track': 1, 'velocity': 0, 't': 75726, 'channel': 2, 'pitch': 45} */
PAUSE(14),
NOTE(8, 45, 0),
/* {'track': 1, 'velocity': 0, 't': 75744, 'channel': 1, 'pitch': 69} */
PAUSE(18),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 98, 't': 75776, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 98),
/* {'track': 1, 'velocity': 81, 't': 75776, 'channel': 2, 'pitch': 45} */
NOTE(8, 45, 81),
/* {'track': 1, 'velocity': 0, 't': 75808, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 91, 't': 75840, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 91),
/* {'track': 1, 'velocity': 0, 't': 75872, 'channel': 1, 'pitch': 68} */
PAUSE(32),
NOTE(0, 68, 0),
/* {'track': 1, 'velocity': 99, 't': 75904, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 99),
/* {'track': 1, 'velocity': 0, 't': 75936, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 85, 't': 75968, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 85),
/* {'track': 1, 'velocity': 0, 't': 76000, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 90, 't': 76032, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 90),
/* {'track': 1, 'velocity': 0, 't': 76064, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 84, 't': 76096, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 84),
/* {'track': 1, 'velocity': 0, 't': 76128, 'channel': 1, 'pitch': 57} */
PAUSE(32),
NOTE(0, 57, 0),
/* {'track': 1, 'velocity': 102, 't': 76160, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 102),
/* {'track': 1, 'velocity': 0, 't': 76192, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 106, 't': 76224, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 106),
/* {'track': 1, 'velocity': 0, 't': 76256, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 121, 't': 76288, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 121),
/* {'track': 1, 'velocity': 0, 't': 76320, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 95, 't': 76352, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 95),
/* {'track': 1, 'velocity': 0, 't': 76384, 'channel': 1, 'pitch': 72} */
PAUSE(32),
NOTE(0, 72, 0),
/* {'track': 1, 'velocity': 100, 't': 76416, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 100),
/* {'track': 1, 'velocity': 0, 't': 76448, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 85, 't': 76480, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 85),
/* {'track': 1, 'velocity': 0, 't': 76512, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 83, 't': 76544, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 83),
/* {'track': 1, 'velocity': 0, 't': 76576, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 86, 't': 76608, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 86),
/* {'track': 1, 'velocity': 0, 't': 76640, 'channel': 1, 'pitch': 61} */
PAUSE(32),
NOTE(0, 61, 0),
/* {'track': 1, 'velocity': 100, 't': 76672, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 100),
/* {'track': 1, 'velocity': 0, 't': 76704, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 108, 't': 76736, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 108),
/* {'track': 1, 'velocity': 0, 't': 76768, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 119, 't': 76800, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 119),
/* {'track': 1, 'velocity': 0, 't': 76832, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 91, 't': 76864, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 91),
/* {'track': 1, 'velocity': 0, 't': 76896, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 102, 't': 76928, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 102),
/* {'track': 1, 'velocity': 0, 't': 76960, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 89, 't': 76992, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 89),
/* {'track': 1, 'velocity': 0, 't': 77024, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 88, 't': 77056, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 88),
/* {'track': 1, 'velocity': 0, 't': 77088, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 79, 't': 77120, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 79),
/* {'track': 1, 'velocity': 0, 't': 77152, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 108, 't': 77184, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 108),
/* {'track': 1, 'velocity': 0, 't': 77216, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 110, 't': 77248, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 110),
/* {'track': 1, 'velocity': 0, 't': 77280, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 119, 't': 77312, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 119),
/* {'track': 1, 'velocity': 0, 't': 77344, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 93, 't': 77376, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 93),
/* {'track': 1, 'velocity': 0, 't': 77408, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 102, 't': 77440, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 102),
/* {'track': 1, 'velocity': 0, 't': 77472, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 86, 't': 77504, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 86),
/* {'track': 1, 'velocity': 0, 't': 77536, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 88, 't': 77568, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 88),
/* {'track': 1, 'velocity': 0, 't': 77600, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 84, 't': 77632, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 84),
/* {'track': 1, 'velocity': 0, 't': 77664, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 105, 't': 77696, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 105),
/* {'track': 1, 'velocity': 0, 't': 77728, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 105, 't': 77760, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 105),
/* {'track': 1, 'velocity': 0, 't': 77774, 'channel': 2, 'pitch': 45} */
PAUSE(14),
NOTE(8, 45, 0),
/* {'track': 1, 'velocity': 0, 't': 77792, 'channel': 1, 'pitch': 76} */
PAUSE(18),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 120, 't': 77824, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 120),
/* {'track': 1, 'velocity': 0, 't': 77856, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 93, 't': 77888, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 93),
/* {'track': 1, 'velocity': 0, 't': 77920, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 99, 't': 77952, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 99),
/* {'track': 1, 'velocity': 0, 't': 77984, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 87, 't': 78016, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 87),
/* {'track': 1, 'velocity': 0, 't': 78048, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 85, 't': 78080, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 85),
/* {'track': 1, 'velocity': 0, 't': 78112, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 69, 't': 78144, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 69),
/* {'track': 1, 'velocity': 0, 't': 78176, 'channel': 1, 'pitch': 64} */
PAUSE(32),
NOTE(0, 64, 0),
/* {'track': 1, 'velocity': 105, 't': 78208, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 105),
/* {'track': 1, 'velocity': 0, 't': 78240, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 107, 't': 78272, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 107),
/* {'track': 1, 'velocity': 0, 't': 78304, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 118, 't': 78336, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 118),
/* {'track': 1, 'velocity': 0, 't': 78368, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 96, 't': 78400, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 96),
/* {'track': 1, 'velocity': 0, 't': 78432, 'channel': 1, 'pitch': 80} */
PAUSE(32),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 99, 't': 78464, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 99),
/* {'track': 1, 'velocity': 0, 't': 78496, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 85, 't': 78528, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 85),
/* {'track': 1, 'velocity': 0, 't': 78560, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 86, 't': 78592, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 86),
/* {'track': 1, 'velocity': 0, 't': 78624, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 86, 't': 78656, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 86),
/* {'track': 1, 'velocity': 0, 't': 78688, 'channel': 1, 'pitch': 69} */
PAUSE(32),
NOTE(0, 69, 0),
/* {'track': 1, 'velocity': 105, 't': 78720, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 105),
/* {'track': 1, 'velocity': 0, 't': 78752, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 107, 't': 78784, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 107),
/* {'track': 1, 'velocity': 0, 't': 78816, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 122, 't': 78848, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 122),
/* {'track': 1, 'velocity': 0, 't': 78880, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 96, 't': 78912, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 96),
/* {'track': 1, 'velocity': 0, 't': 78944, 'channel': 1, 'pitch': 84} */
PAUSE(32),
NOTE(0, 84, 0),
/* {'track': 1, 'velocity': 100, 't': 78976, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 100),
/* {'track': 1, 'velocity': 0, 't': 79008, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 85, 't': 79040, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 85),
/* {'track': 1, 'velocity': 0, 't': 79072, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 83, 't': 79104, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 83),
/* {'track': 1, 'velocity': 0, 't': 79136, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 84, 't': 79168, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 84),
/* {'track': 1, 'velocity': 0, 't': 79200, 'channel': 1, 'pitch': 73} */
PAUSE(32),
NOTE(0, 73, 0),
/* {'track': 1, 'velocity': 104, 't': 79232, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 104),
/* {'track': 1, 'velocity': 0, 't': 79264, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 110, 't': 79296, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 110),
/* {'track': 1, 'velocity': 0, 't': 79328, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 119, 't': 79360, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 119),
/* {'track': 1, 'velocity': 0, 't': 79392, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 95, 't': 79424, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 95),
/* {'track': 1, 'velocity': 0, 't': 79456, 'channel': 1, 'pitch': 87} */
PAUSE(32),
NOTE(0, 87, 0),
/* {'track': 1, 'velocity': 100, 't': 79488, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 100),
/* {'track': 1, 'velocity': 0, 't': 79520, 'channel': 1, 'pitch': 88} */
PAUSE(32),
NOTE(0, 88, 0),
/* {'track': 1, 'velocity': 88, 't': 79552, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 88),
/* {'track': 1, 'velocity': 0, 't': 79584, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 86, 't': 79616, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 86),
/* {'track': 1, 'velocity': 0, 't': 79648, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 83, 't': 79680, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 83),
/* {'track': 1, 'velocity': 0, 't': 79712, 'channel': 1, 'pitch': 76} */
PAUSE(32),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 105, 't': 79744, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 105),
/* {'track': 1, 'velocity': 0, 't': 79776, 'channel': 1, 'pitch': 81} */
PAUSE(32),
NOTE(0, 81, 0),
/* {'track': 1, 'velocity': 109, 't': 79808, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 109),
/* {'track': 1, 'velocity': 0, 't': 79840, 'channel': 1, 'pitch': 85} */
PAUSE(32),
NOTE(0, 85, 0),
/* {'track': 1, 'velocity': 120, 't': 79872, 'channel': 1, 'pitch': 93} */
PAUSE(32),
NOTE(0, 93, 120),
/* {'track': 1, 'velocity': 0, 't': 79904, 'channel': 1, 'pitch': 93} */
PAUSE(32),
NOTE(0, 93, 0),
/* {'track': 1, 'velocity': 86, 't': 80384, 'channel': 1, 'pitch': 76} */
PAUSE(255),
NOTE(0, 76, 86),
/* {'track': 1, 'velocity': 87, 't': 80384, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 87),
/* {'track': 1, 'velocity': 88, 't': 80384, 'channel': 1, 'pitch': 85} */
NOTE(2, 85, 88),
/* {'track': 1, 'velocity': 85, 't': 80384, 'channel': 1, 'pitch': 88} */
NOTE(3, 88, 85),
/* {'track': 1, 'velocity': 68, 't': 80384, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 68),
/* {'track': 1, 'velocity': 68, 't': 80384, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 68),
/* {'track': 1, 'velocity': 68, 't': 80384, 'channel': 2, 'pitch': 73} */
NOTE(10, 73, 68),
/* {'track': 1, 'velocity': 67, 't': 80384, 'channel': 2, 'pitch': 45} */
NOTE(11, 45, 67),
/* {'track': 1, 'velocity': 0, 't': 80846, 'channel': 1, 'pitch': 76} */
PAUSE(255),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 80846, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 80846, 'channel': 1, 'pitch': 85} */
NOTE(2, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 80846, 'channel': 1, 'pitch': 88} */
NOTE(3, 88, 0),
/* {'track': 1, 'velocity': 0, 't': 80846, 'channel': 2, 'pitch': 64} */
NOTE(8, 64, 0),
/* {'track': 1, 'velocity': 0, 't': 80846, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 80846, 'channel': 2, 'pitch': 73} */
NOTE(10, 73, 0),
/* {'track': 1, 'velocity': 0, 't': 80846, 'channel': 2, 'pitch': 45} */
NOTE(11, 45, 0),
/* {'track': 1, 'velocity': 96, 't': 80896, 'channel': 1, 'pitch': 76} */
PAUSE(50),
NOTE(0, 76, 96),
/* {'track': 1, 'velocity': 93, 't': 80896, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 93),
/* {'track': 1, 'velocity': 96, 't': 80896, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 96),
/* {'track': 1, 'velocity': 93, 't': 80896, 'channel': 1, 'pitch': 88} */
NOTE(3, 88, 93),
/* {'track': 1, 'velocity': 76, 't': 80896, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 76),
/* {'track': 1, 'velocity': 74, 't': 80896, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 74),
/* {'track': 1, 'velocity': 74, 't': 80896, 'channel': 2, 'pitch': 73} */
NOTE(10, 73, 74),
/* {'track': 1, 'velocity': 86, 't': 80896, 'channel': 2, 'pitch': 50} */
NOTE(11, 50, 86),
/* {'track': 1, 'velocity': 0, 't': 81358, 'channel': 1, 'pitch': 76} */
PAUSE(255),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 81358, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 81358, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 81358, 'channel': 1, 'pitch': 88} */
NOTE(3, 88, 0),
/* {'track': 1, 'velocity': 0, 't': 81358, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 81358, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 81358, 'channel': 2, 'pitch': 73} */
NOTE(10, 73, 0),
/* {'track': 1, 'velocity': 0, 't': 81358, 'channel': 2, 'pitch': 50} */
NOTE(11, 50, 0),
/* {'track': 1, 'velocity': 89, 't': 81408, 'channel': 1, 'pitch': 74} */
PAUSE(50),
NOTE(0, 74, 89),
/* {'track': 1, 'velocity': 91, 't': 81408, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 91),
/* {'track': 1, 'velocity': 89, 't': 81408, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 89),
/* {'track': 1, 'velocity': 89, 't': 81408, 'channel': 1, 'pitch': 86} */
NOTE(3, 86, 89),
/* {'track': 1, 'velocity': 67, 't': 81408, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 67),
/* {'track': 1, 'velocity': 68, 't': 81408, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 68),
/* {'track': 1, 'velocity': 78, 't': 81408, 'channel': 2, 'pitch': 50} */
NOTE(10, 50, 78),
/* {'track': 1, 'velocity': 0, 't': 81639, 'channel': 1, 'pitch': 74} */
PAUSE(231),
NOTE(0, 74, 0),
/* {'track': 1, 'velocity': 0, 't': 81639, 'channel': 1, 'pitch': 78} */
NOTE(1, 78, 0),
/* {'track': 1, 'velocity': 0, 't': 81639, 'channel': 1, 'pitch': 81} */
NOTE(2, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 81639, 'channel': 1, 'pitch': 86} */
NOTE(3, 86, 0),
/* {'track': 1, 'velocity': 0, 't': 81639, 'channel': 2, 'pitch': 66} */
NOTE(8, 66, 0),
/* {'track': 1, 'velocity': 0, 't': 81639, 'channel': 2, 'pitch': 69} */
NOTE(9, 69, 0),
/* {'track': 1, 'velocity': 87, 't': 81664, 'channel': 1, 'pitch': 80} */
PAUSE(25),
NOTE(0, 80, 87),
/* {'track': 1, 'velocity': 88, 't': 81664, 'channel': 1, 'pitch': 83} */
NOTE(1, 83, 88),
/* {'track': 1, 'velocity': 81, 't': 81664, 'channel': 2, 'pitch': 68} */
NOTE(8, 68, 81),
/* {'track': 1, 'velocity': 80, 't': 81664, 'channel': 2, 'pitch': 71} */
NOTE(9, 71, 80),
/* {'track': 1, 'velocity': 0, 't': 81870, 'channel': 2, 'pitch': 50} */
PAUSE(206),
NOTE(8, 50, 0),
/* {'track': 1, 'velocity': 0, 't': 81895, 'channel': 1, 'pitch': 80} */
PAUSE(25),
NOTE(0, 80, 0),
/* {'track': 1, 'velocity': 0, 't': 81895, 'channel': 1, 'pitch': 83} */
NOTE(1, 83, 0),
/* {'track': 1, 'velocity': 0, 't': 81895, 'channel': 2, 'pitch': 68} */
NOTE(8, 68, 0),
/* {'track': 1, 'velocity': 0, 't': 81895, 'channel': 2, 'pitch': 71} */
NOTE(9, 71, 0),
/* {'track': 1, 'velocity': 109, 't': 81920, 'channel': 1, 'pitch': 76} */
PAUSE(25),
NOTE(0, 76, 109),
/* {'track': 1, 'velocity': 109, 't': 81920, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 109),
/* {'track': 1, 'velocity': 111, 't': 81920, 'channel': 1, 'pitch': 85} */
NOTE(2, 85, 111),
/* {'track': 1, 'velocity': 109, 't': 81920, 'channel': 1, 'pitch': 88} */
NOTE(3, 88, 109),
/* {'track': 1, 'velocity': 86, 't': 81920, 'channel': 2, 'pitch': 69} */
NOTE(8, 69, 86),
/* {'track': 1, 'velocity': 86, 't': 81920, 'channel': 2, 'pitch': 73} */
NOTE(9, 73, 86),
/* {'track': 1, 'velocity': 67, 't': 81920, 'channel': 2, 'pitch': 45} */
NOTE(10, 45, 67),
/* {'track': 1, 'velocity': 0, 't': 83918, 'channel': 1, 'pitch': 76} */
PAUSE(255),
NOTE(0, 76, 0),
/* {'track': 1, 'velocity': 0, 't': 83918, 'channel': 1, 'pitch': 81} */
NOTE(1, 81, 0),
/* {'track': 1, 'velocity': 0, 't': 83918, 'channel': 1, 'pitch': 85} */
NOTE(2, 85, 0),
/* {'track': 1, 'velocity': 0, 't': 83918, 'channel': 1, 'pitch': 88} */
NOTE(3, 88, 0),
/* {'track': 1, 'velocity': 0, 't': 83918, 'channel': 2, 'pitch': 69} */
NOTE(8, 69, 0),
/* {'track': 1, 'velocity': 0, 't': 83918, 'channel': 2, 'pitch': 73} */
NOTE(9, 73, 0),
/* {'track': 1, 'velocity': 0, 't': 83918, 'channel': 2, 'pitch': 45} */
NOTE(10, 45, 0),
